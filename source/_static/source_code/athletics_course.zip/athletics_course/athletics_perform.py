#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\11.拓展课程之田径运动课程\第4课 田径运动(4.Advanced Lessons\11.Athletics Sport Lesson\Lesson4 Athletics Performance) #3
import os #4
import sys #5
import cv2 #6
import time #7
import math #8
import threading #9
import numpy as np #10
import hiwonder.ros_robot_controller_sdk as rrc #11
from hiwonder.Controller import Controller #12
import hiwonder.Misc as Misc #13
import hiwonder.PID as PID #14
import hiwonder.ActionGroupControl as AGC #15
import hiwonder.yaml_handle as yaml_handle #16

if sys.version_info.major == 2: #18
    print('Please run this program with python3!') #19
    sys.exit(0) #20

# 田径表演(athletics performance) #22

go_forward = 'go_forward' #24
go_forward_one_step = 'go_forward_one_step' #25
turn_right = 'turn_right_small_step_a' #26
turn_left  = 'turn_left_small_step_a'         #27
left_move = 'left_move_20' #28
right_move = 'right_move_20' #29
go_turn_right = 'turn_right' #30
go_turn_left = 'turn_left' #31

lab_data = None #33
servo_data = None #34

def load_config(): #36
    global lab_data, servo_data #37
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #39
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #40

load_config() #42

board = rrc.Board() #44
ctl = Controller(board) #45

# 初始位置(initial position) #47
def initMove(): #48
    ctl.set_pwm_servo_pulse(1,servo_data['servo1'],500) #49
    ctl.set_pwm_servo_pulse(2,servo_data['servo2'],500)    #50

object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #52
switch = False #53
# 变量重置(variable reset) #54
def reset(): #55
    global object_left_x, object_right_x #56
    global object_center_y, object_angle, switch #57
    
    switch = False #59
    object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #60
    
def init(): #62
    load_config() #63
    initMove() #64
    reset() #65


# 找出面积最大的轮廓(find out the contour with the maximal area) #68
# 参数为要比较的轮廓的列表(the parameter is a list of contours to compare) #69
def getAreaMaxContour(contours, area_min=10): #70
    contour_area_temp = 0 #71
    contour_area_max = 0 #72
    area_max_contour = None #73

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #75
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #76
        if contour_area_temp > contour_area_max: #77
            contour_area_max = contour_area_temp #78
            if contour_area_temp >= area_min:  # 只有在面积大于设定值时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than the set value, the contour with the largest area is considered valid, to filter out interference) #79
                area_max_contour = c #80

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #82


line_centerx = 320 #85
size = (640, 480) #86
roi = [  #87
        (300, 340,  0, 640, 0.1),  #88
        (360, 400,  0, 640, 0.3),  #89
        (420, 480,  0, 640, 0.6) #90
      ] #91

roi_h1 = roi[0][0] #93
roi_h2 = roi[1][0] - roi[0][0] #94
roi_h3 = roi[2][0] - roi[1][0] #95
roi_h_list = [roi_h1, roi_h2, roi_h3] #96

#巡线视觉处理函数(line following vision processing function) #98
def line_patrol(img, img_draw, target_color = 'black'): #99
    
    n = 0 #101
    center_ = [] #102
    weight_sum = 0 #103
    centroid_x_sum = 0 #104
    
    img_h, img_w = img.shape[:2] #106
    frame_resize = cv2.resize(img_draw, size, interpolation=cv2.INTER_NEAREST) #107
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #108
    
    #将图像分割成上中下三个部分，这样处理速度会更快，更精确(divide the image into three parts: top, middle, and bottom. This approach will result in faster and more accurate processing) #110
    for r in roi: #111
        roi_h = roi_h_list[n] #112
        n += 1        #113
        blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #114
        frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #115
        
        frame_mask = cv2.inRange(frame_lab, #117
                                     (lab_data[target_color]['min'][0], #118
                                      lab_data[target_color]['min'][1], #119
                                      lab_data[target_color]['min'][2]), #120
                                     (lab_data[target_color]['max'][0], #121
                                      lab_data[target_color]['max'][1], #122
                                      lab_data[target_color]['max'][2]))  #对原图像和掩模进行位运算(operate bitwise operation to original image and mask) #123
        opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6, 6), np.uint8))  # 开运算(opening operation) #124
        closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6, 6), np.uint8))  # 闭运算(closing operation) #125
        cnts = cv2.findContours(closed , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all contours) #126
        cnt_large, area = getAreaMaxContour(cnts)#找到最大面积的轮廓(find out the contour with the maximal area) #127
        if cnt_large is not None:#如果轮廓不为空(if contour is not NONE) #128
            rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimum bounding rectangle) #129
            box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #130
            for i in range(4): #131
                box[i, 1] = box[i, 1] + (n - 1)*roi_h + roi[0][0] #132
                box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #133
            for i in range(4):                 #134
                box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #135
                
            cv2.drawContours(img_draw, [box], -1, (0,0,255,255), 2)#画出四个点组成的矩形(draw the rectangle formed by the four points) #137
        
            #获取矩形的对角点(retrieve the diagonal points of the rectangle) #139
            pt1_x, pt1_y = box[0, 0], box[0, 1] #140
            pt3_x, pt3_y = box[2, 0], box[2, 1]             #141
            center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2#中心点(center point) #142
            cv2.circle(img_draw, (int(center_x), int(center_y)), 5, (0,0,255), -1)#画出中心点(draw center point) #143
            
            center_.append([center_x, center_y])                         #145
            #按权重不同对上中下三个中心点进行求和(sum the weighted centroids of the upper, middle, and lower regions with different weights) #146
            centroid_x_sum += center_x * r[4] #147
            weight_sum += r[4] #148

    if weight_sum != 0: #150
        #求最终得到的中心点(calculate the final obtained center point) #151
        line_centerx = int(centroid_x_sum / weight_sum) #152
        cv2.circle(img_draw, (line_centerx, int(center_y)), 10, (0,255,255), -1)#画出中心(draw center) #153
    else: #154
        line_centerx = 8888 #155

    return line_centerx #157


# 色块定位视觉处理函数(the visual processing function for color block localization) #160
def color_identify(img, img_draw, target_color = 'blue'): #161
    
    img_w = img.shape[:2][1] #163
    img_h = img.shape[:2][0] #164
    img_resize = cv2.resize(img, (size[0], size[1]), interpolation = cv2.INTER_CUBIC) #165
    GaussianBlur_img = cv2.GaussianBlur(img_resize, (3, 3), 0)#高斯模糊(Gaussian blur) #166
    frame_lab = cv2.cvtColor(GaussianBlur_img, cv2.COLOR_BGR2LAB) #将图像转换到LAB空间(convert the image to LAB space) #167
    frame_mask = cv2.inRange(frame_lab, #168
                                 (lab_data[target_color]['min'][0], #169
                                  lab_data[target_color]['min'][1], #170
                                  lab_data[target_color]['min'][2]), #171
                                 (lab_data[target_color]['max'][0], #172
                                  lab_data[target_color]['max'][1], #173
                                  lab_data[target_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #174
    opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))#开运算(opening operation) #175
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((3,3),np.uint8))#闭运算(closing operation) #176
    contours = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #找出所有外轮廓(find out all the bounding contours) #177
    areaMax_contour = getAreaMaxContour(contours, area_min=50)[0] #找到最大的轮廓(find out the contour with the maximal area) #178

    left_x, right_x, center_y, angle = -1, -1, -1, 0 #180
    if areaMax_contour is not None: #181
        down_x = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[0] #182
        down_y = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1] #183

        left_x = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[0] #185
        left_y = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[1] #186

        right_x = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[0] #188
        right_y = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[1] #189
        
        if pow(down_x - left_x, 2) + pow(down_y - left_y, 2) > pow(down_x - right_x, 2) + pow(down_y - right_y, 2): #191
            left_x = int(Misc.map(left_x, 0, size[0], 0, img_w)) #192
            left_y = int(Misc.map(left_y, 0, size[1], 0, img_h))   #193
            right_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #194
            right_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #195
        else: #196
            left_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #197
            left_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #198
            right_x = int(Misc.map(right_x, 0, size[0], 0, img_w)) #199
            right_y = int(Misc.map(right_y, 0, size[1], 0, img_h)) #200

        center_y = int(Misc.map((areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1], 0, size[1], 0, img_h)) #202
        angle = int(math.degrees(math.atan2(right_y - left_y, right_x - left_x))) #203
        
        cv2.line(img_draw, (left_x, left_y), (right_x, right_y), (255, 0, 0), 2)      #205
            
    return left_x, right_x, center_y, angle       #207


skip = 1 #210
skip_st = True #211
items = None #212
line_st = True #213
fence_st = True #214
strp_up = True #215
x_center = 360 #216
#机器人跟踪线程(robot tracking thread) #217
def move(): #218
    global object_center_y,line_centerx,items #219
    global line_st,strp_up,fence_st,skip_st #220
    
    while True: #222
        if switch: #223
            if object_center_y >= 300:  #检测到台阶或者跨栏,进行位置微调(detect steps or hurdles and perform position refinement) #224
                
                if 20 <= object_angle < 90: #226
                    AGC.runActionGroup(go_turn_right) #227
                    time.sleep(0.2)            #228
                elif -20 >= object_angle > -90: #229
                    AGC.runActionGroup(go_turn_left) #230
                    time.sleep(0.2) #231
                
                elif line_centerx - x_center > 15: #233
                    AGC.runAction(right_move) #234
                elif line_centerx - x_center < -15: #235
                    AGC.runAction(left_move) #236
                
                elif 3 < object_angle < 20: #238
                    AGC.runActionGroup(turn_right) #239
                    time.sleep(0.2)            #240
                elif -5 > object_angle > -20: #241
                    AGC.runActionGroup(turn_left) #242
                    time.sleep(0.2) #243
                    
                elif 300 <= object_center_y < 430:    #在中心(in the center) #245
                    AGC.runActionGroup(go_forward_one_step) #246
                    time.sleep(0.2) #247
                    
                elif object_center_y >= 430: #位置靠近，可以跨栏或者上下台阶(the positions are close, allowing for stepping over or stepping onto/down from the platform) #249
                    time.sleep(0.5) #250
                    if object_center_y >= 430: #251
                        board.set_buzzer(1900, 0.1, 0.9, 1) #252
                        AGC.runActionGroup(go_forward_one_step) #前进一步(take one step forward) #253
                        time.sleep(0.5) #254
                        AGC.runActionGroup(go_forward_one_step) #前进一步(take one step forward) #255
                        time.sleep(0.5) #256
                        
                        if items == 'hurdles':# 跨栏(hurdles) #258
                            
                            AGC.runActionGroup('hurdles') #260
                            skip_st = True #261
                            strp_up = True #262
                            items = None #263
                        elif items == 'stairway': #264
                            if strp_up: # 上台阶(go up stairs) #265
                                AGC.runActionGroup('climb_stairs') #266
                                strp_up = False #267
                            else: # 下台阶(go down stairs) #268
                                for i in range(2): #269
                                    AGC.runActionGroup(go_forward_one_step) #270
                                time.sleep(0.2) #271
                                AGC.runActionGroup('down_floor') #272
                                strp_up = True #273
                            items = None #274
                            skip_st = True #275
                        time.sleep(0.5) #276
                        object_center_y = -1 #277
                    
                else: #279
                    time.sleep(0.01) #280
                    
            elif line_st and line_centerx != 8888: #巡线(line following) #282
                if abs(line_centerx - x_center) <= 20: #283
                    AGC.runAction(go_forward) #284
                    time.sleep(0.2) #285
                elif line_centerx - x_center > 20: #286
                    AGC.runAction(go_turn_right) #287
                    time.sleep(0.2) #288
                elif line_centerx - x_center < -20: #289
                    AGC.runAction(go_turn_left) #290
                    time.sleep(0.2) #291
                else: #292
                    time.sleep(0.01) #293
            else: #294
                time.sleep(0.01) #295
        else: #296
            time.sleep(0.01) #297
                
            
#作为子线程开启(start as a sub-thread) #300
th = threading.Thread(target=move) #301
th.daemon = True #302
th.start() #303


def run(img): #306
    global skip_st, line_st, strp_st, fence_st #307
    global object_left_x, object_right_x, skip, items #308
    global object_center_y, object_angle, line_centerx #309
    
    img_copy = img.copy() #311
    img_h, img_w = img.shape[:2] #312
    
    # 巡线(line following) #314
    line_centerx = line_patrol(img, img_copy, target_color = 'black')  #315
    
    # 跨栏(hurdles) #317
    if skip == 1: #318
        object_left_x, object_right_x, object_center_y, object_angle = color_identify(img, img_copy, target_color = 'blue') #319
        print('hurdles',object_left_x, object_right_x, object_center_y, object_angle)# 打印位置角度参数(print position angle parameter) #320
        if object_center_y >= 260:#准备跨栏，关闭错帧检测(prepare for hurdles, disable error frame detection) #321
            skip_st = False #322
            items = 'hurdles' #323
        elif object_center_y == -1: #324
            skip_st = True #325

    # 台阶(stair) #327
    elif skip == 2: #328
        object_left_x, object_right_x, object_center_y, object_angle = color_identify(img, img_copy, target_color = 'red') #329
        print('stairway',object_left_x, object_right_x, object_center_y, object_angle)# 打印位置角度参数(print position angle parameter) #330
        if object_center_y >= 260:#准备上台阶，关闭错帧检测(prepare to ascend stairs, disable error frame detection) #331
            skip_st = False #332
            items = 'stairway' #333
        elif object_center_y == -1: #334
            skip_st = True #335
               
    if skip_st: # 设置跨栏和台阶错帧检测(enable error frame detection for hurdles and stairs) #337
        skip += 1  #338
        if skip > 2: #339
            skip = 1 #340
        
    return img_copy #342

if __name__ == '__main__': #344
    
    from hiwonder.CalibrationConfig import * #346
    init()    #347
    
    #加载参数(load parameters) #349
    param_data = np.load(calibration_param_path + '.npz') #350
    mtx = param_data['mtx_array'] #351
    dist = param_data['dist_array'] #352
    newcameramtx, roi_area = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #353
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #354

    
    camera = cv2.VideoCapture(-1) #357
    AGC.runAction('stand_slow') #358
    switch = True #359
    while True: #360
        ret,img = camera.read() #361
        if ret: #362
            frame = img.copy() #363
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #364
            
            Frame = run(frame)            #366
            cv2.imshow('Frame', Frame) #367
            key = cv2.waitKey(1) #368
            if key == 27: #369
                break #370
        else: #371
            time.sleep(0.01) #372
    camera.camera_close() #373
    cv2.destroyAllWindows() #374

