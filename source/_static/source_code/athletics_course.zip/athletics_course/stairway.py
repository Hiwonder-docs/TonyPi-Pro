#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\11.拓展课程之田径运动课程\第2课 爬台阶(4.Advanced Lessons\11.Athletics Sport Lesson\Lesson2 Go Up and Down Stair) #3
import os #4
import sys #5
import cv2 #6
import time #7
import math #8
import threading #9
import numpy as np #10
import hiwonder.ros_robot_controller_sdk as rrc #11
from hiwonder.Controller import Controller #12
import hiwonder.PID as PID #13
import hiwonder.Misc as Misc #14
import hiwonder.Camera as Camera #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17

if sys.version_info.major == 2: #19
    print('Please run this program with python3!') #20
    sys.exit(0) #21

# 上下台阶(go up and down stair) #23

go_forward = 'go_forward' #25
go_forward_one_step = 'go_forward_one_step' #26
go_forward_one_small_step = 'go_forward_one_small_step' #27
turn_right = 'turn_right_small_step_a' #28
turn_left  = 'turn_left_small_step_a'         #29
left_move = 'left_move_20' #30
right_move = 'right_move_20' #31
go_turn_right = 'turn_right' #32
go_turn_left = 'turn_left' #33

from hiwonder.CalibrationConfig import *     #35
#加载参数(load parameters) #36
param_data = np.load(calibration_param_path + '.npz') #37
mtx = param_data['mtx_array'] #38
dist = param_data['dist_array'] #39
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #40
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #41

lab_data = None #43
servo_data = None #44
def load_config(): #45
    global lab_data, servo_data #46
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #48
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #49

board = rrc.Board() #51
ctl = Controller(board) #52

# 初始位置(initial position) #54
def initMove(): #55
    ctl.set_pwm_servo_pulse(1,servo_data['servo1'],500) #56
    ctl.set_pwm_servo_pulse(2,servo_data['servo2'],500)    #57

object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #59
strp_up = True #60
# 变量重置(variable reset) #61
def reset(): #62
    global object_left_x, object_right_x #63
    global object_center_y, object_angle,strp_up #64
    
    strp_up = True #66
    object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #67
    

# app初始化调用(app initialization calling) #70
def init(): #71
    print("Stairway Init") #72
    load_config() #73
    initMove() #74
    AGC.runAction('stand_slow') #75

robot_is_running = False #77
# app开始玩法调用(app start program calling) #78
def start(): #79
    global robot_is_running #80
    reset() #81
    robot_is_running = True #82
    print("Stairway Start") #83

# app停止玩法调用(app stop program calling) #85
def stop(): #86
    global robot_is_running #87
    robot_is_running = False #88
    print("Stairway Stop") #89

# app退出玩法调用(app exit program calling) #91
def exit(): #92
    global robot_is_running #93
    robot_is_running = False #94
    AGC.runActionGroup('stand_slow') #95
    print("Stairway Exit") #96


# 找出面积最大的轮廓(find out the contour with the maximal area) #99
# 参数为要比较的轮廓的列表(the list is the contour to be compared) #100
def getAreaMaxContour(contours, area_min=10): #101
    contour_area_temp = 0 #102
    contour_area_max = 0 #103
    area_max_contour = None #104

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #106
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #107
        if contour_area_temp > contour_area_max: #108
            contour_area_max = contour_area_temp #109
            if contour_area_temp >= area_min:  # 只有在面积大于设定值时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than the set value, the contour with the maximum area is considered valid to filter out interference) #110
                area_max_contour = c #111

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #113

size = (640, 480) #115
# 色块定位视觉处理函数(color block positioning vision processing function) #116
def color_identify(img, img_draw, target_color = 'blue'): #117
    
    img_w = img.shape[:2][1] #119
    img_h = img.shape[:2][0] #120
    img_resize = cv2.resize(img, (size[0], size[1]), interpolation = cv2.INTER_CUBIC) #121
    GaussianBlur_img = cv2.GaussianBlur(img_resize, (3, 3), 3)#高斯模糊(Gaussian blur) #122
    frame_lab = cv2.cvtColor(GaussianBlur_img, cv2.COLOR_BGR2LAB) #将图像转换到LAB空间(convert the image to LAB space) #123
    frame_mask = cv2.inRange(frame_lab, #124
                                 (lab_data[target_color]['min'][0], #125
                                  lab_data[target_color]['min'][1], #126
                                  lab_data[target_color]['min'][2]), #127
                                 (lab_data[target_color]['max'][0], #128
                                  lab_data[target_color]['max'][1], #129
                                  lab_data[target_color]['max'][2]))  #对原图像和掩模进行位运算(operate bitwise operation to original image and mask) #130
    opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))#开运算(opening operation) #131
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((3,3),np.uint8))#闭运算(closing operation) #132
    contours = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #找出所有外轮廓(find out all the bounding contours) #133
    areaMax_contour = getAreaMaxContour(contours, area_min=50)[0] #找到最大的轮廓(find out the contour with the maximal area) #134

    left_x, right_x, center_y, angle = -1, -1, -1, 0 #136
    if areaMax_contour is not None: #137
        
        down_x = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[0] #139
        down_y = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1] #140

        left_x = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[0] #142
        left_y = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[1] #143

        right_x = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[0] #145
        right_y = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[1] #146
        
        if pow(down_x - left_x, 2) + pow(down_y - left_y, 2) > pow(down_x - right_x, 2) + pow(down_y - right_y, 2): #148
            left_x = int(Misc.map(left_x, 0, size[0], 0, img_w)) #149
            left_y = int(Misc.map(left_y, 0, size[1], 0, img_h))   #150
            right_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #151
            right_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #152
        else: #153
            left_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #154
            left_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #155
            right_x = int(Misc.map(right_x, 0, size[0], 0, img_w)) #156
            right_y = int(Misc.map(right_y, 0, size[1], 0, img_h)) #157

        center_y = int(Misc.map((areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1], 0, size[1], 0, img_h)) #159
        angle = int(math.degrees(math.atan2(right_y - left_y, right_x - left_x))) #160
        
        cv2.line(img_draw, (left_x, left_y), (right_x, right_y), (255, 0, 0), 2) #162
            
    return left_x, right_x, center_y, angle       #164


#机器人跟踪线程(robot tracking thread) #167
def move(): #168
    global strp_up #169
    global object_center_y #170
    
    centreX = 320 # 物体在机器人正前方中心点对应的像素坐标,由于安装误差，物体在画面中心并不对应物体就在机器人中心点(the pixel coordinates of the object corresponding to the center point directly in front of the robot may not align with the actual center of the object due to installation errors) #172
    
    while True: #174
        if robot_is_running: #175
            if object_center_y >= 0:  #检测到台阶,进行位置微调(detected stair, perform positional fine-tuning) #176
                object_x = object_left_x + (object_right_x - object_left_x)/2 #177
                
                if object_center_y < 320 and abs(object_x - centreX) < 150:  #快速靠近(approach quickly) #179
                    AGC.runActionGroup(go_forward) #180
                    time.sleep(0.2) #181
                
                elif 20 <= object_angle < 90:  #角度调整(angle adjustment) #183
                    AGC.runActionGroup(go_turn_right) #184
                    time.sleep(0.2)            #185
                elif -20 >= object_angle > -90: #186
                    AGC.runActionGroup(go_turn_left) #187
                    time.sleep(0.2) #188
                    
                elif object_x - centreX > 15: #左右调整(adjust left and right) #190
                    AGC.runActionGroup(right_move) #191
                elif object_x - centreX < -15: #192
                    AGC.runActionGroup(left_move) #193
                
                elif 3 < object_angle < 20:   #角度微调(adjust the angle slightly) #195
                    AGC.runActionGroup(turn_right) #196
                    time.sleep(0.2)            #197
                elif -5 > object_angle > -20: #198
                    AGC.runActionGroup(turn_left) #199
                    time.sleep(0.2) #200
                    
                elif 320 <= object_center_y < 450:   #在中心(in the center) #202
                    AGC.runActionGroup(go_forward_one_step) #203
                    time.sleep(0.2) #204
                    
                elif object_center_y >= 450: #位置靠近，可以跨栏或者上下台阶(approaching position, ready to hurdle or ascend/descend stairs) #206
                    time.sleep(0.8) #207
                    if object_center_y >= 450: #208
                        board.set_buzzer(1900, 0.1, 0.9, 1)  #209
                        for i in range(2): #210
                            AGC.runActionGroup(go_forward_one_small_step) #前进一小步(take a small step forward) #211
                            time.sleep(0.5) #212
                    
                        if strp_up: # 上台阶(go up stair) #214
                            AGC.runActionGroup('climb_stairs') #215
                            strp_up = False #216
                        else:       # 下台阶(go down stair) #217
                            for i in range(2): #218
                                AGC.runActionGroup(go_forward_one_small_step) #前进一步(take a small step forward) #219
                            time.sleep(0.5) #220
                            AGC.runActionGroup('down_floor') #221
                            strp_up = True #222
                        time.sleep(0.5) #223
                        object_center_y = -1 #224
                    
                else: #226
                    time.sleep(0.01) #227
            else: #228
                time.sleep(0.01) #229
        else: #230
            time.sleep(0.01) #231
                
            
#作为子线程开启(start as a sub-thread) #234
th = threading.Thread(target=move) #235
th.daemon = True  #236
th.start() #237


def run(img): #240
    global object_left_x, object_right_x #241
    global object_center_y, object_angle #242

    img_copy = cv2.remap(img, mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #244
    
    if not robot_is_running: #246
        return img_copy #247
    
    # 上下台阶(go up and down stair) #249
    object_left_x, object_right_x, object_center_y, object_angle = color_identify(img_copy.copy(), img_copy, target_color = 'red') #250
    print('stairway',object_left_x, object_right_x, object_center_y, object_angle)# 打印位置角度参数 #251
            
        
    return img_copy #254

if __name__ == '__main__': #256
    
    my_camera = Camera.Camera() #258
    my_camera.camera_open() #259
    
    init() #261
    start() #262
    
    while True: #264
        ret,img = my_camera.read() #265
        if ret: #266
            frame = img.copy() #267
            Frame = run(frame)            #268
            cv2.imshow('Frame', Frame) #269
            key = cv2.waitKey(1) #270
            if key == 27: #271
                break #272
        else: #273
            time.sleep(0.01) #274
    my_camera.camera_close() #275
    cv2.destroyAllWindows() #276

