#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\11.拓展课程之田径运动课程\第3课 跨栏运动(4.Advanced Lessons\11.Athletics Sport Lesson\Lesson3 Hurdle Clearing) #3
import os #4
import sys #5
import cv2 #6
import time #7
import math #8
import threading #9
import numpy as np #10

import hiwonder.PID as PID #12
import hiwonder.Misc as Misc #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.Camera as Camera #16
import hiwonder.ActionGroupControl as AGC #17
import hiwonder.yaml_handle as yaml_handle #18

if sys.version_info.major == 2: #20
    print('Please run this program with python3!') #21
    sys.exit(0) #22

# 跨栏避障(hurdle clearing) #24

go_forward = 'go_forward' #26
go_forward_one_step = 'go_forward_one_step' #27
go_forward_one_small_step = 'go_forward_one_small_step' #28
turn_right = 'turn_right_small_step_a' #29
turn_left  = 'turn_left_small_step_a'         #30
left_move = 'left_move_20' #31
right_move = 'right_move_20' #32
go_turn_right = 'turn_right' #33
go_turn_left = 'turn_left' #34

from hiwonder.CalibrationConfig import *     #36
#加载参数(load parameters) #37
param_data = np.load(calibration_param_path + '.npz') #38
mtx = param_data['mtx_array'] #39
dist = param_data['dist_array'] #40
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #41
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #42

lab_data = None #44
servo_data = None #45
def load_config(): #46
    global lab_data, servo_data #47
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #49
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #50

board = rrc.Board() #52
ctl = Controller(board) #53

# 初始位置(initial position) #55
def initMove(): #56
    ctl.set_pwm_servo_pulse(1,servo_data['servo1'],500) #57
    ctl.set_pwm_servo_pulse(2,servo_data['servo2'],500)    #58

object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #60

# 变量重置(variable reset) #62
def reset(): #63
    global object_left_x, object_right_x #64
    global object_center_y, object_angle  #65
    
    object_left_x, object_right_x, object_center_y, object_angle = -2, -2, -2, 0 #67

# app初始化调用(app initialization calling) #69
def init(): #70
    print("Hurdles Init") #71
    load_config() #72
    initMove() #73
    AGC.runAction('stand_slow') #74

robot_is_running = False #76
# app开始玩法调用(app start program calling) #77
def start(): #78
    global robot_is_running #79
    reset() #80
    robot_is_running = True #81
    print("Hurdles Start") #82

# app停止玩法调用(app stop program calling) #84
def stop(): #85
    global robot_is_running #86
    robot_is_running = False #87
    print("Hurdles Stop") #88

# app退出玩法调用(app exit program calling) #90
def exit(): #91
    global robot_is_running #92
    robot_is_running = False #93
    AGC.runActionGroup('stand_slow') #94
    print("Hurdles Exit") #95


# 找出面积最大的轮廓(find out the contour with the maximal area) #98
# 参数为要比较的轮廓的列表(the list is the contour to be compared) #99
def getAreaMaxContour(contours, area_min=10): #100
    contour_area_temp = 0 #101
    contour_area_max = 0 #102
    area_max_contour = None #103

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #105
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #106
        if contour_area_temp > contour_area_max: #107
            contour_area_max = contour_area_temp #108
            if contour_area_temp >= area_min:  # 只有在面积大于设定值时，最大面积的轮廓才是有效的，以过滤干扰(only when the area is greater than the set value, the contour with the maximum area is considered valid to filter out interference) #109
                area_max_contour = c #110

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #112


size = (640, 480) #115

# 色块定位视觉处理函数(color block positioning vision processing function) #117
def color_identify(img, img_draw, target_color = 'blue'): #118
    
    img_w = img.shape[:2][1] #120
    img_h = img.shape[:2][0] #121
    img_resize = cv2.resize(img, (size[0], size[1]), interpolation = cv2.INTER_CUBIC) #122
    GaussianBlur_img = cv2.GaussianBlur(img_resize, (3, 3), 0)#高斯模糊(Gaussian blur) #123
    frame_lab = cv2.cvtColor(GaussianBlur_img, cv2.COLOR_BGR2LAB) #将图像转换到LAB空间(convert the image to LAB space) #124
    frame_mask = cv2.inRange(frame_lab, #125
                                 (lab_data[target_color]['min'][0], #126
                                  lab_data[target_color]['min'][1], #127
                                  lab_data[target_color]['min'][2]), #128
                                 (lab_data[target_color]['max'][0], #129
                                  lab_data[target_color]['max'][1], #130
                                  lab_data[target_color]['max'][2]))  #对原图像和掩模进行位运算(operate bitwise operation to original image and mask) #131
    opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((3,3),np.uint8))#开运算(opening operation) #132
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((3,3),np.uint8))#闭运算(closing operation) #133
    contours = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #找出所有外轮廓(find out all the bounding contours) #134
    areaMax_contour = getAreaMaxContour(contours, area_min=50)[0] #找到最大的轮廓(find out the contour with the maximal area) #135

    left_x, right_x, center_y, angle = -1, -1, -1, 0 #137
    if areaMax_contour is not None: #138
        
        down_x = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[0] #140
        down_y = (areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1] #141

        left_x = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[0] #143
        left_y = (areaMax_contour[areaMax_contour[:,:,0].argmin()][0])[1] #144

        right_x = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[0] #146
        right_y = (areaMax_contour[areaMax_contour[:,:,0].argmax()][0])[1] #147
        
        if pow(down_x - left_x, 2) + pow(down_y - left_y, 2) > pow(down_x - right_x, 2) + pow(down_y - right_y, 2): #149
            left_x = int(Misc.map(left_x, 0, size[0], 0, img_w)) #150
            left_y = int(Misc.map(left_y, 0, size[1], 0, img_h))   #151
            right_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #152
            right_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #153
        else: #154
            left_x = int(Misc.map(down_x, 0, size[0], 0, img_w)) #155
            left_y = int(Misc.map(down_y, 0, size[1], 0, img_h)) #156
            right_x = int(Misc.map(right_x, 0, size[0], 0, img_w)) #157
            right_y = int(Misc.map(right_y, 0, size[1], 0, img_h)) #158

        center_y = int(Misc.map((areaMax_contour[areaMax_contour[:,:,1].argmax()][0])[1], 0, size[1], 0, img_h)) #160
        angle = int(math.degrees(math.atan2(right_y - left_y, right_x - left_x))) #161
        
        cv2.line(img_draw, (left_x, left_y), (right_x, right_y), (255, 0, 0), 2)      #163
            
    return left_x, right_x, center_y, angle       #165


#机器人跟踪线程(robot tracking thread) #168
def move(): #169
    global object_center_y #170
    
    centreX = 350 # 物体在机器人正前方中心点对应的像素坐标,由于安装误差，物体在画面中心并不对应物体就在机器人中心点(the pixel coordinates of the object corresponding to the center point directly in front of the robot may not align with the actual center of the object due to installation errors) #172
    
    while True: #174
        if robot_is_running: #175
            if object_center_y >= 0:  #检测到跨栏,进行位置微调(detected hurdle, perform positional fine-tuning) #176
                
                object_x = object_left_x + (object_right_x - object_left_x)/2 #178
                
                if object_center_y < 320 and abs(object_x - centreX) < 150:  #离栏杆比较远，快速靠近(the railing is quite far away, move quickly to approach) #180
                    AGC.runActionGroup(go_forward) #181
                    time.sleep(0.2) #182
                
                elif 20 <= object_angle < 90:  #角度调整(angle adjustment) #184
                    AGC.runActionGroup(go_turn_right) #185
                    time.sleep(0.2)            #186
                elif -20 >= object_angle > -90: #187
                    AGC.runActionGroup(go_turn_left) #188
                    time.sleep(0.2) #189
                    
                elif object_x - centreX > 15: #左右调整，让机器人正对栏杆(adjust left and right to align the robot directly with the railing) #191
                    AGC.runActionGroup(right_move) #192
                elif object_x - centreX < -15: #193
                    AGC.runActionGroup(left_move) #194
                
                elif 3 < object_angle < 20:   #角度微调(adjust the angle slightly) #196
                    AGC.runActionGroup(turn_right) #197
                    time.sleep(0.2)            #198
                elif -5 > object_angle > -20: #199
                    AGC.runActionGroup(turn_left) #200
                    time.sleep(0.2) #201
                    
                elif 320 <= object_center_y < 450:   #慢慢靠近栏杆(approach the railing slowly) #203
                    AGC.runActionGroup(go_forward_one_step) #204
                    time.sleep(0.5) #205
                    
                elif object_center_y >= 450: #位置靠近，跨栏(approach the position, hurdle the obstacle) #207
                    time.sleep(0.8) #208
                    if object_center_y >= 450: #209
                        board.set_buzzer(1900, 0.1, 0.9, 1) #210
                        for i in range(3): #211
                            AGC.runActionGroup(go_forward_one_small_step) #前进一小步(take a small step forward) #212
                            time.sleep(0.5) #213
                        
                        AGC.runActionGroup('hurdles') #215
                        time.sleep(0.5) #216
                        object_center_y = -1 #217
                    
                else: #219
                    time.sleep(0.01) #220
            else: #221
                time.sleep(0.01) #222
        else: #223
            time.sleep(0.01) #224
                
            
#作为子线程开启(start as a sub-thread) #227
th = threading.Thread(target=move) #228
th.daemon = True #229
th.start() #230


def run(img): #233
    global object_left_x, object_right_x #234
    global object_center_y, object_angle #235
    
    img_copy = cv2.remap(img, mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #237
    
    if not robot_is_running: #239
        return img_copy #240
    
    # 跨栏(hurdles) #242
    object_left_x, object_right_x, object_center_y, object_angle = color_identify(img_copy.copy(), img_copy, target_color = 'blue') #243
    print('hurdles',object_left_x, object_right_x, object_center_y, object_angle)# 打印位置角度参数(print position angle parameter) #244
        
    return img_copy #246

if __name__ == '__main__': #248

    my_camera = Camera.Camera() #250
    my_camera.camera_open() #251

    init() #253
    start() #254
    
    while True: #256
        ret,img = my_camera.read() #257
        if ret: #258
            frame = img.copy() #259
            Frame = run(frame)            #260
            cv2.imshow('Frame', Frame) #261
            key = cv2.waitKey(1) #262
            if key == 27: #263
                break #264
        else: #265
            time.sleep(0.01) #266
    my_camera.camera_close() #267
    cv2.destroyAllWindows() #268

