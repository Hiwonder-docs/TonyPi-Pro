#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/09/21
import os, sys, inspect
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from common.config import *
import hiwonder.ActionGroupControl as AGC
from hiwonder.Controller import Controller
import hiwonder.ros_robot_controller_sdk as rrc

ctl = AGC.ctl

def stand():
    AGC.runActionGroup('stand')

def init():
    ctl.set_pwm_servo_pulse(1, 1500, 500)
    ctl.set_pwm_servo_pulse(2, 1500, 500)
    AGC.runActionGroup('stand')

def forward():
    AGC.runActionGroup('go_forward')

def back():
    AGC.runActionGroup('back_fast')

def move_left():
    AGC.runActionGroup('left_move_fast')

def move_right():
    AGC.runActionGroup('right_move_fast')

def turn_left():
    AGC.runActionGroup('turn_left')

def turn_right():
    AGC.runActionGroup('turn_right')

def bow():
    AGC.runActionGroup('bow')

def wave():
    AGC.runActionGroup('wave')
    
def twist():
    AGC.runActionGroup('twist')

def celebrate():
    AGC.runActionGroup('chest')

def squat():
    AGC.runActionGroup('squat')

def right_shot():
    AGC.runActionGroup('right_shot_fast')

def left_shot():
    AGC.runActionGroup('left_shot_fast')

def sit_ups():
    AGC.runActionGroup('sit_ups')

def wing_chun():
    AGC.runActionGroup('wing_chun')

frame = inspect.stack()[1]
caller_file = frame.filename
functions_code_path = os.path.dirname(os.path.abspath(caller_file))
def kick_ball(color='red'):
    os.system('python3 ' + os.path.join(functions_code_path, 'functions', 'kick_ball.py') + ' ' + color)

def athletics_perform():
    os.system('python3 ' + os.path.join(functions_code_path, 'functions', 'athletics_perform.py'))

if __name__ == '__main__':
    pass
