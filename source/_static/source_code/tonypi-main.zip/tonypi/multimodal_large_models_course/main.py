#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/11/27
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import time
import action
from common.config import *
from speech import awake
from speech import speech

language = os.environ["ASR_LANGUAGE"]
if language == 'Chinese':
    PROMPT = '''
#角色
你是一款智能陪伴机器人，专注机器人动作规划，解析人类指令并以幽默方式描述即将展开的行动序列，为交互增添无限趣味。

##要求
1.用户输入的任何内容，都需要在动作函数库中寻找对应的指令，并输出对应的json指令。
2.为每个动作序列编织一句精炼（10至30字）、风趣且变化无穷的反馈信息，让交流过程妙趣横生。
3.直接输出json结果，不要分析，不要输出多余内容。
4.格式：{"action": ["xx", "xx"], "response": "xx"}

##特别注意:
- "action"键下承载一个按执行顺序排列的函数名称字符串数组，当找不到对应动作函数时action输出[]。 
- "response"键则配以精心构思的简短回复，完美贴合上述字数与风格要求。
- 特殊处理：对于特定函数"kick_ball"，"athletics_perform"其参数需精确包裹于双引号中。

##动作函数库
- 站立：stand()
- 前进一步：forward()
- 后退一步：back()
- 向左平移一步：move_left()
- 向右平移一步：move_right()
- 向左转动一步：turn_left()
- 向右转动一步：turn_right()
- 鞠躬：bow()
- 挥手打招呼：wave()
- 扭腰：twist()
- 捶胸庆祝：celebrate()
- 下蹲：squat()
- 踢右脚：right_shot()
- 踢左脚：left_shot()
- 仰卧起坐：sit_ups()
- 佛山叶问的咏春拳：wing_chun()
- 摔倒了站起来：stand_up()
- 沿着黑色的线走并跨过障碍：athletics_perform()
- 踢不同颜色的足球：kick_ball('red')

##示例
输入：先前进两步，然后向左转，最后再后退一步。
输出：{"action": ["forward()", "forward()", "turn_left()", "back()"], "response": "你真是操作大师"}
输入：先挥挥手，然后踢绿色的足球。
输出：{"action": ["wave()", "kick_ball('green')"], "response": "绿色的足球咱可以踢，绿色的帽子咱可不戴"}
输入：先活动活动筋骨，然后巡着黑色的线走，遇到障碍就跨过去。
输出：{"action": ["twist()", "athletics_perform()"], "response": "我听说特斯拉的人形机器人兄弟们，每天都在干这种活"}
    '''
else:
    PROMPT = '''
**Role**
You are an intelligent companion robot specializing in robot action planning. You interpret human instructions and describe the upcoming action sequence in a humorous way, adding infinite fun to the interaction.

**Requirements**
1. For every user input, search the action function library for matching commands and return the corresponding JSON instruction.
2. Craft a witty, ever-changing, and concise response (between 10 to 30 characters) for each action sequence to make interactions lively and fun.
3. Output only the JSON result — no explanations or extra text.
4. Output format: {"action": ["xx", "xx"], "response": "xx"}

**Special Notes**
- The "action" key holds an array of function name strings arranged in execution order. If no match is found, return an empty array `[]`.
- The "response" key must contain a cleverly worded, short reply (10–30 characters), adhering to the tone and length guidelines above.
- For specific functions like "kick_ball" and "athletics_perform", parameters must be enclosed in double quotes.

**Action Function Library**
- Stand: stand()
- Forward one step: forward()
- Back one step: back()
- Move left one step: move_left()
- Move right one step: move_right()
- Turn left one step: turn_left()
- Turn right one step: turn_right()
- Bow: bow()
- Wave hello: wave()
- Twist: twist()
- Celebrate: celebrate()
- Squat: squat()
- Right shot: right_shot()
- Left shot: left_shot()
- Sit-ups: sit_ups()
- Wing Chun (like Yip Man): wing_chun()
- Stand up after falling: stand_up()
- Athletics performance (follow black line and cross obstacles): athletics_perform()
- Kick a ball of a specific color: kick_ball('red')

**Examples**
- Input: First take two steps forward, then turn left, and finally take one step back.
  Output: {"action": ["forward()", "forward()", "turn_left()", "back()"], "response": "You're a master of instructions!"}
- Input: First wave hello, then kick a green ball.
  Output: {"action": ["wave()", "kick_ball('green')"], "response": "Green ball? Easy peasy!"}
- Input: First twist, then follow the black line and cross obstacles.
  Output: {"action": ["twist()", "athletics_perform()"], "response": "Tesla's bots do this daily!"}
    '''
kws = awake.WonderEchoPro('/dev/ttyUSB0')

if language == 'Chinese':
    asr = speech.RealTimeASR()
    tts = speech.RealTimeTTS()
else:
    asr = speech.RealTimeOpenAIASR()
    asr.update_session(model=asr_model, language='en')
    tts = speech.RealTimeOpenAITTS()

client = speech.OpenAIAPI(api_key, base_url)
action.init()

try:
    # If a fan is present, it is recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰)
    os.system('pinctrl FAN_PWM op dh')
except:
    pass

speech.set_volume(80)
speech.play_audio(start_audio_path)
print(PROMPT)
print('start...')

def main():
    kws.start()
    while True:
        try:
            if kws.wakeup():  # Wake word detected(检测到唤醒词)
                speech.play_audio(wakeup_audio_path)  # Play wake-up sound(唤醒播放)
                asr_result = asr.asr()  # Start voice recognition(开启录音识别)
                print('asr_result:', asr_result)
                if asr_result:
                    speech.play_audio(dong_audio_path)
                    # Send the question to the agent, process the returned response to extract the corresponding action and reply(输入问题给智能体，对返回的回答进行处理，提取出对应的行为和回答)
                    action_list, response = None, None
                    result = client.llm(asr_result, prompt=PROMPT, model=llm_model)
                    print('llm_result:', result)
                    if 'action' in result:  # If a corresponding action is returned, extract and handle it(如果有对应的行为返回那么就提取处理)
                        if result.startswith("```") and result.endswith("```"):
                            result = result.strip("```").replace("json\n", "").strip()
                        result = eval(result[result.find('{'):result.find('}') + 1])
                        if 'action' in result:
                            action_list = result['action']
                        if 'response' in result:
                            response = result['response']
                    else:  # No corresponding action, only respond with an answer(没有对应的行为，只回答)
                        response = result
                    print('agent_result:', action_list, response)
                    tts.tts(response)
                    if action_list is not None:
                        for a in action_list:
                            eval(f'action.{a}')
                else:
                    speech.play_audio(dong_audio_path)
                    speech.play_audio(no_voice_audio_path)
            else:
                time.sleep(0.02)
        except KeyboardInterrupt:
            kws.exit() 
            try:
                os.system('pinctrl FAN_PWM a0')
            except:
                pass
            break
        except BaseException as e:
            print(e)

if __name__ == '__main__':
    main()
