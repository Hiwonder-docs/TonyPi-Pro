#!/usr/bin/python3
# coding=utf8
import sys
import cv2
import time
import math
import random
import threading
import numpy as np
import hiwonder.Misc as Misc
import hiwonder.ros_robot_controller_sdk as rrc
from hiwonder.Controller import Controller
import hiwonder.ActionGroupControl as AGC
import hiwonder.yaml_handle as yaml_handle

board = rrc.Board()
ctl = Controller(board)

CENTER_X = 343  # Central Parameters(中心参数)
target_color = None
step = 1
running = True
object_center_x, object_center_y, object_angle = -2, -2, 0

# Action Group Names for Object Handling (搬运用到的动作组名称)
go_forward = 'go_forward'
back = 'back_fast'
turn_left = 'turn_left_small_step'
turn_right = 'turn_right_small_step'
left_move = 'left_move'
right_move = 'right_move'
left_move_large = 'left_move_40'
right_move_large = 'right_move_40'

range_rgb = {
    'red': (0, 0, 255),
    'blue': (255, 0, 0),
    'green': (0, 255, 0),
    'black': (0, 0, 0),
    'white': (255, 255, 255),
}

lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path)
servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)
ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500)
ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500)

servo1 = servo_data['servo1']
servo2 = servo_data['servo2']

# initialize the timestamp for starting the timer (初始化开始计时的时间戳)
t1 = 0

# initialize the step size for servo movement in the horizontal and vertical directions (初始化舵机移动水平方向和垂直方向的步长)
d_x = 20
d_y = 20

# initialize the main step (when the ball is detected) and sub-step (when the ball is not detected) (初始化主步骤step（检测到球时的情况）和子步骤step_（未检测到球时的情况）)
step_ = 1

# set servo position(设置舵机位置)
x_dis = servo_data['servo2']
y_dis = servo_data['servo1']

# initialize the flag variable for starting the timer(初始化开始计时的标志量)
start_count= True

# Find the contour with the largest area(找出面积最大的轮廓)
# The parameter is a list of contours to compare(参数为要比较的轮廓的列表)
def getAreaMaxContour(contours, min_area=300):
    contour_area_max = 0
    area_max_contour = None

    for c in contours:  # Iterate through all contours(历遍所有轮廓)
        contour_area_temp = math.fabs(cv2.contourArea(c))  # Calculate contour area(计算轮廓面积)
        if contour_area_temp > contour_area_max:
            contour_area_max = contour_area_temp
            if contour_area_temp >= min_area:  # Filter out noise/interference(过滤干扰)
                area_max_contour = c

    return area_max_contour, contour_area_max  # Return the largest contour(返回最大的轮廓)


# Red, green, and blue color detection(红绿蓝颜色识别)
size = (320, 240)
def color_detect(img, box_color):
    img_h, img_w = img.shape[:2]

    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST)
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # Convert the image to LAB color space（将图像转换到LAB空间）

    center_x, center_y, angle = -1, -1, 0
    for i in lab_data:
        if i == box_color:
            frame_mask = cv2.inRange(frame_lab,
                                     (lab_data[i]['min'][0],
                                      lab_data[i]['min'][1],
                                      lab_data[i]['min'][2]),
                                     (lab_data[i]['max'][0],
                                      lab_data[i]['max'][1],
                                      lab_data[i]['max'][2]))  #perform bitwise operation to original image and mask （对原图像和掩模进行位运算)
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  # Erosion(腐蚀)
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  # Dilation(膨胀)
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # Find contours(找出轮廓)
            areaMaxContour, area_max = getAreaMaxContour(contours)  # Get the largest contour(找出最大轮廓)

            if area_max > 100 and areaMaxContour is not None:  # A valid largest contour was found(有找到最大面积)
                # print(areaMaxContour)
                rect = cv2.minAreaRect(areaMaxContour)  # Minimum bounding rectangle(最小外接矩形)
                angle_ = rect[2]

                box = np.int0(cv2.boxPoints(rect))  # Four vertices of the minimum bounding rectangle(最小外接矩形的四个顶点)
                for j in range(4):
                    box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w))
                    box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h))

                cv2.drawContours(img, [box], -1, (0, 255, 255), 2)  # Draw the rectangle formed by the four points(画出四个点组成的矩形)

                # Get the diagonal points of the rectangle(获取矩形的对角点)
                pt1_x, pt3_x = box[0, 0], box[2, 0]
                center_x_ = int((pt1_x + pt3_x) / 2)
                center_y_ = max(box[0, 1], box[1, 1], box[2, 1], box[3, 1])
                cv2.circle(img, (center_x_, center_y_), 5, (0, 255, 255), -1)  # Draw the center point(画出中心点)

                center_x, center_y, angle = center_x_, center_y_, angle_

    return center_x, center_y, angle

status = 'pick'
lock_servos = ''
stop_detect = False
LOCK_SERVOS = {'6': 600, '7': 870, '8': 0, '14': 400, '15': 130, '16': 1000}

action = None
change_action = True
finish = False
target_action = None
target_color = None
position = None
action_list = []
# Execute the action group (执行动作组)
def move():
    global step
    global status
    global target_color
    global lock_servos
    global stop_detect
    global running
    global object_center_x
    global target_action, target_color, position, action, change_action, action_list
    global x_dis, y_dis, start_count, step_, t1, d_x, d_y 
    time.sleep(1) 
    change = True
    while True:
        if running:
            if change_action:
                if action_list:
                    action = action_list[0]
                    target_action = list(action.keys())[0]
                    if target_action == 'place_random':
                        target_color = None
                    else:
                        if target_action != 'place_on':
                            target_color = action[target_action]
                            position = None
                        else:
                            target_color = action[target_action][0]
                            position = action[target_action][1]
                    change_action = False
                else:
                    running = False
            elif target_action is not None:
                if target_action == 'place_random':
                    AGC.runActionGroup(back, lock_servos=lock_servos, times=random.randint(5, 8))
                    n = random.randint(1, 10) > 5
                    if n > 5:
                        turn = random.randint(8, 14)
                        AGC.runActionGroup(turn_left, lock_servos=lock_servos, times=turn)
                    else:
                        turn = random.randint(8, 14)
                        AGC.runActionGroup(turn_right, lock_servos=lock_servos, times=turn)
                    AGC.runActionGroup('stand', lock_servos=lock_servos)
                    AGC.runActionGroup('put_down')
                    lock_servos = ''
                    AGC.runActionGroup(back, lock_servos=lock_servos, times=random.randint(5, 8))
                    if n > 5:
                        AGC.runActionGroup(turn_right, lock_servos=lock_servos, times=turn)
                    else:
                        AGC.runActionGroup(turn_left, lock_servos=lock_servos, times=turn)
                    step = 1
                    del action_list[0]
                    change_action = True
                else:
                    if abs(x_dis - servo2) < 40 and abs(y_dis - servo1) < 40 and object_center_x > 0: 
                        if step == 1:  # Adjust left and right to stay centered(左右调整，保持在正中)
                            if 0 < object_center_y <= 250:
                                AGC.runActionGroup(go_forward, lock_servos=lock_servos)
                            elif 475 < object_center_y:
                                AGC.runActionGroup(back, lock_servos=lock_servos, times=1)
                            else:
                                step = 2
                        elif step == 2:  # Approach the object (接近物体)
                            if 85 > object_angle > 45 and object_center_x - CENTER_X < -200:
                                AGC.runActionGroup(turn_left, lock_servos=lock_servos)
                            elif 5 < object_angle <= 45 and object_center_x - CENTER_X > 200:
                                AGC.runActionGroup(turn_right, lock_servos=lock_servos)
                            elif 470 < object_center_y:
                                AGC.runActionGroup(back, lock_servos=lock_servos, times=1)
                            elif object_center_x - CENTER_X > 200:  # Not centered; turn the robot one step to the right(不在中心，根据方向让机器人转向一步)
                                AGC.runActionGroup(right_move_large, lock_servos=lock_servos)
                            elif object_center_x - CENTER_X < -200:
                                AGC.runActionGroup(left_move_large, lock_servos=lock_servos)
                            elif 85 > object_angle > 45:
                                AGC.runActionGroup(turn_left, lock_servos=lock_servos)
                            elif 5 < object_angle <= 45:
                                AGC.runActionGroup(turn_right, lock_servos=lock_servos)
                            elif object_center_x - CENTER_X > 40:  # Not centered; make a smaller adjustment to the right(不在中心，根据方向让机器人转向一步)
                                AGC.runActionGroup(right_move_large, lock_servos=lock_servos)
                            elif object_center_x - CENTER_X < -40:
                                AGC.runActionGroup(left_move_large, lock_servos=lock_servos)
                            else:
                                step = 3
                        elif step == 3:
                            if 0 < object_center_y <= 380:
                                AGC.runActionGroup(go_forward, lock_servos=lock_servos)
                            elif 85 > object_angle > 45:
                                AGC.runActionGroup(turn_left, lock_servos=lock_servos)
                            elif 5 < object_angle <= 45:
                                AGC.runActionGroup(turn_right, lock_servos=lock_servos)
                            elif object_center_x - CENTER_X >= 40:  # Not centered; make a smaller adjustment to the right（不在中心，根据方向让机器人转向一步）
                                AGC.runActionGroup(right_move_large, lock_servos=lock_servos)
                            elif object_center_x - CENTER_X <= -40:
                                AGC.runActionGroup(left_move_large, lock_servos=lock_servos)
                            elif 20 <= object_center_x - CENTER_X < 40:  # Not centered; make a smaller adjustment to the right（不在中心，根据方向让机器人转向一步）
                                AGC.runActionGroup(right_move, lock_servos=lock_servos)
                            elif -40 < object_center_x - CENTER_X < -20:
                                AGC.runActionGroup(left_move, lock_servos=lock_servos)
                            else:
                                step = 4
                        elif step == 4:  # Approach the object (靠近物体)
                            if 380 < object_center_y <= 450:
                                AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos)
                                time.sleep(1)
                            elif 0 <= object_center_y <= 380:
                                AGC.runActionGroup(go_forward, lock_servos=lock_servos)
                                time.sleep(1)
                            elif 85 > object_angle > 45:
                                AGC.runActionGroup(turn_left, lock_servos=lock_servos)
                            elif 5 < object_angle <= 45:
                                AGC.runActionGroup(turn_right, lock_servos=lock_servos)
                            else:
                                if abs(object_center_x - CENTER_X) <= 40:
                                    if change:
                                        ctl.set_pwm_servo_pulse(1, servo1, 500)
                                        time.sleep(1)
                                        change = False
                                        step = 1
                                    else:
                                        stop_detect = True  #
                                        step = 5
                                else:
                                    step = 3
                        elif step == 5:  # Pick up the object (搬起物体)
                            if target_action == 'pick_up':
                                AGC.runActionGroup('go_forward_one_step', times=3)
                                AGC.runActionGroup('stand', lock_servos=lock_servos)
                                AGC.runActionGroup('move_up')
                                lock_servos = LOCK_SERVOS
                                step = 1
                                object_center_x = -2
                                stop_detect = False
                                del action_list[0]
                                change_action = True
                            elif target_action == 'pick_up_on':
                                AGC.runActionGroup('go_forward_one_step', times=1)
                                AGC.runActionGroup('stand', lock_servos=lock_servos)
                                AGC.runActionGroup('move_up2')
                                lock_servos = LOCK_SERVOS
                                step = 1
                                object_center_x = -2
                                stop_detect = False
                                del action_list[0]
                                change_action = True
                            elif target_action == 'place_on':
                                if position == 'left':
                                    AGC.runActionGroup('left_move_40', lock_servos=lock_servos, times=13)
                                    AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos)
                                    time.sleep(1)
                                    AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos)
                                    time.sleep(1)
                                    AGC.runActionGroup('stand', lock_servos=lock_servos)
                                    AGC.runActionGroup('put_down')
                                elif position == 'right':
                                    AGC.runActionGroup('right_move_40', lock_servos=lock_servos, times=10)
                                    AGC.runActionGroup('stand', lock_servos=lock_servos)
                                    AGC.runActionGroup('put_down')
                                else:
                                    AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos)
                                    time.sleep(1)
                                    AGC.runActionGroup('stand', lock_servos=lock_servos)
                                    AGC.runActionGroup('put_down2')

                                lock_servos = ''
                                object_center_x = 0
                                step = 1
                                del action_list[0]
                                change_action = True
                                AGC.runActionGroup(back, lock_servos=lock_servos, times=4)
                                AGC.runActionGroup('stand', lock_servos=lock_servos)
                    else:  # If the target is not found, turn the head and body to search(找不到目标时，转头，转身子来寻找)
                        if start_count:  # the flag variable for starting the timer is set to True (开始计时的标志变量为True)
                            start_count= False
                            t1 = time.time()    # record the current time and start the timer(记录当前的时间，开始计时)
                        else:
                            if time.time() - t1 > 0.5:
                                if step_ == 5:
                                    x_dis += d_x
                                    if abs(x_dis - servo_data['servo2']) < abs(d_x):
                                        AGC.runActionGroup(turn_right, lock_servos=lock_servos, times=5)
                                        step_ = 1
                                if step_ == 1 or step_ == 3:
                                    x_dis += d_x            
                                    if x_dis > servo_data['servo2'] + 400:
                                        if step_ == 1:
                                            step_ = 2
                                        d_x = -d_x
                                    elif x_dis < servo_data['servo2'] - 400:
                                        if step_ == 3:
                                            step_ = 4
                                        d_x = -d_x
                                elif step_ == 2 or step_ == 4:
                                    y_dis += d_y
                                    if y_dis > 1200:
                                        if step_ == 2:
                                            step_ = 3
                                        d_y = -d_y
                                    elif y_dis < servo_data['servo1']:
                                        if step_ == 4:                                
                                            step_ = 5
                                        d_y = -d_y
                                ctl.set_pwm_servo_pulse(1, y_dis, 20)
                                ctl.set_pwm_servo_pulse(2, x_dis, 20)
                                
                                time.sleep(0.02)
            else:
                time.sleep(0.01)
        else:
            time.sleep(0.01)

def run(img):
    global object_center_x, object_center_y, object_angle

    if not running or stop_detect or target_action is None:
        return img
    
    object_center_x, object_center_y, object_angle = color_detect(img, target_color)  # Returns center coordinates and angle(返回中心坐标，角度)
    # print(object_center_x, object_center_y, object_angle)
    return img

def pick_up(color):
    action_list.append({'pick_up': color})

def pick_up_on(color):
    action_list.append({'pick_up_on': color})

def place_on(color, position):
    action_list.append({'place_on': [color, position]})

def place_random():
    action_list.append({'place_random': ''})

if __name__ == '__main__':
    args = sys.argv[1:]
    for i in args:
        eval(i)
    print('action_list:', action_list)
    # Initiate the action thread(启动动作的线程)
    th = threading.Thread(target=move, daemon=True).start()
    cap = cv2.VideoCapture(-1)
    AGC.runActionGroup('stand')
    while running:
        ret, img = cap.read()
        if ret:
            frame = run(img)
            cv2.imshow('frame', frame)
            key = cv2.waitKey(1)
        else:
            time.sleep(0.01)
    cap.release()
    cv2.destroyAllWindows()
