#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/09/21
import math
import time
import smbus
import inspect
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from common.config import *
from speech import speech
from speech import awake
import hiwonder.ActionGroupControl as AGC
from hiwonder.Controller import Controller
import hiwonder.ros_robot_controller_sdk as rrc

language = os.environ["ASR_LANGUAGE"]
if language == 'Chinese':
    tts = speech.RealTimeTTS()
else:
    tts = speech.RealTimeOpenAITTS()

ctl = AGC.ctl
board = AGC.board
board.enable_reception()

def init():
    ctl.set_pwm_servo_pulse(1, 1500, 500)
    ctl.set_pwm_servo_pulse(2, 1500, 500)
    AGC.runActionGroup('stand')

def stand():
    AGC.runActionGroup('stand')

def stand_up_back():
    AGC.runActionGroup('stand_up_back')
    
def stand_up_front():
    AGC.runActionGroup('stand_up_front')

def left():
    AGC.runActionGroup('left_hand')
    
def right():
    AGC.runActionGroup('right_hand')

def forward():
    AGC.runActionGroup('go_forward')

def back():
    AGC.runActionGroup('back_fast')

def move_left():
    AGC.runActionGroup('left_move_fast')

def move_right():
    AGC.runActionGroup('right_move_fast')

def turn_left():
    AGC.runActionGroup('turn_left')

def turn_right():
    AGC.runActionGroup('turn_right')

def bow():
    AGC.runActionGroup('bow')

def wave():
    AGC.runActionGroup('wave')
    
def twist():
    AGC.runActionGroup('twist')

def celebrate():
    AGC.runActionGroup('chest')

def squat():
    AGC.runActionGroup('squat')

def right_shot():
    AGC.runActionGroup('right_shot_fast')

def left_shot():
    AGC.runActionGroup('left_shot_fast')

def sit_ups():
    AGC.runActionGroup('sit_ups')

def wing_chun():
    AGC.runActionGroup('wing_chun')

def lie_down():
    AGC.runActionGroup('lie_down')

class AHT10:
    CONFIG = [0x08, 0x00]
    MEASURE = [0x33, 0x00]

    def __init__(self, bus=1, addr=0x38):
        self.bus = smbus.SMBus(bus)
        self.addr = addr
        time.sleep(0.2) 

    def getData(self):
        byte = self.bus.read_byte(self.addr)
        self.bus.write_i2c_block_data(self.addr, 0xAC, self.MEASURE)
        time.sleep(0.5)
        data = self.bus.read_i2c_block_data(self.addr, 0x00)
        temp = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5]
        ctemp = ((temp*200) / 1048576) - 50
        hum = ((data[1] << 16) | (data[2] << 8) | data[3]) >> 4
        chum = int(hum * 100 / 1048576)
        
        return (ctemp, chum)

aht10 = AHT10()

def get_temperature():
    while True:
        data = int(aht10.getData()[0])
        if data:
            if language == 'Chinese':
                tts.tts('当前室内温度' + str(data) + '度')
            else:
                tts.tts('Current indoor temperature ' + str(data) + 'degrees Celsius')
            break

def get_pose():
    count = 0
    while True:
        accel_date = board.get_imu()
        if accel_date is not None:
            count += 1
            if count > 10:
                angle_y = int(math.degrees(math.atan2(accel_date[0], accel_date[2]))) 
                if language == 'Chinese':
                    return '当前姿态' + str(angle_y)
                else:
                    return 'Posture value is ' + str(angle_y)

def stand_up():
    count1 = 0
    count2 = 0
    is_running = True
    while is_running:
        try:
            accel_date = board.get_imu()
            angle_y = int(math.degrees(math.atan2(accel_date[0], accel_date[2]))) 
            # print(angle_y)
            if abs(angle_y) > 160: 
                count1 += 1
            else:
                count1 = 0

            if abs(angle_y) < 10: 
                count2 += 1
            else:
                count2 = 0

            time.sleep(0.1)
            if count1 >= 5: 
                count1 = 0
                print("stand_up_back")
                AGC.runActionGroup('stand_up_back')
                is_running = False
            
            elif count2 >= 5: 
                count2 = 0
                print('stand_up_front')
                AGC.runActionGroup('stand_up_front')
                is_running = False
        except BaseException as e:
            print(e)
    
frame = inspect.stack()[1]
caller_file = frame.filename
transport_code_path = os.path.dirname(os.path.abspath(caller_file))
def transport(target):
    os.system('python3 ' + os.path.join(transport_code_path, 'functions', 'transport.py') + ' ' + target)

if __name__ == '__main__':
    right()
