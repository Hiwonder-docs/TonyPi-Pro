#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/09/21
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import cv2
import json
import time
import action
import queue
import threading
from common.config import *
from speech import speech
from speech import awake

language = os.environ["ASR_LANGUAGE"]
if language == 'Chinese':
    prompt = '''
我即将说一句给机器人的指令，你根据我的指令识别图片中的物体，然后做出相应的回答，回答的内容放到response里，物体的方位词放到position里，输出json数据结构。

例如，如果我的指令是：我喜欢吃红色的水果，推荐我吃哪个。
你输出这样的格式：
{
 "response": "你可以吃左边的苹果，它是红色的",
 "position": "left()"
}

只回复json本身即可，不要回复其它内容

我现在的指令是：
'''
else:
    prompt = '''
I am about to give an instruction to the robot. Based on my instruction, identify the relevant object(s) in the image and generate an appropriate response.

Your answer should be in JSON format with the following structure:
Place your reply text in the "response" field.
Place the positional word (e.g., "left()", "right()") describing the object's location in the "position" field.

For example, if my instruction is: "I like eating red fruits, which one should I eat?"
You should return something like:
{
  "response": "You can eat the apple on the left, it's red.",
  "position": "left()"
}
Only return the JSON — no extra explanation or text.
Here is my instruction:
    '''

kws = awake.WonderEchoPro('/dev/ttyUSB0')
if language == 'Chinese':
    asr = speech.RealTimeASR()
    tts = speech.RealTimeTTS()
    client = speech.OpenAIAPI(api_key, base_url)
else:
    asr = speech.RealTimeOpenAIASR()
    asr.update_session(model=asr_model, language='en')
    tts = speech.RealTimeOpenAITTS()
    client = speech.OpenAIAPI(vllm_api_key, vllm_base_url)

try:  # If there is a fan, it is recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰)
    os.system('pinctrl FAN_PWM op dh')
except:
    pass

action.ctl.set_pwm_servo_pulse(1, 1000, 500)
action.ctl.set_pwm_servo_pulse(2, 1500, 500)
action.AGC.runActionGroup('stand')

running = True
image_queue = queue.Queue(maxsize=2)
speech.set_volume(80)
speech.play_audio(start_audio_path)
print(prompt)
print('start...')

def vllm_thread():
    kws.start()
    while running:
        if kws.wakeup(): # Wake word has been detected(检测到唤醒词)
            speech.play_audio(wakeup_audio_path)
            asr_result = asr.asr()  # Start recording and recognition (开启录音识别)
            print('asr_result:', asr_result)
            if asr_result:
                action_list, response = None, None
                image = image_queue.get(block=True) 
                try:
                    print('thinking...')
                    # Pass the recognition result to the agent for it to respond(将识别结果传给智能体让他来回答)
                    response = client.vllm(asr_result, image, prompt=prompt, model=vllm_model)
                    print('vision_result:', response)
                    res_dict = json.loads(response)
                    response = res_dict['response']
                    a = str(res_dict['position'])
                    print('tts...')
                    tts.tts(response)
                    eval(f'action.{a}') 
                except BaseException as e:
                    print(e)
            else:
                speech.play_audio(no_voice_audio_path)
        else:
            time.sleep(0.02)
threading.Thread(target=vllm_thread, daemon=True).start()

def main():
    global running
    cap = cv2.VideoCapture(-1)
    while running:
        try:
            ret, image = cap.read()
            if ret:
                if not image_queue.empty():
                    try:
                        image_queue.get_nowait()
                    except queue.Empty:
                        pass
                try:
                    image_queue.put_nowait(image)
                except queue.Full:
                    pass
                cv2.imshow('track', image)
                cv2.waitKey(1)
            else:
                time.sleep(0.01)
        except KeyboardInterrupt:
            try:
                os.system('pinctrl FAN_PWM a0')
            except:
                pass
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()

