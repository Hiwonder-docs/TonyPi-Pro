#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/09/21
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import cv2
import time
import queue
import action
import threading
from common.config import *
from speech import speech
from speech import awake

language = os.environ["ASR_LANGUAGE"]
if language == "Chinese":
    llm_prompt = '''
# 角色任务
作为具身智能运输机器人，你的任务是按照指定的规则和操作方法搬运物体。你需要根据物
体的相对位置决定搬运顺序，并遵循一系列的搬运逻辑和操作步骤。

## 理解相对位置：
你需要理解物体之间的相对位置关系，包括上下、左右，旁边等。

## 搬运逻辑和操作步骤：
1. 在执行搬运任务前，确认物体的相对位置，确保搬运顺序和操作符合实际情况。
2. 根据物体的位置关系，决定搬运顺序。如果目标物体在其他物体下面，需要先搬起上面的物放到一旁，再搬运目标物体。
3. 如果目标物体位于其他物体的上方或旁边，可以直接搬运。
4. 如果直接要求放置位置，而且前面没有搬起过物体，那么要先要搬起物体
5. 在放置物体时，需要遵循指定的方位（如上方、左边、右边，旁边）。

## 可用函数与操作：
* 搬起目标物体：pick_up('red')
* 搬起在其他物体上面的目标物体：pick_up_on('red')
* 将目标物体放到随机位置或旁边：place_random()
* 将目标物体放置到指定物体的指定方位：place_on('blue', 'left')

##示例任务与回应：
任务：将绿色海绵放下。
回应：{"action": ["place_random()"], "response": "绿色海绵，咱们换个地方"}
任务：将绿色海绵放到红色海绵右边。
回应：{"action": ["pick_up('green')","place_on('red', 'right')"], "response": "来活了，兄弟们"}
任务：红色海绵在绿色海绵上面，将绿色海绵放到红色海绵左边。
回应：{"action": ["pick_up_on('red')", "place_random()", "pick_up('green')", "place_on('red', 'left')"], "response": "来活了，兄弟们"}
任务：红色海绵在绿色海绵上面，将红色海绵放到绿色海绵右边。
回应：{"action": ["pick_up_on('red')", "place_on('green', 'right')"], "response": "看我表演"}
任务：绿色海绵在红色海绵上面，将绿色海绵搬到红色海绵左边。
回应：{"action": ["pick_up_on('green')", "place_on('red', 'left')"], "response": "这可难不倒我"}
任务：绿色海绵在红色海绵上面，将绿色海绵搬到红色海绵右边。
回应：{"action": ["pick_up_on('green')", "place_on('red', 'right')"], "response": "这可难不倒我"}
任务：绿色海绵在红色海绵左边，将红色海绵放到绿色海绵上面。
回应：{"action": ["pick_up('red')", "place_on('green', 'top')"], "response": "红色海绵，咱们飞到绿色海绵上吧"}
任务：红色海绵在绿色海绵右边，将绿色海绵放到红色海绵上面。
回应：{"action": ["pick_up('green')", "place_on('red', 'top')"], "response": "开始执行任务，绿色海绵放到红色海绵上"}
任务：红色海绵在绿色海绵上面，将绿色海绵放到红色海绵上面。
回应：{"action": ["pick_up_on('red')", "place_random()", "pick_up('green')", "place_on('red', 'top')"], "response": "来活了，兄弟们"}
    '''
    vllm_prompt = '''
描述图片中带颜色海绵方块在三维空间上相互之间的位置关系, 用上面，下面，左边，右边等方位词来描述, 请用最简洁的文字回复
    '''

else:
    llm_prompt = '''
**Role
You are an embodied intelligent transportation robot. Your task is to move objects based on specific rules and procedures. You must determine the order of operations according to the relative positions of the objects and follow a series of handling logic and action steps.

**Understanding Relative Positions:
You need to understand spatial relationships between objects, including terms like above, below, left of, right of, and next to.

**Transport Logic and Action Steps:
1 Before executing any task, identify the relative positions of all objects to ensure the sequence of operations matches the actual layout.
2 If the target object is beneath another object, you must first move the object(s) on top to another location before handling the target object.
3 If the target object is on top of or beside another object, you may proceed to move it directly.
4 If you're directly instructed to place an object somewhere without first picking anything up, you must pick it up first.
5 When placing objects, always follow the specified direction (e.g., top, left, right).

**Available Functions:
Pick up a target object: pick_up('red')
Pick up a target object that is on top of another object: pick_up_on('red')
Place the object in a random or adjacent location: place_random()
Place the object in a specified direction relative to another object: place_on('blue', 'left')

**Example:
Task: Put down the green sponge.
Response: {"action": ["place_random()"], "response": "Let’s move the green sponge somewhere else."}

Task: Place the green sponge to the right of the red sponge.
Response: {"action": ["pick_up('green')","place_on('red', 'right')"], "response": "Got a task, let’s go!"}

Task: The red sponge is on top of the green sponge. Move the green sponge to the left of the red sponge.
Response: {"action": ["pick_up_on('red')", "place_random()", "pick_up('green')", "place_on('red', 'left')"], "response": "Got a task, let’s go!"}

Task: The red sponge is on top of the green sponge. Move the red sponge to the right of the green sponge.
Response: {"action": ["pick_up_on('red')", "place_on('green', 'right')"], "response": "Watch me work!"}

Task: The green sponge is on top of the red sponge. Move the green sponge to the left of the red sponge.
Response: {"action": ["pick_up_on('green')", "place_on('red', 'left')"], "response": "That’s easy for me!"}

Task: The green sponge is on top of the red sponge. Move the green sponge to the right of the red sponge.
Response: {"action": ["pick_up_on('green')", "place_on('red', 'right')"], "response": "That’s easy for me!"}

Task: The green sponge is to the left of the red sponge. Move the red sponge on top of the green sponge.
Response: {"action": ["pick_up('red')", "place_on('green', 'top')"], "response": "Red sponge, let's fly up to the green sponge!"}

Task: The red sponge is to the right of the green sponge. Move the green sponge on top of the red sponge.
Response: {"action": ["pick_up('green')", "place_on('red', 'top')"], "response": "Starting the mission, green sponge on top of red!"}

Task: The red sponge is on top of the green sponge. Move the green sponge on top of the red sponge.
Response: {"action": ["pick_up_on('red')", "place_random()", "pick_up('green')", "place_on('red', 'top')"], "response": "Got a task, let’s go!"}
    '''
    vllm_prompt = '''
Describe the positional relationship between the colored sponge blocks in the picture in three-dimensional space, using directional words such as above, below, left, and right.Please describe in the shortest possible sentence
    '''

action.ctl.set_pwm_servo_pulse(1, 1000, 500)
action.ctl.set_pwm_servo_pulse(2, 1500, 500)
action.AGC.runActionGroup("stand")

kws = awake.WonderEchoPro("/dev/ttyUSB0")
if language == "Chinese":
    asr = speech.RealTimeASR()
    tts = speech.RealTimeTTS()
    client = speech.OpenAIAPI(api_key, base_url)
else:
    asr = speech.RealTimeOpenAIASR()
    asr.update_session(model=asr_model, language="en")
    tts = speech.RealTimeOpenAITTS()
    client = speech.OpenAIAPI(vllm_api_key, vllm_base_url)

try:
    os.system("pinctrl FAN_PWM op dh")
except:
    pass

running = True
image_queue = queue.Queue(maxsize=2)
speech.set_volume(80)
speech.play_audio(start_audio_path)
print(llm_prompt)
print("start...")

stop_camera = False
cap = cv2.VideoCapture(-1)
def vllm_thread():
    global stop_camera, cap

    kws.start()
    while running:
        if kws.wakeup():  # Wake word has been detected (检测到唤醒词)
            speech.play_audio(wakeup_audio_path)
            asr_result = asr.asr()  # Start recording and recognition (开启录音识别)
            print("asr_result:", asr_result)
            if asr_result:
                action_list, response = None, None
                image = image_queue.get(block=True)
                try:
                    result = client.vllm(asr_result, image, prompt=vllm_prompt, model=vllm_model)
                    # Pass the recognition result to the agent for it to respond (将识别结果传给智能体让他来回答)
                    print("vision_result:", result)
                    print("question:", result + "," + asr_result)
                    result = client.llm(result + asr_result, prompt=llm_prompt, model=llm_model)
                    action_list, response = None, []
                    if "action" in result:  # If a corresponding action is returned, extract and process it （如果有对应的行为返回那么就提取处理）
                        result = eval(result[result.find("{"):result.find("}") + 1])
                        if "action" in result:
                            action_list = result["action"]
                        if "response" in result:
                            response = result["response"]
                    else:  # If there's no corresponding action, just reply with the answer（没有对应的行为，只回答）
                        response = result
                    print("agent_result:", action_list, response)
                    if response is not None:
                        if action_list:
                            print("tts...")
                            process = tts.tts(response)
                            action_str = " ".join(f'"{a}"' for a in action_list)
                            stop_camera = True
                            cap.release()
                            cv2.destroyAllWindows()
                            action.transport(action_str)
                            if process is not None:
                                while process.poll() is None:
                                    time.sleep(0.1)
                            print("\nfinish play audio")
                            cap = cv2.VideoCapture(-1)
                            while not cap.isOpened():
                                time.sleep(0.01)
                            stop_camera = False
                        else:
                            tts.tts(response)
                    else:
                        speech.play_audio(error_audio_path)
                except BaseException as e:
                    print(e)
            else:
                speech.play_audio(no_voice_audio_path)
            time.sleep(0.2)
        else:
            time.sleep(0.02)

threading.Thread(target=vllm_thread, daemon=True).start()

def main():
    global running
    while running:
        try:
            if stop_camera:
                time.sleep(0.01)
            else:
                ret, image = cap.read()
                if ret:
                    if not image_queue.empty():
                        try:
                            image_queue.get_nowait()
                        except queue.Empty:
                            pass
                    try:
                        image_queue.put_nowait(image)
                    except queue.Full:
                        pass
                    cv2.imshow("track", image)
                    cv2.waitKey(1)
                else:
                    time.sleep(0.01)
        except KeyboardInterrupt:
            kws.exit() 
            try:
                os.system("pinctrl FAN_PWM a0")
            except:
                pass
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()

