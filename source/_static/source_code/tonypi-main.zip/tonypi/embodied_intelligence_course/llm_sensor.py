#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/11/27
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import time
import action
from common.config import *
from speech import awake
from speech import speech

language = os.environ["ASR_LANGUAGE"]
if language == 'Chinese':
    PROMPT = '''
# 角色
你是一款智能陪伴机器人，专注于解析人类指令并以幽默风趣的方式描述即将展开的动作序列，为交互增添趣味。

## 要求
- 对于用户输入的任何内容，在动作函数库中寻找对应的指令，并输出符合格式要求的JSON结果。
- 为每个动作序列创造一句精炼（10至30字）、风趣且富有变化的反馈信息，确保交流过程充满乐趣。
- 直接输出JSON格式的结果，避免不必要的分析或额外内容。
- 输出格式应严格遵循：`{"action": ["xx", "xx"], "response": "xx"}`

## 特别注意
- `"action"`键下是一个按执行顺序排列的动作函数名称字符串数组。如果找不到对应的动作函数，则`"action"`值为空数组`[]`。
- `"response"`键包含一条精心设计的简短回复，需满足上述风格与长度要求。
- 当获取的姿态数据位于[-20, 20]、[160, 180]或[-160, -180]区间内时，表示当前状态为躺下，此时`"response"`应回复关于躺着的内容，同时`"action"`设为空数组`[]`；其他情况下，`"response"`应回复关于站立的内容，`"action"`同样为空数组`[]`。
- 如果任务涉及查询城市或室外温度，请联网获取实际温度后将其填入`"response"`中，此时`"action"`仍为空数组`[]`。
- 面对需要做出选择的情况时，直接将你的选择放入`"response"`里，`"action"`保持为空数组`[]`。

## 动作函数列表
- `lie_down()`：躺下
- `get_temperature()`：获取室内温度
- `get_pose()`：获取姿态
- `stand_up()`：站起来

---

###示例
任务示例：深圳市的温度多少。
期望回应：{"action": [], "response": "现在深圳市的温度是24度"}
任务示例：当前室内温度多少。
期望回应：{"action": ["get_temperature()"], "response": ""}
任务示例：现在什么姿态。
期望回应：{"action": ["get_pose()"], "response": ""}
任务示例：你现在躺着吗？
期望回应：{"action:: ["get_pose()"], "response": ""}
任务示例：你现在站着吗？
期望回应：{"action": ["get_pose()"], "response": ""}
任务示例：当前姿态10。
期望回应：{"action": [], "response": "我现在躺着呢"}
任务示例：当前姿态30。
期望回应：{"action": [], "response": "我笔直的站着"}
任务示例：躺下。
期望回应：{"action": ["lie_down()"], "response": "我这就躺下"}
    '''
else:
    PROMPT = '''
**Role
You are a witty companion robot, specializing in parsing human commands and describing the upcoming action sequence in a humorous, engaging way to keep interactions fun.

**Requirements
For any user input, map it to one or more functions from the action library and output a JSON result.
Craft a concise (10–30 characters), playful, ever‑changing response for each action sequence to delight the user.
Output only the JSON—no extra explanation or commentary.
Strict format:
{"action": ["xx", "xx"], "response": "xx"}

**Special Rules
action: an array of function names (strings) in execution order. If no match is found, use an empty array [].
response: a carefully written short reply (10–30 characters) matching the style.
Posture: if the pose value is in [-20, 20], [160, 180], or [-180, -160], you are lying down—reply about lying down and set "action": []. Otherwise, reply about standing and set "action": [].
Outdoor temperature: when asked for a city’s or outdoor temperature, fetch the live value online, put it in "response", and use "action": [].
Choices: when making a decision, return your choice in "response" and "action": [].

**Action Library
- lie_down(): Lie down
- get_temperature(): Get indoor temperature
- get_pose(): Get current posture
- stand_up(): Stand up

**Examples
Input: What’s the temperature in Los Angeles?
Output:{"action": [], "response": "The current temperature in Los Angeles is 24°C"}
Input: What’s the current indoor temperature?
Output:{"action": ["get_temperature()"], "response": ""}
Input: What’s your posture now?
Output:{"action": ["get_pose()"], "response": ""}
Input: Are you lying down?
Output:{"action": ["get_pose()"], "response": ""}
Input: Are you standing up?
Output:{"action": ["get_pose()"], "response": ""}
Input: Posture value is 10.
Output:{"action": [], "response": "I'm lying down now"}
Input: Posture value is 30.
Output:{"action": [], "response": "I'm standing straight!"}
Input: Lie down.
Output:{"action": ["lie_down()"], "response": "I'll lie down now!"}
    '''

kws = awake.WonderEchoPro('/dev/ttyUSB0')
if language == 'Chinese':
    asr = speech.RealTimeASR()
    tts = speech.RealTimeTTS()
else:
    asr = speech.RealTimeOpenAIASR()
    asr.update_session(model=asr_model, language='en')
    tts = speech.RealTimeOpenAITTS()

client = speech.OpenAIAPI(api_key, base_url)

action.init()

try:
    # If there is a fan, it is recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰)
    os.system('pinctrl FAN_PWM op dh')
except:
    pass

speech.set_volume(80)
speech.play_audio(start_audio_path)
print(PROMPT)
print('start...')

def main():
    kws.start()
    while True:
        try:
            if kws.wakeup():  # Wake word detected（检测到唤醒词）
                speech.play_audio(wakeup_audio_path)  # Play wake-up audio（唤醒播放）
                asr_result = asr.asr()  # Start recording and speech recognition（开启录音识别）
                print('asr_result:', asr_result)
                if asr_result:
                    # Send the input question to the agent, then process the response to extract the corresponding action and reply（输入问题给智能体，对返回的回答进行处理，提取出对应的行为和回答）
                    action_list, response = None, None
                    if language == 'Chinese':
                        params = {
                                "model": llm_model, 
                                "messages": [{
                                    "role": "system",
                                    "content": PROMPT},
                                             {
                                    "role": "user",
                                    "content": asr_result}],
                                "extra_body": {
                                    "enable_search": True}
                        }
                    else:
                        params = {"model": 'gpt-4o-search-preview', 
                                  "web_search_options": {}, 
                                  "messages": [{
                                      "role": "system",
                                      "content": PROMPT},
                                             {
                                      "role": "user",
                                      "content": asr_result}],
                        }   
                    result = client.llm_origin(params).choices[0].message.content.strip()
                    # result = client.llm(asr_result, prompt=PROMPT, model=llm_model)
                    print('llm_result1:', result)
                    if 'action' in result:  # If a corresponding action is returned, extract and handle it（如果有对应的行为返回那么就提取处理）
                        result = eval(result[result.find('{'):result.find('}') + 1])
                        if 'action' in result:
                            action_list = result['action']
                        if 'response' in result:
                            response = result['response']
                    else:  # If there's no corresponding action, just reply with the answer(没有对应的行为，只回答)
                        response = result
                    print('agent_result1:', action_list, response)
                    if action_list:
                        if response != '':
                            print('tts...')
                            tts.tts(response)
                        for a in action_list:
                            response = eval(f'action.{a}') 
                            print('action result:', response)
                            if response is not None:
                                result = client.llm(response, prompt=PROMPT, model=llm_model)
                                print('llm_result12:', result)
                                actions, response = None, []
                                if 'action' in result:  # If a corresponding action is returned, extract and process it(如果有对应的行为返回那么就提取处理)
                                    result = eval(result[result.find('{'):result.find('}') + 1])
                                    if 'action' in result:
                                        actions = result['action']
                                    if 'response' in result:
                                        response = result['response']
                                else:  # If there's no corresponding action, just reply with the answer(没有对应的行为，只回答)
                                    response = result
                                print('agent_result2:', actions, response)
                                if actions:
                                    for a in actions:
                                        eval(f'action.{a}')
                                else:
                                    if response != '':
                                        tts.tts(response)
                                    else:
                                        speech.play_audio(error_audio_path)
                    else:
                        if response != '':
                            tts.tts(response)
                        else:
                            speech.play_audio(error_audio_path)
                else:
                    speech.play_audio(no_voice_audio_path)
                time.sleep(0.2)
            else:
                time.sleep(0.02)
        except KeyboardInterrupt:
            try:
                os.system('pinctrl FAN_PWM a0')
            except:
                pass
            break
        except BaseException as e:
            print(e)

if __name__ == '__main__':
    main()
