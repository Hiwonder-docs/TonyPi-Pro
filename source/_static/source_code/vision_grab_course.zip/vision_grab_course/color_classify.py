#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\10.拓展课程之视觉抓取课程\第3课 色块分拣(4.Advanced Lessons\10.Vision Gripping Lesson\Lesson3 Color Sorting) #3
import sys #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9
import hiwonder.ros_robot_controller_sdk as rrc #10
from hiwonder.Controller import Controller #11
import hiwonder.Misc as Misc #12
import hiwonder.Camera as Camera #13
import hiwonder.ActionGroupControl as AGC #14
import hiwonder.yaml_handle as yaml_handle #15

# 开合手掌色块分类(open and close hand for color block classification) #17

debug = False #19

if sys.version_info.major == 2: #21
    print('Please run this program with python3!') #22
    sys.exit(0) #23

range_rgb = { #25
    'red': (0, 0, 255), #26
    'blue': (255, 0, 0), #27
    'green': (0, 255, 0), #28
    'black': (0, 0, 0), #29
    'white': (255, 255, 255), #30
} #31

# 找出面积最大的轮廓(find out the contour with the maximal area) #33
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #34
def getAreaMaxContour(contours): #35
    contour_area_temp = 0 #36
    contour_area_max = 0 #37
    area_max_contour = None #38

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #40
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #41
        if contour_area_temp > contour_area_max: #42
            contour_area_max = contour_area_temp #43
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid, with the largest area being the effective one to filter out interference) #44
                area_max_contour = c #45

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #47

lab_data = None #49
servo_data = None #50
def load_config(): #51
    global lab_data, servo_data #52
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #54
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #55

board = rrc.Board() #57
ctl = Controller(board) #58

# 初始位置(initial position) #60
def initMove(): #61
    servo1 = servo_data['servo1'] #62
    ctl.set_bus_servo_pulse(17, 500, 500) #63
    ctl.set_bus_servo_pulse(18, 500, 500) #64
    ctl.set_pwm_servo_pulse(1, servo1, 500) #65
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #66

color_list = [] #68
detect_color = 'None' #69
action_finish = True #70
draw_color = range_rgb["black"] #71

# 变量重置(variable reset) #73
def reset(): #74
    global draw_color #75
    global color_list #76
    global detect_color #77
    global action_finish #78
    
    color_list = [] #80
    detect_color = 'None' #81
    action_finish = True #82
    draw_color = range_rgb["black"] #83


# app初始化调用(app initialization calling) #86
def init(): #87
    print("ColorClassify Init") #88
    load_config() #89
    initMove() #90
    AGC.runActionGroup('stand_slow') #91
    time.sleep(1) #92
    AGC.runActionGroup('squat_down') #93

robot_is_running = False #95
# app开始玩法调用(app start program calling) #96
def start(): #97
    global robot_is_running #98
    reset() #99
    robot_is_running = True #100
    print("ColorClassify Start") #101

# app停止玩法调用(app stop program calling) #103
def stop(): #104
    global robot_is_running #105
    robot_is_running = False #106
    print("ColorClassify Stop") #107

# app退出玩法调用(app exit program calling) #109
def exit(): #110
    global robot_is_running #111
    robot_is_running = False #112
    AGC.runActionGroup('stand_slow') #113
    print("ColorClassify Exit") #114
    
   
def move(): #117
    global draw_color #118
    global detect_color #119
    global action_finish #120
    
    
    while True: #123
        if debug: #124
            return #125
        if robot_is_running: #126
            if detect_color != 'None': #127
                board.set_buzzer(1900, 0.1, 0.9, 1) #128
                action_finish = False #129
                
                time.sleep(1) #131
                if detect_color == 'red': #132
                    AGC.runActionGroup('grab_right') #133
                    detect_color = 'None' #134
                    draw_color = range_rgb["black"]                     #135
                    action_finish = True #136
                    
                elif detect_color == 'blue': #138
                    AGC.runActionGroup('grab_left') #139
                    detect_color = 'None' #140
                    draw_color = range_rgb["black"]                     #141
                    action_finish = True #142
                    
                elif detect_color == 'green': #144
                    for i in range(2): #145
                        ctl.set_pwm_servo_pulse(2, 1300, 300) #146
                        time.sleep(0.3) #147
                        ctl.set_pwm_servo_pulse(2, 1700, 300) #148
                        time.sleep(0.3) #149
                    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #150
                    detect_color = 'None' #151
                    draw_color = range_rgb["black"]                     #152
                    action_finish = True #153
                    
                else: #155
                    detect_color = 'None' #156
                    draw_color = range_rgb["black"]                     #157
                    action_finish = True #158
            else: #159
               time.sleep(0.01) #160
        else: #161
            time.sleep(0.01) #162

# 运行子线程(run sub-thread) #164
th = threading.Thread(target=move) #165
th.daemon = True #166
th.start() #167

size = (320, 240) #169
def run(img): #170
    global draw_color #171
    global color_list #172
    global detect_color #173
    global action_finish #174
    
    img_copy = img.copy() #176
    img_h, img_w = img.shape[:2] #177

    if not robot_is_running: #179
        return img #180

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #182
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #183
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #184

    max_area = 0 #186
    color_area_max = None     #187
    areaMaxContour_max = 0 #188
    
    if action_finish: #190
        for i in lab_data: #191
            if i in ['red', 'green', 'blue']: #192
                frame_mask = cv2.inRange(frame_lab, #193
                                         (lab_data[i]['min'][0], #194
                                          lab_data[i]['min'][1], #195
                                          lab_data[i]['min'][2]), #196
                                         (lab_data[i]['max'][0], #197
                                          lab_data[i]['max'][1], #198
                                          lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #199
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #200
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #201
                if debug: #202
                    cv2.imshow(i, dilated) #203
                contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contours) #204
                areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #205
                if areaMaxContour is not None: #206
                    if area_max > max_area:#找最大面积(find the maximal area) #207
                        max_area = area_max #208
                        color_area_max = i #209
                        areaMaxContour_max = areaMaxContour #210
        if max_area > 3500:  # 有找到最大面积(the maximal area is found) #211
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum bounding rectangle) #212
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #213
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #214
            radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #215
            cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #216

            if color_area_max == 'red':  #红色最大(red is the maximal area) #218
                color = 1 #219
            elif color_area_max == 'green':  #绿色最大(green is the maximal area) #220
                color = 2 #221
            elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #222
                color = 3 #223
            else: #224
                color = 0 #225
            color_list.append(color) #226

            if len(color_list) == 3:  #多次判断(multiple judgements) #228
                # 取平均值(take average value) #229
                color = round(np.mean(np.array(color_list))) #230
                color_list = [] #231
                if color == 1: #232
                    detect_color = 'red' #233
                    draw_color = range_rgb["red"] #234
                elif color == 2: #235
                    detect_color = 'green' #236
                    draw_color = range_rgb["green"] #237
                elif color == 3: #238
                    detect_color = 'blue' #239
                    draw_color = range_rgb["blue"] #240
                else: #241
                    detect_color = 'None' #242
                    draw_color = range_rgb["black"]                #243
        else: #244
            color_list = [] #245
            detect_color = 'None' #246
            draw_color = range_rgb["black"] #247
            
    cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2) #249
    
    return img #251


if __name__ == '__main__': #254
    from hiwonder.CalibrationConfig import * #255
    
    param_data = np.load(calibration_param_path + '.npz') #257
    mtx = param_data['mtx_array'] #258
    dist = param_data['dist_array'] #259
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #260
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #261
  
    my_camera = Camera.Camera() #263
    my_camera.camera_open() #264
    
    init() #266
    start() #267
    
    while True: #269
        ret,img = my_camera.read() #270
        if ret: #271
            frame = img.copy() #272
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #273
            Frame = run(frame)            #274
            cv2.imshow('Frame', Frame) #275
            key = cv2.waitKey(1) #276
            if key == 27: #277
                break #278
        else: #279
            time.sleep(0.01) #280
    my_camera.camera_close() #281
    cv2.destroyAllWindows() #282
    
    
