#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\10.拓展课程之视觉抓取课程\第5课 TonyPi Pro语音控制抓取(4.Advanced Lessons\10.Vision Gripping Lesson\Lesson5 TonyPi Pro Voice Control Gripping) #3
import os #4
import sys #5
import cv2 #6
import math #7
import time #8
import serial #9
import threading #10
import numpy as np #11
from hiwonder import fps #12
from speech import speech #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.Misc as Misc #16
import hiwonder.ActionGroupControl as AGC #17
import hiwonder.yaml_handle as yaml_handle #18

cmd_dict = {b"\xaa\x55\x03\x00\xfb": 'wakeup', #20
            b"\xaa\x55\x02\x00\xfb": 'sleep', #21
            b"\xaa\x55\x00\x08\xfb": 'red', #22
            b"\xaa\x55\x00\x09\xfb": 'green', #23
            b"\xaa\x55\x00\x0A\xfb": 'blue'} #24
audio_path = os.path.join(os.path.abspath(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'audio')))  #25
fps = fps.FPS() #26
if sys.version_info.major == 2: #27
    print('Please run this program with python3!') #28
    sys.exit(0) #29

#语音控制抓取(voice control gripping) #31

CentreX = 330 #33
state = False #34
target_color = 'None' #35
color, color_x, color_y, angle = None, 0, 0, 0 #36

lab_data = None #38
servo_data = None #39
def load_config(): #40
    global lab_data #41
    global servo_data #42
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #43
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #44

load_config() #46

range_rgb = { #48
    'red': (0, 0, 255), #49
    'blue': (255, 0, 0), #50
    'green': (0, 255, 0), #51
    'black': (0, 0, 0), #52
    'white': (255, 255, 255), #53
    'None': (255, 255, 255)} #54

board = rrc.Board() #56
ctl = Controller(board) #57

# 初始位置(initial position) #59
def initMove(): #60
    ctl.set_pwm_servo_pulse(1,servo_data['servo1'],1000) #61
    ctl.set_pwm_servo_pulse(2,servo_data['servo2'],1000)  #62
    ctl.set_bus_servo_pulse(17, 500, 1000) #63
    ctl.set_bus_servo_pulse(18, 500, 1000) #64

    

# 找出面积最大的轮廓(find out the contour with the maximal area) #68
# 参数为要比较的轮廓的列表(the parameter is the list to be compared) #69
def getAreaMaxContour(contours): #70
    contour_area_temp = 0 #71
    contour_area_max = 0 #72
    area_max_contour = None #73

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #75
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #76
        if contour_area_temp > contour_area_max: #77
            contour_area_max = contour_area_temp #78
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid, with the largest area being the effective one to filter out interference) #79
                area_max_contour = c #80

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #82


def move(): #85
    global state, target_color #86
    global lab_data #87
    global servo_data #88

    skip = True #90
    pulse2 = servo_data['servo2'] #91
    dire = None #92
    while True: #93
        if state: #94
            time.sleep(1) #95
            if color != 'None': #96
                if dire is None: #97
                    if color_x > CentreX: #98
                        dire = 'right' #99
                    elif color_x < CentreX: #100
                        dire = 'left' #101
                if 15 > color_x - CentreX > 8: #102
                    AGC.runAction('right_move_10') #103
                elif -15 < color_x - CentreX < -8: #104
                    AGC.runAction('left_move_10') #105
                elif color_x - CentreX >= 20: #106
                    AGC.runAction('right_move_20') #107
                elif color_x - CentreX <= -20: #108
                    AGC.runAction('left_move_20') #109
                else: #110
                    board.set_buzzer(1900, 0.1, 0.9, 1) #111
                    if dire == 'left': #112
                        AGC.runAction('grab_squat_left') #113
                        time.sleep(0.5) #114
                        AGC.runAction('grab_squat_up_left') #115
                        time.sleep(0.5) #116
                        AGC.runAction('grab_stand_left') #117
                    elif dire == 'right': #118
                        AGC.runAction('grab_squat_right') #119
                        time.sleep(0.5) #120
                        AGC.runAction('grab_squat_up_right') #121
                        time.sleep(0.5) #122
                        AGC.runAction('grab_stand_right') #123
                    dire = None #124
                    state = False #125
                    target_color = 'None' #126
                    
                if pulse2 - servo_data['servo2'] >= 10: #128
                    pulse2 -= 20 #129
                elif pulse2 - servo_data['servo2'] <= -10: #130
                    pulse2 += 20 #131
                ctl.set_pwm_servo_pulse(2, pulse2, 30) #132
                
            else: #134
                dire = None #135
                if skip: #136
                    pulse2 = 1700 #137
                    skip = False #138
                else: #139
                    pulse2 = 1360 #140
                    skip = True #141
                ctl.set_pwm_servo_pulse(2, pulse2, 300) #142
                time.sleep(0.8) #143
        else:  #144
            time.sleep(0.01) #145

# 运行子线程(run sub-thread) #147
th = threading.Thread(target=move) #148
th.daemon = True #149
th.start() #150

def colorDetect(img): #152
    img_h, img_w = img.shape[:2] #153
    size = (img_w, img_h) #154
    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #155
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #156
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #157
    
    center_max_distance = pow(img_w/2, 2) + pow(img_h, 2) #159
    color, center_x, center_y, angle = 'None', -1, -1, 0 #160
    if target_color != 'None': #161
        frame_mask = cv2.inRange(frame_lab, #162
                                 (lab_data[target_color]['min'][0], #163
                                  lab_data[target_color]['min'][1], #164
                                  lab_data[target_color]['min'][2]), #165
                                 (lab_data[target_color]['max'][0], #166
                                  lab_data[target_color]['max'][1], #167
                                  lab_data[target_color]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #168
        eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #169
        dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #170
        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contours) #171
        areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #172
        if area_max > 500:  # 有找到最大面积(the maximal area is found) #173
            rect = cv2.minAreaRect(areaMaxContour)#最小外接矩形(the minimum bounding rectangle) #174
            angle_ = rect[2] #175

            box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #177
            for j in range(4): #178
                box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w)) #179
                box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h)) #180
            cv2.drawContours(img, [box], -1, range_rgb[target_color], 2)#画出四个点组成的矩形(draw the rectangle formed by the four points) #181
            #获取矩形的对角点(get the diagonal points of the rectangle) #182
            ptime_start_x, ptime_start_y = box[0, 0], box[0, 1] #183
            pt3_x, pt3_y = box[2, 0], box[2, 1]             #184
            center_x_, center_y_ = int((ptime_start_x + pt3_x) / 2), int((ptime_start_y + pt3_y) / 2)#中心点(center point) #185
            cv2.circle(img, (center_x_, center_y_), 5, (0, 255, 255), -1)#画出中心点(draw center point) #186
            distance = pow(center_x_ - img_w/2, 2) + pow(center_y_ - img_h, 2) #187
            if distance < center_max_distance:  # 寻找距离最近的物体来搬运(find the nearest object for transportation) #188
                center_max_distance = distance #189
                color = target_color #190
                center_x, center_y, angle = center_x_, center_y_, angle_ #191
                    
    return color, center_x, center_y, angle #193

class WonderEcho: #195
    def __init__(self, port): #196
        self.serialHandle = serial.Serial(None, 115200, serial.EIGHTBITS, serial.PARITY_NONE, serial.STOPBITS_ONE, timeout=0.02) #197
        self.serialHandle.rts = False #198
        self.serialHandle.dtr = False #199
        self.serialHandle.setPort(port) #200
        self.serialHandle.open() #201
        self.serialHandle.reset_input_buffer() #202

    def detect(self): #204
        return self.serialHandle.read(5) #205

    def exit(self): #207
        self.serialHandle.close() #208

wonderecho = WonderEcho('/dev/ttyUSB0') #210
def asr_detect(): #211
    global state, target_color #212
    while True: #213
        if not state: #214
            data = wonderecho.detect() #215
            if data != b'': #216
                if data in cmd_dict: #217
                    print("result:", cmd_dict[data]) #218
                    if cmd_dict[data] == 'wakeup': #219
                        speech.play_audio(os.path.join(audio_path, 'wakeup.wav')) #220
                    elif cmd_dict[data] == 'sleep': #221
                        speech.play_audio(os.path.join(audio_path, 'dong.wav'))  #222
                    elif cmd_dict[data] == 'red': #223
                        target_color = 'red' #224
                        state = True #225
                    elif cmd_dict[data] == 'green': #226
                        target_color = 'green' #227
                        state = True #228
                    elif cmd_dict[data] == 'blue': #229
                        target_color = 'blue' #230
                        state = True #231
                    else: #232
                        target_color = 'None' #233
                        state = False #234
            else: #235
                time.sleep(0.01) #236
        else: #237
            time.sleep(0.01) #238

# 运行子线程(run sub-thread) #240
th = threading.Thread(target=asr_detect) #241
th.daemon = True #242
th.start() #243

def run(img): #245
    global target_color, state #246
    global color, color_x, color_y, angle #247
    
    if state and target_color != 'None': #249
        color, color_x, color_y, angle = colorDetect(img) #250
#         print('Color:',color, color_x, color_y, angle) #251
        cv2.putText(img, "Color:"+color, (10, img.shape[0] - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.65, range_rgb[color], 2) #252
       
    return img #254


if __name__ == '__main__': #257
    from hiwonder.CalibrationConfig import * #258
    
    param_data = np.load(calibration_param_path + '.npz') #260
    mtx = param_data['mtx_array'] #261
    dist = param_data['dist_array'] #262
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #263
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #264
    
    load_config() #266
    initMove() #267
    
    camera = cv2.VideoCapture(-1) #269
    AGC.runActionGroup('stand_slow') #270
    
    while True: #272
    
        Time = time.time() #274
        ret,img = camera.read() #275
        if ret: #276
            frame = img.copy() #277
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #278
            Frame = run(frame) #279
            d_time = time.time() - Time #280
            fps = int(1.0 / d_time) #281
            cv2.putText(Frame, 'FPS:'+ str(fps), (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,0), 2) #282
            cv2.imshow('Frame', Frame) #283
            key = cv2.waitKey(1) #284
            if key == 27: #285
                break #286
        else: #287
            time.sleep(0.01) #288
    camera.camera_close() #289
    cv2.destroyAllWindows() #290
    
    
