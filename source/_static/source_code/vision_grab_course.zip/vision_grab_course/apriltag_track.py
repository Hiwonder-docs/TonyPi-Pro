#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\10.拓展课程之视觉抓取课程\第4课 Apriltag追踪投放(4.Advanced Lessons\10.Vision Gripping Lesson\Lesson4 Apriltag Tracking) #3
import sys #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9
import hiwonder.ros_robot_controller_sdk as rrc #10
from hiwonder.Controller import Controller #11
import hiwonder.Misc as Misc #12
import hiwonder.apriltag as apriltag #13
import hiwonder.ActionGroupControl as AGC #14
import hiwonder.yaml_handle as yaml_handle #15

#开合手掌放置apriltag区域(open and close your hand to place it in the apriltag area) #17

if sys.version_info.major == 2: #19
    print('Please run this program with python3!') #20
    sys.exit(0) #21

debug = False #23
tag_id = None #24
action_finish = False #25
CentreX = 320 #26

objective_x, objective_y = 0, 0 #28
color, color_x, color_y, angle = None, 0, 0, 0 #29

lab_data = None #31
servo_data = None #32
def load_config(): #33
    global lab_data , servo_data #34
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #36
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #37

load_config() #39
servo1, servo2 = servo_data['servo1'], servo_data['servo2'] #40

range_rgb = { #42
    'red': (0, 0, 255), #43
    'blue': (255, 0, 0), #44
    'green': (0, 255, 0), #45
    'black': (0, 0, 0), #46
    'white': (255, 255, 255), #47
    'None': (255, 255, 255)} #48

board = rrc.Board() #50
ctl = Controller(board) #51

# 初始位置(initial position) #53
def initMove(): #54
    ctl.set_pwm_servo_pulse(1, servo1, 1000) #55
    ctl.set_pwm_servo_pulse(2, servo2, 1000) #56
    ctl.set_bus_servo_pulse(17, 500, 1000) #57
    ctl.set_bus_servo_pulse(18, 500, 1000) #58

def right_splay(): #60
    ctl.set_bus_servo_pulse(17, 760, 1000) #61
    time.sleep(1) #62
    
def right_grasp(): #64
    ctl.set_bus_servo_pulse(17, 500, 1000) #65
    time.sleep(1) #66
    
def up_hand(): #68
    ctl.set_bus_servo_pulse(16, 650, 1000) #69
    time.sleep(0.5) #70
    ctl.set_bus_servo_pulse(15, 260, 1000) #71
    ctl.set_bus_servo_pulse(14, 180, 1000) #72
    ctl.set_bus_servo_pulse(17, 500, 1000) #73
    time.sleep(1) #74

def down_hand(): #76
    ctl.set_bus_servo_pulse(15, 200, 1000) #77
    ctl.set_bus_servo_pulse(14, 460, 1000) #78
    ctl.set_bus_servo_pulse(17, 500, 1000) #79
    time.sleep(0.6) #80
    ctl.set_bus_servo_pulse(16, 275, 1000) #81
    time.sleep(1) #82
    
def runBuzzer(sleep): #84
    Board.setBuzzer(1) # 打开(open) #85
    time.sleep(sleep) # 延时(delay) #86
    Board.setBuzzer(0) #关闭(close) #87

# 找出面积最大的轮廓(find out the contour with the maximal area) #89
# 参数为要比较的轮廓的列表(the list is the contour to be compared) #90
def getAreaMaxContour(contours): #91
    contour_area_temp = 0 #92
    contour_area_max = 0 #93
    area_max_contour = None #94

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #96
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #97
        if contour_area_temp > contour_area_max: #98
            contour_area_max = contour_area_temp #99
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid, with the largest area being the effective one to filter out interference) #100
                area_max_contour = c #101

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #103


def move(): #106
    global tag_id,objective_x,objective_y #107
    global action_finish,servo1,servo2 #108
    
    LOCK_servos = {'14': 180,'15': 260,'16': 650} #110
    servo1_st, servo2_st = True, True #111
    
    while True: #113
        if not action_finish: #114
            if color is not None: #115
                if color_y >= 300: #116
                    board.set_buzzer(1900, 0.1, 0.9, 1) #117
                    up_hand() #118
                    right_splay() #119
                    time.sleep(2) #120
                    board.set_buzzer(1900, 0.1, 0.9, 1) #121
                    time.sleep(0.1) #122
                    board.set_buzzer(1900, 0.1, 0.9, 1) #123
                    right_grasp() #124
                    down_hand() #125
                    action_finish = True #126
                else: #127
                    time.sleep(0.01) #128
            else: #129
                time.sleep(0.01) #130
                    
        elif action_finish: #132
            if tag_id is not None: #133
                if objective_x - CentreX >= 50 and objective_y < 240: #134
                    AGC.runAction('turn_right') #135
                    
                elif objective_x - CentreX <= -50 and objective_y < 240: #137
                    AGC.runAction('turn_left') #138
                
                elif objective_y <= 280: #140
                    AGC.runAction('go_forward') #141
                
                elif objective_x - CentreX >= 30: #143
                    AGC.runAction('right_move_20') #144
                    
                elif objective_x - CentreX <= -30: #146
                    AGC.runAction('left_move_20') #147
                
                elif 30 > objective_x - CentreX >= 10: #149
                    AGC.runAction('right_move') #150
                    
                elif -30 < objective_x - CentreX <= -10: #152
                    AGC.runAction('left_move') #153
                    
                elif 280 < objective_y < 320: #155
                    AGC.runAction('go_forward_one_step') #156
                
                elif objective_y >= 320: #158
                    board.set_buzzer(1900, 0.1, 0.9, 1) #159
                    AGC.runAction('put_down_object') #160
                    right_splay() #161
                    time.sleep(0.5) #162
                    right_grasp() #163
                    AGC.runAction('put_up_object') #164
                    time.sleep(2) #165
                    action_finish = False #166
                    
                if servo1 > 920: #168
                    servo1 -= 15 #169
                servo1 = servo_data['servo1'] if servo1 < servo_data['servo1'] else servo1 #170
                
                if servo2 - servo_data['servo2'] >= 10: #172
                    servo2 -= 10 #173
                elif servo2 - servo_data['servo2'] <= -10: #174
                    servo2 +=10  #175
                        
                ctl.set_pwm_servo_pulse(1, servo1, 30) #177
                ctl.set_pwm_servo_pulse(2, servo2, 30) #178
                
            else: #180
                if servo1 >= 1250: #181
                    servo1_st = False #182
                elif servo1 <= servo_data['servo1']: #183
                    servo1_st = True    #184
                if servo1_st: #185
                    servo1 += 5 #186
                else: #187
                    servo1 -= 5 #188
                    
                if servo2 >= 1700: #190
                    servo2_st = False #191
                elif servo2 <= 1300: #192
                    servo2_st = True #193
                    
                if servo2_st: #195
                    servo2 += 5 #196
                else: #197
                    servo2 -= 5 #198
                ctl.set_pwm_servo_pulse(1, servo1, 30) #199
                ctl.set_pwm_servo_pulse(2, servo2, 30) #200
                time.sleep(0.05) #201
                
        else: #203
            time.sleep(0.01) #204

# 运行子线程(run the sub-thread) #206
th = threading.Thread(target=move) #207
th.daemon = True #208
th.start() #209

# 检测apriltag(detect apriltag) #211
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #212

def apriltagDetect(img):    #214
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #215
    detections = detector.detect(gray, return_image=False) #216

    if len(detections) != 0: #218
        for detection in detections:                        #219
            corners = np.int0(detection.corners)  # 获取四个角点(get four corner points) #220
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 2) #221

            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #223
            tag_id = int(detection.tag_id)  # 获取tag_id(get tag_id) #224

            objective_x, objective_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #226
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation angle) #228
            
            return [tag_family, tag_id, objective_x, objective_y] #230
            
    return None, None, None, None #232


def colorDetect(img): #235
    img_h, img_w = img.shape[:2] #236
    size = (img_w, img_h) #237
    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #238
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #239
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #240
    
    center_max_distance = pow(img_w/2, 2) + pow(img_h, 2) #242
    color, center_x, center_y, angle = 'None', -1, -1, 0 #243
    for i in lab_data: #244
        if i in color_list: #245
            frame_mask = cv2.inRange(frame_lab, #246
                                     (lab_data[i]['min'][0], #247
                                      lab_data[i]['min'][1], #248
                                      lab_data[i]['min'][2]), #249
                                     (lab_data[i]['max'][0], #250
                                      lab_data[i]['max'][1], #251
                                      lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #252
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #253
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #254
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contours) #255
            areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #256
            
            if area_max > 500:  # 有找到最大面积(the maximal area is found) #258
                rect = cv2.minAreaRect(areaMaxContour)#最小外接矩形(the minimum bounding rectangle) #259
                angle_ = rect[2] #260
        
                box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #262
                for j in range(4): #263
                    box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w)) #264
                    box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h)) #265

                cv2.drawContours(img, [box], -1, range_rgb[i], 2)#画出四个点组成的矩形(draw the rectangle formed by the four points) #267
            
                #获取矩形的对角点(get the diagonal points of the rectangle) #269
                ptime_start_x, ptime_start_y = box[0, 0], box[0, 1] #270
                pt3_x, pt3_y = box[2, 0], box[2, 1]             #271
                center_x_, center_y_ = int((ptime_start_x + pt3_x) / 2), int((ptime_start_y + pt3_y) / 2)#中心点(center point) #272
                cv2.circle(img, (center_x_, center_y_), 5, (0, 255, 255), -1)#画出中心点(draw center point) #273
                
                distance = pow(center_x_ - img_w/2, 2) + pow(center_y_ - img_h, 2) #275
                if distance < center_max_distance:  # 寻找距离最近的物体来搬运(find the nearest object for transportation) #276
                    center_max_distance = distance #277
                    color = i #278
                    center_x, center_y, angle = center_x_, center_y_, angle_ #279
                    
    return color, center_x, center_y, angle #281

def run(img): #283
    global tag_id,objective_x,objective_y #284
    global action_finish, color, color_x, color_y, angle #285
     
    img_copy = img.copy() #287
    img_h, img_w = img.shape[:2] #288
    
    if action_finish: #290
        tag_family, tag_id, objective_x, objective_y = apriltagDetect(img) # apriltag检测(apriltag detection) #291
        print('Apriltag:',objective_x,objective_y) #292
        if tag_id is not None: #293
            cv2.putText(img, "tag_id: " + str(tag_id), (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #294
            cv2.putText(img, "tag_family: " + tag_family, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #295
        else: #296
            cv2.putText(img, "tag_id: None", (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #297
            cv2.putText(img, "tag_family: None", (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #298
        
    elif not action_finish: #300
        color, color_x, color_y, angle = colorDetect(img) #301
        print('Color:',color, color_x, color_y, angle) #302
        cv2.putText(img, "Color:"+color, (10, img.shape[0] - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.65, range_rgb[color], 2) #303
       
    return img #305


if __name__ == '__main__': #308
    from hiwonder.CalibrationConfig import * #309
    
    param_data = np.load(calibration_param_path + '.npz') #311
    mtx = param_data['mtx_array'] #312
    dist = param_data['dist_array'] #313
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #314
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #315
  
    load_config() #317
    initMove() #318
    color_list = ('red','blue','green') #319
    camera = cv2.VideoCapture(-1) #320
    AGC.runActionGroup('stand_slow') #321
    
    while True: #323
        ret,img = camera.read() #324
        if ret: #325
            frame = img.copy() #326
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #327
            Frame = run(frame)            #328
            cv2.imshow('Frame', Frame) #329
            key = cv2.waitKey(1) #330
            if key == 27: #331
                break #332
        else: #333
            time.sleep(0.01) #334
    my_camera.camera_close() #335
    cv2.destroyAllWindows() #336
    
    
