#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9

import mediapipe as mp #11
import hiwonder.Camera as Camera #12
import hiwonder.Misc as Misc #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17


''' #20
    程序功能：人脸识别(program function: face recognition) #21

    运行效果：玩法开启后，摄像头云台将进行左右转动。当识别到人脸后，云台会停止转动，此时机器人将执行招手动作。(running effect: after the game mode is activated, the camera gimbal will rotate left and right. When a face is recognized, the gimbal will stop rotating, and the robot will perform a waving gesture) #23

    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第6课 人脸识别(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\3.AI Vision Game Course\Lesson6 Human Face Recognition) #25
''' #26

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #28
if sys.version_info.major == 2: #29
    print('Please run this program with python3!') #30
    sys.exit(0) #31

# 导入人脸识别模块(import human face recognition module) #33
face = mp.solutions.face_detection #34
# 自定义人脸识别方法，最小的人脸检测置信度0.5(custom human face recognition method, the minimum face detection confidence is 0.5) #35
face_detection = face.FaceDetection(min_detection_confidence=0.7) #36

board = rrc.Board() #38
ctl = Controller(board) #39


servo_data = None #42
def load_config(): #43
    global servo_data #44
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)   #46

load_config() #48

servo2_pulse = servo_data['servo2'] #50

# 初始化机器人舵机初始位置(initialize the servo initialization position of robot) #52
def initMove(): #53
    ctl.set_pwm_servo_pulse(1, 1800, 500) #54
    ctl.set_pwm_servo_pulse(2, servo2_pulse, 500) #55


d_pulse = 10 #58
start_greet = False #59
action_finish = True #60
# 变量重置(variable reset) #61
def reset(): #62
    global d_pulse #63
    global start_greet #64
    global servo2_pulse     #65
    global action_finish #66

    d_pulse = 10 #68
    start_greet = False #69
    action_finish = True #70
    servo2_pulse = servo_data['servo2']     #71
    initMove()   #72
    
# app初始化调用(app initialization calling) #74
def init(): #75
    print("FaceDetect Init") #76
    reset() #77

__isRunning = False #79
# app开始玩法调用(app start program calling) #80
def start(): #81
    global __isRunning #82
    __isRunning = True #83
    print("FaceDetect Start") #84

# app停止玩法调用(app stop program calling) #86
def stop(): #87
    global __isRunning #88
    __isRunning = False #89
    reset() #90
    print("FaceDetect Stop") #91

# app退出玩法调用(app exit program calling) #93
def exit(): #94
    global __isRunning #95
    __isRunning = False #96
    AGC.runActionGroup('stand_slow') #97
    print("FaceDetect Exit") #98

def move(): #100
    global start_greet #101
    global action_finish #102
    global d_pulse, servo2_pulse     #103
    
    while True: #105
        if __isRunning: #106
            if start_greet: #107
                start_greet = False #108
                action_finish = False #109
                AGC.runActionGroup('wave') # 识别到人脸时执行的动作(the action to be performed when a face is recognized) #110
                action_finish = True #111
                time.sleep(0.5) #112
            else: #113
                if servo2_pulse > 2000 or servo2_pulse < 1000: #114
                    d_pulse = -d_pulse #115
            
                servo2_pulse += d_pulse  #117
                ctl.set_pwm_servo_pulse(2, servo2_pulse, 50) #118
                time.sleep(0.05) #119
        else: #120
            time.sleep(0.01) #121
            
# 运行子线程(run sub-thread) #123
th = threading.Thread(target=move) #124
th.daemon = True #125
th.start() #126

def run(img): #128
    global start_greet #129
    global action_finish #130
       
    img_copy = img.copy() #132
    img_h, img_w = img.shape[:2] #133

    if not __isRunning: #135
        return img #136
    
    image_rgb = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB) # 将BGR图像转为RGB图像(convert BGR image to RGB image) #138
    results = face_detection.process(image_rgb) # 将每一帧图像传给人脸识别模块(pass each frame of the image to the face recognition module) #139
    if results.detections:   # 如果检测不到人脸那就返回None #140
        for index, detection in enumerate(results.detections): # 返回人脸索引index(第几张脸)，和关键点的坐标信息(return the face index (which face) and the coordinate information of the keypoints) #141
            bboxC = detection.location_data.relative_bounding_box # 设置一个边界框，接收所有的框的xywh及关键点信息(set up a bounding box to receive the xywh and keypoint information for all boxes) #142
            
            # 将边界框的坐标点,宽,高从比例坐标转换成像素坐标(convert the coordinates, width, and height of the bounding box from relative coordinates to pixel coordinates) #144
            bbox = (int(bboxC.xmin * img_w), int(bboxC.ymin * img_h),   #145
                   int(bboxC.width * img_w), int(bboxC.height * img_h)) #146
            cv2.rectangle(img, bbox, (0,255,0), 2)  # 在每一帧图像上绘制矩形框(draw a rectangle on each frame of the image) #147
            x, y, w, h = bbox  # 获取识别框的信息,xy为左上角坐标点(get the information of the recognition box, where xy is the coordinate point of the upper left corner) #148
            center_x =  int(x + (w/2)) #149
           
            if abs(center_x - img_w/2) < img_w/4: #151
                if action_finish: #152
                    start_greet = True #153
    
    return img #155

if __name__ == '__main__': #157
    from CameraCalibration.CalibrationConfig import * #158
    
    #加载参数(load parameters) #160
    param_data = np.load(calibration_param_path + '.npz') #161

    #获取参数(get parameters) #163
    mtx = param_data['mtx_array'] #164
    dist = param_data['dist_array'] #165
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #166
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5)  #167
    
    init() #169
    start() #170
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #172
    if open_once: #173
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #174
    else: #175
        my_camera = Camera.Camera() #176
        my_camera.camera_open()                 #177
    AGC.runActionGroup('stand') #178
    while True: #179
        ret, img = my_camera.read() #180
        if ret: #181
            frame = img.copy() #182
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #183
            Frame = run(frame)            #184
            cv2.imshow('Frame', Frame) #185
            key = cv2.waitKey(1) #186
            if key == 27: #187
                break #188
        else: #189
            time.sleep(0.01) #190
    my_camera.camera_close() #191
    cv2.destroyAllWindows() #192
