#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
import pandas as pd #10

import hiwonder.PID as PID #12
import hiwonder.Camera as Camera #13
import hiwonder.Misc as Misc #14
import hiwonder.ros_robot_controller_sdk as rrc #15
from hiwonder.Controller import Controller #16
import hiwonder.ActionGroupControl as AGC #17
import hiwonder.yaml_handle as yaml_handle #18
from CameraCalibration.CalibrationConfig import * #19

''' #21
    程序功能：物体追踪(program function: object tracking) #22

    运行效果：   玩法开启后，手持红色海绵方块或者将方块置于可以移动的载体上进行缓慢移动， #24
                TonyPi 机器人将随着目标颜色的移动而移动。(running effect: after the game mode is activated, move the red sponge block slowly by hand or place the block on a movable carrier. The TonyPi robot will move along with the movement of the target color) #25

                    
    对应教程文档路径：  TonyPi智能视觉人形机器人\4.拓展课程学习\1.语音交互及智能搬运课程（语音模块选配）\第6课 物体追踪(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\4.Expanded Courses\1.Voice Interaction and Intelligent Transportation(voice module optional)\Lesson6 Object Tracking) #28
''' #29

# 调试模式标志量(debug mode flag variable) #31
debug = False #32

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #34
if sys.version_info.major == 2: #35
    print('Please run this program with python3!') #36
    sys.exit(0) #37

#加载参数(load parameters) #39
param_data = np.load(calibration_param_path + '.npz') #40

#获取参数(get parameters) #42
mtx = param_data['mtx_array'] #43
dist = param_data['dist_array'] #44
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #45
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #46

range_rgb = { #48
    'red': (0, 0, 255), #49
    'blue': (255, 0, 0), #50
    'green': (0, 255, 0), #51
    'black': (0, 0, 0), #52
    'white': (255, 255, 255), #53
} #54

lab_data = None #56
servo_data = None #57
# 加载配置文件数据(load configuration file data) #58
def load_config(): #59
    global lab_data, servo_data #60
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #62
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #63

load_config() #65

__target_color = ('green') #67

# 设置检测颜色(set detected color) #69
def setBallTargetColor(target_color): #70
    global __target_color #71

    __target_color = target_color #73
    return (True, ()) #74

# 初始化机器人底层驱动(initialize robot underlying drivers) #76
board = rrc.Board() #77
ctl = Controller(board) #78

# 初始位置(initial position) #80
def initMove(): #81
    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #82
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #83

# 初始化舵机移动水平方向和垂直方向的步长(initialize the step size for servo movement in the horizontal and vertical directions) #85
d_x = 20 #86
d_y = 20 #87

step = 1 #89

# 设置舵机位置(set servo position) #91
x_dis = servo_data['servo2'] #92
y_dis = servo_data['servo1'] #93

# 初始化物体中心点的xy坐标(initialize the xy coordinates of the object's center point) #95
centerX, centerY = -2, -2 #96

# 初始化 PID控制器(initialize PID controller) #98
x_pid = PID.PID(P=0.145, I=0.0, D=0.0007)#pid初始化(pid initialization) #99
y_pid = PID.PID(P=0.145, I=0.0, D=0.0007) #100

# 变量重置(variable reset) #102
def reset(): #103
    global d_x, d_y #104
    global step #105
    global x_dis, y_dis #106
    global __target_color #107
    global centerX, centerY #108

    d_x = 20 #110
    d_y = 20 #111
    step = 1 #112
    x_pid.clear() #113
    y_pid.clear() #114
    x_dis = servo_data['servo2'] #115
    y_dis = servo_data['servo1'] #116
    __target_color = () #117
    centerX, centerY = -2, -2 #118

# app初始化调用(app initialization calling) #120
def init(): #121
    print("Follow Init") #122
    load_config() #123
    initMove() #124

__isRunning = False #126
# app开始玩法调用(app start program calling) #127
def start(): #128
    global __isRunning #129
    reset() #130
    __isRunning = True #131
    print("Follow Start") #132

# app停止玩法调用(app stop program calling) #134
def stop(): #135
    global __isRunning #136
    __isRunning = False #137
    print("Follow Stop") #138

# app退出玩法调用(app exit program calling) #140
def exit(): #141
    global __isRunning #142
    __isRunning = False #143
    AGC.runActionGroup('stand_slow') #144
    print("Follow Exit") #145

# 找出面积最大的轮廓(find out the contour with the maximal area) #147
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #148
def getAreaMaxContour(contours): #149
    contour_area_temp = 0 #150
    contour_area_max = 0 #151
    areaMaxContour = None #152

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #154
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #155
        if contour_area_temp > contour_area_max: #156
            contour_area_max = contour_area_temp #157
            if contour_area_temp > 100:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #158
                areaMaxContour = c #159

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #161


CENTER_X = 320 #164
circle_radius = 0 #165
#执行动作组(execute action group) #166
def move(): #167
    
    while True: #169
        if __isRunning: #170
            if centerX >= 0: #171
                if centerX - CENTER_X > 100 or x_dis - servo_data['servo2'] < -80:  # 不在中心，根据方向让机器人转向一步(if not in the center, instruct the robot to turn one step according to the direction) #172
                    AGC.runActionGroup('turn_right_small_step') #173
                elif centerX - CENTER_X < -100 or x_dis - servo_data['servo2'] > 80: #174
                    AGC.runActionGroup('turn_left_small_step')                         #175
                elif 100 > circle_radius > 0: #176
                    AGC.runActionGroup('go_forward') #177
                elif 180 < circle_radius: #178
                    AGC.runActionGroup('back_fast') #179
            else: #180
                time.sleep(0.01) #181
        else: #182
            time.sleep(0.01) #183

#启动动作的线程(start the thread for executing actions) #185
th = threading.Thread(target=move) #186
th.daemon = True #187
th.start() #188

radius_data = [] #190
size = (320, 240) #191
def run(img): #192
    global radius_data #193
    global x_dis, y_dis #194
    global centerX, centerY, circle_radius #195
    
    img_copy = img.copy() #197
    img_h, img_w = img.shape[:2] #198
    
    if not __isRunning or __target_color == (): #200
        return img #201
    
    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #203
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #204
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #205
    
    area_max = 0 #207
    areaMaxContour = 0 #208
    for i in lab_data: #209
        if i in __target_color: #210
            detect_color = i #211
            frame_mask = cv2.inRange(frame_lab, #212
                                     (lab_data[i]['min'][0], #213
                                      lab_data[i]['min'][1], #214
                                      lab_data[i]['min'][2]), #215
                                     (lab_data[i]['max'][0], #216
                                      lab_data[i]['max'][1], #217
                                      lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #218
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #219
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #220
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contour) #221
            areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #222
    if areaMaxContour is not None and area_max > 100:  # 有找到最大面积(the maximal area is found) #223
        rect = cv2.minAreaRect(areaMaxContour)#最小外接矩形(the minimum bounding rectangle) #224
        box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #225
        for j in range(4): #226
            box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w)) #227
            box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h)) #228

        cv2.drawContours(img, [box], -1, (0,255,255), 2)#画出四个点组成的矩形(draw the rectangle formed by the four points) #230
        #获取矩形的对角点(get the diagonal points of the rectangle) #231
        ptime_start_x, ptime_start_y = box[0, 0], box[0, 1] #232
        pt3_x, pt3_y = box[2, 0], box[2, 1] #233
        radius = abs(ptime_start_x - pt3_x) #234
        centerX, centerY = int((ptime_start_x + pt3_x) / 2), int((ptime_start_y + pt3_y) / 2)#中心点(center point) #235
        cv2.circle(img, (centerX, centerY), 5, (0, 255, 255), -1)#画出中心点(draw the center point) #236
          
        use_time = 0        #238
        
        radius_data.append(radius) #240
        data = pd.DataFrame(radius_data) #241
        data_ = data.copy() #242
        u = data_.mean()  # 计算均值(calculate the average value) #243
        std = data_.std()  # 计算标准差(calculate standard deviation) #244

        data_c = data[np.abs(data - u) <= std] #246
        circle_radius = round(data_c.mean()[0], 1) #247
        if len(radius_data) == 5: #248
            radius_data.remove(radius_data[0]) #249

        # 设置水平舵机位置PID的目标值为图像宽度的一半(set the target value of the PID for the horizontal servo position to half of the image width) #251
        x_pid.SetPoint = img_w/2 #设定(set) #252
        x_pid.update(centerX) #当前(current) #253
        dx = int(x_pid.output) #254
        # 计算使用时间(calculate the usage time) #255
        use_time = abs(dx*0.00025) #256
        x_dis += dx #输出(output) #257
        
        # 将控制头部水平移动的舵机位置限制在预设范围内(limit the position of the servo controlling horizontal head movement within the preset range) #259
        x_dis = servo_data['servo2'] - 400 if x_dis < servo_data['servo2'] - 400 else x_dis           #260
        x_dis = servo_data['servo2'] + 400 if x_dis > servo_data['servo2'] + 400 else x_dis #261

        # 设置垂直舵机位置PID的目标值为图像高度的一半(set the target value of the PID for the vertical servo position to half of the image height) #263
        y_pid.SetPoint = img_h/2 #264
        y_pid.update(centerY) #265
        dy = int(y_pid.output) #266
        # 计算使用时间(calculate the usage time) #267
        use_time = round(max(use_time, abs(dy*0.00025)), 5) #268
        y_dis += dy #269
        
        # 将控制头部垂直移动的舵机位置限制在预设范围内(limit the position of the servo controlling vertical head movement within the preset range) #271
        y_dis = servo_data['servo1'] if y_dis < servo_data['servo1'] else y_dis #272
        y_dis = 2000 if y_dis > 2000 else y_dis     #273
        
        ctl.set_pwm_servo_pulse(1, y_dis, use_time*1000) #275
        ctl.set_pwm_servo_pulse(2, x_dis, use_time*1000) #276

        time.sleep(use_time) #278
    else: #279
        centerX, centerY = -1, -1 #280
   
    

    return img #284

if __name__ == '__main__': #286
    init() #287
    start() #288
    __target_color = ('red') #289
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #291
    if open_once: #292
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #293
    else: #294
        my_camera = Camera.Camera() #295
        my_camera.camera_open()  #296
    AGC.runActionGroup('stand') #297
    while True: #298
        ret, img = my_camera.read() #299
        if img is not None: #300
            frame = img.copy() #301
            Frame = run(frame)            #302
            cv2.imshow('Frame', Frame) #303
            key = cv2.waitKey(1) #304
            if key == 27: #305
                break #306
        else: #307
            time.sleep(0.01) #308
    my_camera.camera_close() #309
    cv2.destroyAllWindows() #310
