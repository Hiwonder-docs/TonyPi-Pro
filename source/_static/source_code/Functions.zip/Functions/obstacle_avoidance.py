#!/usr/bin/python3 #1
# coding=utf8 #2
import time #3
import VL53L0X #4
import threading #5
import hiwonder.ActionGroupControl as AGC #6


# Create a VL53L0X object #9
tof = VL53L0X.VL53L0X(i2c_bus=1,i2c_address=0x29) #10
tof.open() #11

# Start ranging #13
tof.start_ranging(VL53L0X.Vl53l0xAccuracyMode.BETTER) #14

timing = tof.get_timing() #16

if (timing < 20000): #18
    timing = 20000 #19
print ("Timing %d ms" % (timing/1000)) #20

AGC.runActionGroup('stand')  # 初始姿态(initial posture) #22

distance = None #24
last_distance = 999 #25

#执行动作组线程(execute action group thread) #27
def move(): #28
    global distance, last_distance #29
    while True: #30
        if distance is not None: #31
            if distance > 350: # 检测距离大于350mm时(when the detected distance is greater than 350mm) #32
                if last_distance <= 350: # 如果上次距离大于350mm, 说明是刚转到检测不到障碍物，但是没有完全转正(if the previous distance is greater than 350mm, it indicates that the robot has just turned and cannot detect obstacles, but has not fully straightened) #33
                    last_distance = distance #34
                    AGC.runActionGroup('turn_right', 3)  # 右转3次(turn right three times) #35
                else: #36
                    last_distance = distance #37
                    AGC.runActionGroup('go_forward')  # 直走(go straight) #38
            elif 150 < distance <= 350: # 检测距离在150-350mm时(when the detected distance is between 150 and 350 mm) #39
                last_distance = distance #40
                AGC.runActionGroup('turn_right')  # 右转(turn right) #41
            else: #42
                last_distance = distance #43
                AGC.runActionGroup('back_fast') # 后退(go backward) #44
        else: #45
            time.sleep(0.01) #46
        
#启动动作的线程(start the action thread) #48
th = threading.Thread(target=move) #49
th.daemon = True #50
th.start() #51

while True: #53
    distance = tof.get_distance() # 获取测距(obtain distance measurement) #54
    if (distance > 0): #55
        print ("%d mm" % distance) #56
    time.sleep(timing/1000000.00) #57
tof.stop_ranging()  # 关闭测距(close distance measurement) #58
tof.close() #59
