#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9

import hiwonder.Camera as Camera #11
import hiwonder.Misc as Misc #12
import hiwonder.ros_robot_controller_sdk as rrc #13
import hiwonder.yaml_handle as yaml_handle #14

# 初始化机器人底层驱动(initial robot underlying drivers) #16
board = rrc.Board() #17

range_rgb = { #19
    'red': (0, 0, 255), #20
    'blue': (255, 0, 0), #21
    'green': (0, 255, 0), #22
    'black': (0, 0, 0), #23
    'white': (255, 255, 255), #24
} #25

# 找出面积最大的轮廓(find out the contour with the maximal area) #27
# 参数为要比较的轮廓的列表(parameter is the list to be compared) #28
def getAreaMaxContour(contours): #29
    contour_area_temp = 0 #30
    contour_area_max = 0 #31
    areaMaxContour = None #32

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #34
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #35
        if contour_area_temp > contour_area_max: #36
            contour_area_max = contour_area_temp #37
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid; the contour with the largest area is used to filter out interference) #38
                areaMaxContour = c #39

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #41

lab_data = None #43
def load_config(): #44
    global lab_data, servo_data #45
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #47
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #48

load_config() #50

color_list = [] #52
detect_color = 'None' #53
draw_color = range_rgb["black"] #54
di_once = True #55
size = (320, 240) #56


def buzzer(): #59
    global di_once #60
    global detect_color #61
    while True: #62
        if detect_color == 'red' and di_once: #63
            board.set_buzzer(1900, 0.1, 0.9, 1)  # 以1900Hz的频率，持续响0.1秒，关闭0.9秒，重复1次(at a frequency of 1900Hz, sound for 0.1 seconds, then pause for 0.9 seconds, repeat once) #64
            di_once = False #65
        elif not di_once and detect_color != 'red': #66
            di_once = True #67
        else: #68
            time.sleep(0.01) #69
            
# 运行子线程(run sub-thread) #71
th = threading.Thread(target=buzzer) #72
th.daemon = True #73
th.start() #74

def run(img): #76
    global draw_color #77
    global color_list #78
    global detect_color #79
        
    img_copy = img.copy() #81
    img_h, img_w = img.shape[:2] #82

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #84
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #85
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #86

    max_area = 0 #88
    color_area_max = None     #89
    areaMaxContour_max = 0 #90
    
    for i in lab_data: #92
        if i != 'black' and i != 'white': #93
            frame_mask = cv2.inRange(frame_lab, #94
                                     (lab_data[i]['min'][0], #95
                                      lab_data[i]['min'][1], #96
                                      lab_data[i]['min'][2]), #97
                                     (lab_data[i]['max'][0], #98
                                      lab_data[i]['max'][1], #99
                                      lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #100
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #101
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #102
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contours) #103
            areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #104
            if areaMaxContour is not None: #105
                if area_max > max_area:#找最大面积(find the maximal area) #106
                    max_area = area_max #107
                    color_area_max = i #108
                    areaMaxContour_max = areaMaxContour #109
    
    if max_area > 200:  # 有找到最大面积(the maximal area is found) #111
        ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum bounding circumcircle) #112
        centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #113
        centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #114
        radius = int(Misc.map(radius, 0, size[0], 0, img_w))             #115
        cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #116
        
        if color_area_max == 'red':  #红色最大(red is the maximal area) #118
            detect_color = 'red' #119
            draw_color = range_rgb["red"]          #120
        elif color_area_max == 'green':  #绿色最大(green is the maximal area) #121
            detect_color = 'green' #122
            draw_color = range_rgb["green"]            #123
        elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #124
            detect_color = 'blue' #125
            draw_color = range_rgb["blue"]            #126
    else: #127
        detect_color = 'None' #128
        draw_color = range_rgb["black"] #129
    
    cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2)   #131
    return img #132

if __name__ == '__main__': #134
    from CameraCalibration.CalibrationConfig import * #135
    
    #加载参数(load parameters) #137
    param_data = np.load(calibration_param_path + '.npz') #138

    #获取参数(get parameters) #140
    mtx = param_data['mtx_array'] #141
    dist = param_data['dist_array'] #142
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #143
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #144

    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #146
    if open_once: #147
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #148
    else: #149
        my_camera = Camera.Camera() #150
        my_camera.camera_open() #151

    print("Color_Warning Init") #153
    print("Color_Warning Start") #154
    
    while True: #156
        ret, img = my_camera.read() #157
        if img is not None: #158
            frame = img.copy() #159
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #160
            Frame = run(frame) #161
            cv2.imshow('Frame', Frame) #162
            key = cv2.waitKey(1) #163
            if key == 27: #164
                break #165
        else: #166
            time.sleep(0.01) #167
    my_camera.camera_close() #168
    cv2.destroyAllWindows() #169
