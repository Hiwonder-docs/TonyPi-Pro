#!/usr/bin/python #1

# MIT License #3
# #4
# Copyright (c) 2017 John Bryan Moore #5
# #6
# Permission is hereby granted, free of charge, to any person obtaining a copy #7
# of this software and associated documentation files (the "Software"), to deal #8
# in the Software without restriction, including without limitation the rights #9
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell #10
# copies of the Software, and to permit persons to whom the Software is #11
# furnished to do so, subject to the following conditions: #12
# #13
# The above copyright notice and this permission notice shall be included in all #14
# copies or substantial portions of the Software. #15
# #16
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR #17
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, #18
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE #19
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER #20
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, #21
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE #22
# SOFTWARE. #23
from ctypes import CDLL, CFUNCTYPE, POINTER, c_int, c_uint, pointer, c_ubyte, c_uint8, c_uint32 #24
import sysconfig #25
import pkg_resources #26
SMBUS='smbus' #27
for dist in pkg_resources.working_set: #28
    #print(dist.project_name, dist.version) #29
    if dist.project_name == 'smbus': #30
        break #31
    if dist.project_name == 'smbus2': #32
        SMBUS='smbus2' #33
        break #34
if SMBUS == 'smbus': #35
    import smbus #36
elif SMBUS == 'smbus2': #37
    import smbus2 as smbus #38
import site #39


class Vl53l0xError(RuntimeError): #42
    pass #43


class Vl53l0xAccuracyMode: #46
    GOOD = 0        # 33 ms timing budget 1.2m range #47
    BETTER = 1      # 66 ms timing budget 1.2m range #48
    BEST = 2        # 200 ms 1.2m range #49
    LONG_RANGE = 3  # 33 ms timing budget 2m range #50
    HIGH_SPEED = 4  # 20 ms timing budget 1.2m range #51


class Vl53l0xDeviceMode: #54
    SINGLE_RANGING = 0 #55
    CONTINUOUS_RANGING = 1 #56
    SINGLE_HISTOGRAM = 2 #57
    CONTINUOUS_TIMED_RANGING = 3 #58
    SINGLE_ALS = 10 #59
    GPIO_DRIVE = 20 #60
    GPIO_OSC = 21 #61


class Vl53l0xGpioAlarmType: #64
    OFF = 0 #65
    THRESHOLD_CROSSED_LOW = 1 #66
    THRESHOLD_CROSSED_HIGH = 2 #67
    THRESHOLD_CROSSED_OUT = 3 #68
    NEW_MEASUREMENT_READY = 4 #69


class Vl53l0xInterruptPolarity: #72
    LOW = 0 #73
    HIGH = 1 #74


# Read/write function pointer types. #77
_I2C_READ_FUNC = CFUNCTYPE(c_int, c_ubyte, c_ubyte, POINTER(c_ubyte), c_ubyte) #78
_I2C_WRITE_FUNC = CFUNCTYPE(c_int, c_ubyte, c_ubyte, POINTER(c_ubyte), c_ubyte) #79

# Load VL53L0X shared lib #81

_TOF_LIBRARY = CDLL("./vl53l0x_python.so") #83

class VL53L0X: #85
    """VL53L0X ToF.""" #86
    def __init__(self, i2c_bus=1, i2c_address=0x29, tca9548a_num=255, tca9548a_addr=0): #87
        """Initialize the VL53L0X ToF Sensor from ST""" #88
        self._i2c_bus = i2c_bus #89
        self.i2c_address = i2c_address #90
        self._tca9548a_num = tca9548a_num #91
        self._tca9548a_addr = tca9548a_addr #92
        self._i2c = smbus.SMBus() #93
        self._dev = None #94
        # Resgiter Address #95
        self.ADDR_UNIT_ID_HIGH = 0x16 # Serial number high byte #96
        self.ADDR_UNIT_ID_LOW = 0x17 # Serial number low byte #97
        self.ADDR_I2C_ID_HIGH = 0x18 # Write serial number high byte for I2C address unlock #98
        self.ADDR_I2C_ID_LOW = 0x19 # Write serial number low byte for I2C address unlock #99
        self.ADDR_I2C_SEC_ADDR = 0x8a # Write new I2C address after unlock #100

    def open(self): #102
        self._i2c.open(bus=self._i2c_bus) #103
        self._configure_i2c_library_functions() #104
        self._dev = _TOF_LIBRARY.initialise(self.i2c_address, self._tca9548a_num, self._tca9548a_addr) #105

    def close(self): #107
        self._i2c.close() #108
        self._dev = None #109

    def _configure_i2c_library_functions(self): #111
        # I2C bus read callback for low level library. #112
        def _i2c_read(address, reg, data_p, length): #113
            ret_val = 0 #114
            result = [] #115

            try: #117
                result = self._i2c.read_i2c_block_data(address, reg, length) #118
            except IOError: #119
                ret_val = -1 #120

            if ret_val == 0: #122
                for index in range(length): #123
                    data_p[index] = result[index] #124

            return ret_val #126

        # I2C bus write callback for low level library. #128
        def _i2c_write(address, reg, data_p, length): #129
            ret_val = 0 #130
            data = [] #131

            for index in range(length): #133
                data.append(data_p[index]) #134
            try: #135
                self._i2c.write_i2c_block_data(address, reg, data) #136
            except IOError: #137
                ret_val = -1 #138

            return ret_val #140

        # Pass i2c read/write function pointers to VL53L0X library. #142
        self._i2c_read_func = _I2C_READ_FUNC(_i2c_read) #143
        self._i2c_write_func = _I2C_WRITE_FUNC(_i2c_write) #144
        _TOF_LIBRARY.VL53L0X_set_i2c(self._i2c_read_func, self._i2c_write_func) #145

    def start_ranging(self, mode=Vl53l0xAccuracyMode.GOOD): #147
        """Start VL53L0X ToF Sensor Ranging""" #148
        _TOF_LIBRARY.startRanging(self._dev, mode) #149

    def stop_ranging(self): #151
        """Stop VL53L0X ToF Sensor Ranging""" #152
        _TOF_LIBRARY.stopRanging(self._dev) #153

    def get_distance(self): #155
        """Get distance from VL53L0X ToF Sensor""" #156
        return _TOF_LIBRARY.getDistance(self._dev) #157

    # This function included to show how to access the ST library directly #159
    # from python instead of through the simplified interface #160
    def get_timing(self): #161
        budget = c_uint(0) #162
        budget_p = pointer(budget) #163
        status = _TOF_LIBRARY.VL53L0X_GetMeasurementTimingBudgetMicroSeconds(self._dev, budget_p) #164
        if status == 0: #165
            return budget.value + 1000 #166
        else: #167
            return 0 #168

    def configure_gpio_interrupt( #170
            self, proximity_alarm_type=Vl53l0xGpioAlarmType.THRESHOLD_CROSSED_LOW, #171
            interrupt_polarity=Vl53l0xInterruptPolarity.HIGH, threshold_low_mm=250, threshold_high_mm=500): #172
        """ #173
        Configures a GPIO interrupt from device, be sure to call "clear_interrupt" after interrupt is processed. #174
        """ #175
        pin = c_uint8(0)  # 0 is only GPIO pin. #176
        device_mode = c_uint8(Vl53l0xDeviceMode.CONTINUOUS_RANGING) #177
        functionality = c_uint8(proximity_alarm_type) #178
        polarity = c_uint8(interrupt_polarity) #179
        status = _TOF_LIBRARY.VL53L0X_SetGpioConfig(self._dev, pin, device_mode, functionality, polarity) #180
        if status != 0: #181
            raise Vl53l0xError('Error setting VL53L0X GPIO config') #182

        threshold_low = c_uint32(threshold_low_mm << 16) #184
        threshold_high = c_uint32(threshold_high_mm << 16) #185
        status = _TOF_LIBRARY.VL53L0X_SetInterruptThresholds(self._dev, device_mode, threshold_low, threshold_high) #186
        if status != 0: #187
            raise Vl53l0xError('Error setting VL53L0X thresholds') #188

        # Ensure any pending interrupts are cleared. #190
        self.clear_interrupt() #191

    def clear_interrupt(self): #193
        mask = c_uint32(0) #194
        status = _TOF_LIBRARY.VL53L0X_ClearInterruptMask(self._dev, mask) #195
        if status != 0: #196
            raise Vl53l0xError('Error clearing VL53L0X interrupt') #197

    def change_address(self, new_address): #199
        if self._dev is not None: #200
            raise Vl53l0xError('Error changing VL53L0X address') #201

        self._i2c.open(bus=self._i2c_bus) #203

        if new_address == None: #205
            return #206
        elif new_address == self.i2c_address: #207
            return #208
        else: #209
            # read value from 0x16,0x17 #210
            high = self._i2c.read_byte_data(self.i2c_address, self.ADDR_UNIT_ID_HIGH) #211
            low = self._i2c.read_byte_data(self.i2c_address, self.ADDR_UNIT_ID_LOW) #212

            # write value to 0x18,0x19 #214
            self._i2c.write_byte_data(self.i2c_address, self.ADDR_I2C_ID_HIGH, high) #215
            self._i2c.write_byte_data(self.i2c_address, self.ADDR_I2C_ID_LOW, low) #216

            # write new_address to 0x1a #218
            self._i2c.write_byte_data(self.i2c_address, self.ADDR_I2C_SEC_ADDR, new_address) #219

            self.i2c_address = new_address #221

        self._i2c.close() #223
