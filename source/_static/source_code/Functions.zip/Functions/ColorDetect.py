#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9
import hiwonder.Camera as Camera #10
import hiwonder.Misc as Misc #11
import hiwonder.ros_robot_controller_sdk as rrc #12
from hiwonder.Controller import Controller #13
import hiwonder.ActionGroupControl as AGC #14
import hiwonder.yaml_handle as yaml_handle #15


''' #18
    程序功能：颜色识别(program function: color recognition) #19

    运行效果：将红色小球放置到摄像头前，机器人在识别到后将会“点头”；将蓝色或绿色小球放置 #21
             到摄像头前，机器人识别到后将会“摇头”。(running effect: place the red ball in front of the camera. The robot will 'nod' once it recognizes it. Place the blue or green ball in front of the camera. The robot will 'shake its head' once it recognizes it) #22


    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第3课 颜色识别(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\3.AI Vision Game Course\Lesson3 Color Recognition) #25
''' #26

# 调试模式标志量(debug mode flag variable) #28
debug = False #29

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #31
if sys.version_info.major == 2: #32
    print('Please run this program with python3!') #33
    sys.exit(0) #34

range_rgb = { #36
    'red': (0, 0, 255), #37
    'blue': (255, 0, 0), #38
    'green': (0, 255, 0), #39
    'black': (0, 0, 0), #40
    'white': (255, 255, 255), #41
} #42

# 找出面积最大的轮廓(find the contour with the maximal area) #44
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #45
def getAreaMaxContour(contours): #46
    contour_area_temp = 0 #47
    contour_area_max = 0 #48
    areaMaxContour = None #49

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #51
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #52
        if contour_area_temp > contour_area_max: #53
            contour_area_max = contour_area_temp #54
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid; the contour with the largest area is used to filter out interference) #55
                areaMaxContour = c #56

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #58

board = rrc.Board() #60
ctl = Controller(board) #61


lab_data = None #64
servo_data = None #65

# 加载配置文件数据(load configuration file data) #67
def load_config(): #68
    global lab_data, servo_data #69
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #71
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #72

# 初始化机器人舵机初始位置(initialize the servo initialization position of robot) #74
def initMove(): #75
    ctl.set_pwm_servo_pulse(1, 1500, 500) #76
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #77
   
    
color_list = [] #80
detect_color = 'None' #81
action_finish = True #82
draw_color = range_rgb["black"] #83
# 变量重置(variable reset) #84
def reset(): #85
    global draw_color #86
    global color_list #87
    global detect_color #88
    global action_finish #89
    
    color_list = [] #91
    detect_color = 'None' #92
    action_finish = True #93
    draw_color = range_rgb["black"] #94

# app初始化调用(app initialization calling) #96
def init(): #97
    print("ColorDetect Init") #98
    load_config() #99
    initMove() #100

__isRunning = False #102
# app开始玩法调用(app start program calling) #103
def start(): #104
    global __isRunning #105
    reset() #106
    __isRunning = True #107
    print("ColorDetect Start") #108

# app停止玩法调用(app stop program calling) #110
def stop(): #111
    global __isRunning #112
    __isRunning = False #113
    print("ColorDetect Stop") #114

# app退出玩法调用(app exit program calling) #116
def exit(): #117
    global __isRunning #118
    __isRunning = False #119
    AGC.runActionGroup('stand_slow') #120
    print("ColorDetect Exit") #121


def move(): #124
    global draw_color #125
    global detect_color #126
    global action_finish #127

    while True: #129
        if debug: #130
            return      #131
        if __isRunning: #132
            if detect_color != 'None': #133
                action_finish = False #134

                if detect_color == 'red': #136
                    ctl.set_pwm_servo_pulse(1, 1800, 200) #137
                    time.sleep(0.2) #138
                    ctl.set_pwm_servo_pulse(1, 1200, 200) #139
                    time.sleep(0.2) #140
                    ctl.set_pwm_servo_pulse(1, 1800, 200) #141
                    time.sleep(0.2) #142
                    ctl.set_pwm_servo_pulse(1, 1200, 200) #143
                    time.sleep(0.2) #144
                    ctl.set_pwm_servo_pulse(1, 1500, 100) #145
                    time.sleep(0.1) #146

                    detect_color = 'None' #148
                    draw_color = range_rgb["black"]                     #149
                    time.sleep(1) #150

                elif detect_color == 'green' or detect_color == 'blue': #152
                    ctl.set_pwm_servo_pulse(2, 1800, 200) #153
                    time.sleep(0.2) #154
                    ctl.set_pwm_servo_pulse(2, 1200, 200) #155
                    time.sleep(0.2) #156
                    ctl.set_pwm_servo_pulse(2, 1800, 200) #157
                    time.sleep(0.2) #158
                    ctl.set_pwm_servo_pulse(2, 1200, 200) #159
                    time.sleep(0.2) #160
                    ctl.set_pwm_servo_pulse(2, 1500, 100) #161
                    time.sleep(0.1) #162
                    detect_color = 'None' #163
                    draw_color = range_rgb["black"]                     #164
                    time.sleep(1) #165
                else: #166
                    time.sleep(0.01)                 #167
                action_finish = True                 #168
                detect_color = 'None' #169
            else: #170
               time.sleep(0.01) #171
        else: #172
            time.sleep(0.01) #173

# 运行子线程(run sub-thread) #175
th = threading.Thread(target=move) #176
th.daemon = True #177
th.start() #178

size = (320, 240) #180
def run(img): #181
    global draw_color #182
    global color_list #183
    global detect_color #184
    global action_finish #185
    
    img_copy = img.copy() #187
    img_h, img_w = img.shape[:2] #188

    if not __isRunning: #190
        return img #191

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #193
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #194
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #195

    max_area = 0 #197
    color_area_max = None     #198
    areaMaxContour_max = 0 #199
    
    if action_finish: #201
        for i in lab_data: #202
            if i != 'black' and i != 'white': #203
                frame_mask = cv2.inRange(frame_lab, #204
                                         (lab_data[i]['min'][0], #205
                                          lab_data[i]['min'][1], #206
                                          lab_data[i]['min'][2]), #207
                                         (lab_data[i]['max'][0], #208
                                          lab_data[i]['max'][1], #209
                                          lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #210
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #211
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #212
                if debug: #213
                    cv2.imshow(i, dilated) #214
                contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contours) #215
                areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #216
                if areaMaxContour is not None: #217
                    if area_max > max_area:#找最大面积(find the maximal area) #218
                        max_area = area_max #219
                        color_area_max = i #220
                        areaMaxContour_max = areaMaxContour #221
        if max_area > 200:  # 有找到最大面积(the maximal area is found) #222
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum bounding circumcircle) #223
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #224
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #225
            radius = int(Misc.map(radius, 0, size[0], 0, img_w))             #226
            cv2.circle(img, (centerX, centerY), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #227

            if color_area_max == 'red':  #红色最大(red is the maximal area) #229
                color = 1 #230
            elif color_area_max == 'green':  #绿色最大(green is the maximal area) #231
                color = 2 #232
            elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #233
                color = 3 #234
            else: #235
                color = 0 #236
            color_list.append(color) #237

            if len(color_list) == 3:  #多次判断(multiple judgement) #239
                # 取平均值(take average value) #240
                color = int(round(np.mean(np.array(color_list)))) #241
                color_list = [] #242
                if color == 1: #243
                    detect_color = 'red' #244
                    draw_color = range_rgb["red"] #245
                elif color == 2: #246
                    detect_color = 'green' #247
                    draw_color = range_rgb["green"] #248
                elif color == 3: #249
                    detect_color = 'blue' #250
                    draw_color = range_rgb["blue"] #251
                else: #252
                    detect_color = 'None' #253
                    draw_color = range_rgb["black"]                #254
        else: #255
            detect_color = 'None' #256
            draw_color = range_rgb["black"] #257
            
    cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2) #259
    
    return img #261

if __name__ == '__main__': #263
    from CameraCalibration.CalibrationConfig import * #264
    
    param_data = np.load(calibration_param_path + '.npz') #266
    
    mtx = param_data['mtx_array'] #268
    dist = param_data['dist_array'] #269
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #270
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #271
   
    debug = False #273
    if debug: #274
        print('Debug Mode') #275
        
    init() #277
    start() #278
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #279
    if open_once: #280
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #281
    else: #282
        my_camera = Camera.Camera() #283
        my_camera.camera_open()              #284
    AGC.runActionGroup('stand') #285
    while True: #286
        ret, img = my_camera.read() #287
        if ret: #288
            frame = img.copy() #289
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 鐣稿彉鐭 #290
            Frame = run(frame) #291
            cv2.imshow('Frame', Frame) #292
            key = cv2.waitKey(1) #293
            if key == 27: #294
                break #295
        else: #296
            time.sleep(0.01) #297
    my_camera.camera_close() #298
    cv2.destroyAllWindows() #299
