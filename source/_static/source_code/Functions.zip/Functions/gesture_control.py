#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# 指尖轨迹点发布 #3
import cv2 #4
import math #5
import enum #6
import time #7
import queue #8
import threading #9
import numpy as np #10
import faulthandler #11
import mediapipe as mp #12
import hiwonder.Camera as Camera #13
import hiwonder.ActionGroupControl as AGC #14
import hiwonder.yaml_handle as yaml_handle #15
from hiwonder.Controller import Controller #16
import hiwonder.ros_robot_controller_sdk as rrc #17

faulthandler.enable() #19
def distance(point_1, point_2): #20
    """ #21
    计算两个点间的距离(calculate the distance between two points) #22
    :param point_1: 点1 #23
    :param point_2: 点2 #24
    :return: 两点间的距离(distance between two points) #25
    """ #26
    return math.sqrt((point_1[0] - point_2[0]) ** 2 + (point_1[1] - point_2[1]) ** 2) #27

def vector_2d_angle(v1, v2): #29
    """ #30
    计算两向量间的夹角 -pi ~ pi(calculate the angle between two vectors -pi ~ pi) #31
    :param v1: 第一个向量(first vector) #32
    :param v2: 第二个向量(second vector) #33
    :return: 角度(angle) #34
    """ #35
    d_v1_v2 = np.linalg.norm(v1) * np.linalg.norm(v2) #36
    cos = v1.dot(v2) / (d_v1_v2) #37
    sin = np.cross(v1, v2) / (d_v1_v2) #38
    angle = np.degrees(np.arctan2(sin, cos)) #39
    return angle #40

def get_hand_landmarks(img, landmarks): #42
    """ #43
    将landmarks从medipipe的归一化输出转为像素坐标 #44
    :param img: 像素坐标对应的图片 #45
    :param landmarks: 归一化的关键点 #46
    :return: #47
    """ #48
    h, w, _ = img.shape #49
    landmarks = [(lm.x * w, lm.y * h) for lm in landmarks] #50
    return np.array(landmarks) #51

def hand_angle(landmarks): #53
    """ #54
    计算各个手指的弯曲角度 #55
    :param landmarks: 手部关键点 #56
    :return: 各个手指的角度 #57
    """ #58
    angle_list = [] #59
    # thumb 大拇指 #60
    angle_ = vector_2d_angle(landmarks[3] - landmarks[4], landmarks[0] - landmarks[2]) #61
    angle_list.append(angle_) #62
    # index 食指 #63
    angle_ = vector_2d_angle(landmarks[0] - landmarks[6], landmarks[7] - landmarks[8]) #64
    angle_list.append(angle_) #65
    # middle 中指 #66
    angle_ = vector_2d_angle(landmarks[0] - landmarks[10], landmarks[11] - landmarks[12]) #67
    angle_list.append(angle_) #68
    # ring 无名指 #69
    angle_ = vector_2d_angle(landmarks[0] - landmarks[14], landmarks[15] - landmarks[16]) #70
    angle_list.append(angle_) #71
    # pink 小拇指 #72
    angle_ = vector_2d_angle(landmarks[0] - landmarks[18], landmarks[19] - landmarks[20]) #73
    angle_list.append(angle_) #74
    angle_list = [abs(a) for a in angle_list] #75
    return angle_list #76

def h_gesture(angle_list): #78
    """ #79
    通过二维特征确定手指所摆出的手势 #80
    :param angle_list: 各个手指弯曲的角度 #81
    :return : 手势名称字符串 #82
    """ #83
    thr_angle = 65. #84
    thr_angle_thumb = 53. #85
    thr_angle_s = 49. #86
    gesture_str = "none" #87
    if (angle_list[0] > thr_angle_thumb) and (angle_list[1] > thr_angle) and (angle_list[2] > thr_angle) and ( #88
            angle_list[3] > thr_angle) and (angle_list[4] > thr_angle): #89
        gesture_str = "fist" #90
    elif (angle_list[0] < thr_angle_s) and (angle_list[1] < thr_angle_s) and (angle_list[2] > thr_angle) and ( #91
            angle_list[3] > thr_angle) and (angle_list[4] > thr_angle): #92
        gesture_str = "hand_heart" #93
    elif (angle_list[0] < thr_angle_s) and (angle_list[1] < thr_angle_s) and (angle_list[2] > thr_angle) and ( #94
            angle_list[3] > thr_angle) and (angle_list[4] < thr_angle_s): #95
        gesture_str = "nico-nico-ni" #96
    elif (angle_list[0] < thr_angle_s) and (angle_list[1] > thr_angle) and (angle_list[2] > thr_angle) and ( #97
            angle_list[3] > thr_angle) and (angle_list[4] > thr_angle): #98
        gesture_str = "hand_heart" #99
    elif (angle_list[0] > 5) and (angle_list[1] < thr_angle_s) and (angle_list[2] > thr_angle) and ( #100
            angle_list[3] > thr_angle) and (angle_list[4] > thr_angle): #101
        gesture_str = "one" #102
    elif (angle_list[0] > thr_angle_thumb) and (angle_list[1] < thr_angle_s) and (angle_list[2] < thr_angle_s) and ( #103
            angle_list[3] > thr_angle) and (angle_list[4] > thr_angle): #104
        gesture_str = "two" #105
    elif (angle_list[0] > thr_angle_thumb) and (angle_list[1] < thr_angle_s) and (angle_list[2] < thr_angle_s) and ( #106
            angle_list[3] < thr_angle_s) and (angle_list[4] > thr_angle): #107
        gesture_str = "three" #108
    elif (angle_list[0] > thr_angle_thumb) and (angle_list[1] > thr_angle) and (angle_list[2] < thr_angle_s) and ( #109
            angle_list[3] < thr_angle_s) and (angle_list[4] < thr_angle_s): #110
        gesture_str = "OK" #111
    elif (angle_list[0] > thr_angle_thumb) and (angle_list[1] < thr_angle_s) and (angle_list[2] < thr_angle_s) and ( #112
            angle_list[3] < thr_angle_s) and (angle_list[4] < thr_angle_s): #113
        gesture_str = "four" #114
    elif (angle_list[0] < thr_angle_s) and (angle_list[1] < thr_angle_s) and (angle_list[2] < thr_angle_s) and ( #115
            angle_list[3] < thr_angle_s) and (angle_list[4] < thr_angle_s): #116
        gesture_str = "five" #117
    elif (angle_list[0] < thr_angle_s) and (angle_list[1] > thr_angle) and (angle_list[2] > thr_angle) and ( #118
            angle_list[3] > thr_angle) and (angle_list[4] < thr_angle_s): #119
        gesture_str = "six" #120
    else: #121
        "none" #122
    return gesture_str #123

class State(enum.Enum): #125
    NULL = 0 #126
    START = 1 #127
    TRACKING = 2 #128
    RUNNING = 3 #129

def draw_points(img, points, thickness=4, color=(0, 0, 255)): #131
    points = np.array(points).astype(dtype=np.int64) #132
    if len(points) > 2: #133
        for i, p in enumerate(points): #134
            if i + 1 >= len(points): #135
                break #136
            cv2.line(img, p, points[i + 1], color, thickness) #137
# 颜色阈值数据和头部舵机位置数据(color threshold data and head servo position data) #138
servo_data = None #139
board = rrc.Board() #140
ctl = Controller(board) #141
# 加载配置文件数据(load configuration file data) #142
def load_config(): #143
    global servo_data #144
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #146
    # print(servo_data)         #147

load_config() #149

# 初始化机器人舵机初始位置(initialize the servo initialization position of robot) #151
def initMove(): #152
    ctl.set_pwm_servo_pulse(1, 1500, 500) #153
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #154
drawing = mp.solutions.drawing_utils #155

hand_detector = mp.solutions.hands.Hands( #157
     static_image_mode=False, #158
    max_num_hands=1, #159
    min_tracking_confidence=0.05, #160
    min_detection_confidence=0.6 #161
) #162

state = State.NULL #164
count = 0 #165
start_move = False #166
last_point = [0, 0] #167
points = [] #168
points_list = [] #169
running = False #170
def reset(): #171
    global state, count, start_move, last_point, points, points_list #172
    state = State.NULL #173
    count = 0 #174
    start_move = False #175
    last_point = [0, 0] #176
    points = [] #177
    points_list = [] #178

enter = False #180
running = False #181
# app初始化调用(app initialization calling) #182
def init(): #183
    global enter #184
    print('gesture init') #185
    reset() #186
    initMove() #187
    enter = True #188
    AGC.runActionGroup('stand') #189

# app开始玩法调用(app start program calling) #191
def start(): #192
    global running #193
    print('gesture start') #194
    running = True #195

# app停止玩法调用(app stop program calling) #197
def stop(): #198
    global running #199
    print('gesture stop') #200
    reset() #201
    running = False #202
    initMove() #203
    AGC.runActionGroup('stand') #204

# app退出玩法调用(app exit program calling) #206
def exit(): #207
    global running, enter #208
    print('gesture exit') #209
    reset() #210
    enter = False #211
    running = False #212

def action_thread(): #214
    global last_point, start_move #215
    while True: #216
        if start_move and running: #217
            points = [] #218
            left_and_right = [0] #219
            up_and_down = [0] #220
            for i in target_points: #221
                if i[0] - last_point[0] > 0: #222
                    left_and_right.append(1) #223
                else: #224
                    left_and_right.append(-1) #225
                if i[1] - last_point[1] > 0: #226
                    up_and_down.append(1) #227
                else: #228
                    up_and_down.append(-1) #229
                points.extend([i]) #230
                last_point = i #231
            left_and_right = sum(left_and_right) #232
            up_and_down = sum(up_and_down) #233
            points = np.array(points) #234
            
            line = cv2.fitLine(points, cv2.DIST_L2, 0, 0.01, 0.01) #236
            vx, vy, x0, y0 = line.flatten()   #237
            projections = (points[:, 0] - x0) * vx + (points[:, 1] - y0) * vy #238

            t_min = projections.min() #240
            t_max = projections.max() #241

            line_segment_length = t_max - t_min #243
            angle = int(abs(math.degrees(math.acos(line[0][0])))) #244
            step = round(line_segment_length/70) #245
            print('>>>>>>', angle) #246
            if 90 >= angle > 60: #247
                if up_and_down > 0: #248
                    AGC.runActionGroup('back_fast', step, True) #249
                    print('down') #250
                else: #251
                    AGC.runActionGroup('go_forward', step, True) #252
                    print('up') #253
            elif 30 > angle >= 0: #254
                if left_and_right > 0: #255
                    AGC.runActionGroup('left_move', step, True) #256
                    print('right') #257
                else: #258
                    AGC.runActionGroup('right_move', step, True) #259
                    print('left') #260
            start_move = False #261
        else: #262
            time.sleep(0.1) #263

#启动动作的线程(start the thread of executing action) #265
threading.Thread(target=action_thread, daemon=True).start() #266

def run(image): #268
    global state, count, points, points_list, target_points, start_move #269

    image = cv2.flip(image, 1) #271
    display_image = image.copy() #272
    if not enter: #273
        return display_image #274
    if running: #275
        try: #276
            results = hand_detector.process(image) #277
            if results is not None and results.multi_hand_landmarks: #278
                gesture = "none" #279
                index_finger_tip = [0, 0] #280
                for hand_landmarks in results.multi_hand_landmarks: #281
                    drawing.draw_landmarks( #282
                        display_image, #283
                        hand_landmarks, #284
                        mp.solutions.hands.HAND_CONNECTIONS) #285
                    landmarks = get_hand_landmarks(image, hand_landmarks.landmark) #286
                    angle_list = (hand_angle(landmarks)) #287
                    gesture = (h_gesture(angle_list)) #288
                    index_finger_tip = landmarks[8].tolist() #289
                if state != State.TRACKING: #290
                    if gesture == "one":  # 检测食指手势， 开始指尖追踪 #291
                        count += 1 #292
                        if count > 5: #293
                            count = 0 #294
                            state = State.TRACKING #295
                            points = [] #296
                            points_list = [] #297
                    else: #298
                        count = 0 #299

                elif state == State.TRACKING: #301
                    if gesture != "two": #302
                        if len(points) > 0: #303
                            last_point = points[-1] #304
                            if distance(last_point, index_finger_tip) < 5: #305
                                count += 1 #306
                            else: #307
                                count = 0 #308
                                points_list.append([int(index_finger_tip[0]), int(index_finger_tip[1])]) #309
                                points.append(index_finger_tip) #310
                        else: #311
                            points_list.append([int(index_finger_tip[0]), int(index_finger_tip[1])]) #312
                            points.append(index_finger_tip) #313
                    draw_points(display_image, points) #314
                if gesture == "five": #315
                    state = State.NULL #316
                    if len(points_list) > 10 and not start_move: #317
                        board.set_buzzer(1900, 0.1, 0.9, 1) #318
                        target_points = points_list #319
                        start_move = True #320
                    points = [] #321
                    points_list = [] #322
                    draw_points(display_image, points) #323
        except Exception as e: #324
            print(e) #325
    return display_image #326

if __name__ == "__main__": #328
    init() #329
    start() #330
    
    my_camera = Camera.Camera() #332
    my_camera.camera_open()               #333
    t = time.time() #334
    while True: #335
        ret, img = my_camera.read() #336
        if ret: #337
            frame = img.copy() #338
            frame = run(frame)            #339
            cv2.imshow('result_image', frame) #340
            d = time.time() - t #341
            if d < 0.02: #342
                key = cv2.waitKey(int((0.02 - d)*1000)) #343
            else: #344
                key = cv2.waitKey(1) #345
            if key == 27: #346
                break #347
            t = time.time() #348
        else: #349
            time.sleep(0.01) #350
    my_camera.camera_close() #351
    cv2.destroyAllWindows() #352
