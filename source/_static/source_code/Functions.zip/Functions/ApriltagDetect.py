#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import cv2 #4
import math #5
import time #6
import threading #7
import numpy as np #8

import hiwonder.Camera as Camera #10
import hiwonder.Misc as Misc #11
import hiwonder.ros_robot_controller_sdk as rrc #12
from hiwonder.Controller import Controller #13
import hiwonder.ActionGroupControl as AGC #14
import hiwonder.yaml_handle as yaml_handle #15
import hiwonder.apriltag as apriltag #16



''' #20
    程序功能：标签识别(program function: tag recognition) #21

    运行效果：玩法开启后，取出附带的标签卡片，依次对准摄像头模块进行识别。当识别到后，机器人便执行对应的动作。(running effect: "after the game mode is activated, take out the accompanying tag cards and align them with the camera module for recognition one by one.  #23
    When recognized, the robot will perform the corresponding action) #24

    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第7课 标签识别(corresponding tutorial file path: TonyPi Intelligent Humanoid Robot\3.AI Vision Game Course\Lesson7 Tag Recognition) #26
''' #27

if sys.version_info.major == 2: #29
    print('Please run this program with python3!') #30
    sys.exit(0) #31

# 调试模式标志量(debug mode flag variable) #33
debug = False #34

board = rrc.Board() #36
ctl = Controller(board) #37

# 初始化机器人舵机初始位置(initialize servo initialization position of robot) #39
def initMove(): #40
    ctl.set_pwm_servo_pulse(1, 1500, 500) #41
    ctl.set_pwm_servo_pulse(2, 1500, 500) #42

    
tag_id = None #45
__isRunning = False #46
action_finish = True #47
# 变量重置(variable reset) #48
def reset():       #49
    global tag_id #50
    global action_finish #51
    
    tag_id = 0 #53
    action_finish = True #54
    
# app初始化调用(app initialization calling) #56
def init(): #57
    print("Apriltag Init") #58
    initMove() #59

# app开始玩法调用(app start program calling) #61
def start(): #62
    global __isRunning #63
    reset() #64
    __isRunning = True #65
    print("Apriltag Start") #66

# app停止玩法调用(app stop program calling) #68
def stop(): #69
    global __isRunning #70
    __isRunning = False #71
    print("Apriltag Stop") #72

# app退出玩法调用(app exit program calling) #74
def exit(): #75
    global __isRunning #76
    __isRunning = False #77
    AGC.runActionGroup('stand_slow') #78
    print("Apriltag Exit") #79

def move(): #81
    global tag_id #82
    global action_finish   #83
    
    while True: #85
        if debug: #86
            return #87
        if __isRunning: #88
            if tag_id is not None: #89
                action_finish = False #90
                time.sleep(0.5) #91
                if tag_id == 1:#标签ID为1时(when tag ID is 1) #92
                    AGC.runActionGroup('bow')#鞠躬(bow) #93
                    tag_id = None #94
                    time.sleep(1)                   #95
                    action_finish = True                 #96
                elif tag_id == 2:                     #97
                    AGC.runActionGroup('stepping')#原地踏步(march in place) #98
                    tag_id = None #99
                    time.sleep(1) #100
                    action_finish = True           #101
                elif tag_id == 3:                    #102
                    AGC.runActionGroup('twist')#扭腰(twist your waist) #103
                    tag_id = None #104
                    time.sleep(1) #105
                    action_finish = True #106
                else: #107
                    action_finish = True #108
                    time.sleep(0.01) #109
            else: #110
               time.sleep(0.01) #111
        else: #112
            time.sleep(0.01) #113

# 运行子线程(run sub-thread) #115
th = threading.Thread(target=move) #116
th.daemon = True #117
th.start() #118

# 检测apriltag(detect apriltag) #120
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #121
def apriltagDetect(img):    #122
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #123
    detections = detector.detect(gray, return_image=False) #124

    if len(detections) != 0: #126
        for detection in detections:                        #127
            corners = np.int0(detection.corners)  # 获取四个角点(get four corner points) #128
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 2) #129

            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #131
            tag_id = int(detection.tag_id)  # 获取tag_id(get tag_id) #132

            object_center_x, object_center_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #134
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation angle) #136
            
            return tag_family, tag_id #138
            
    return None, None #140

def run(img): #142
    global tag_id #143
    global action_finish #144
     
    img_copy = img.copy() #146
    img_h, img_w = img.shape[:2] #147

    if not __isRunning: #149
        return img #150
    
    tag_family, tag_id = apriltagDetect(img) # apriltag检测(apriltag detection) #152
    
    if tag_id is not None: #154
        cv2.putText(img, "tag_id: " + str(tag_id), (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #155
        cv2.putText(img, "tag_family: " + tag_family, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #156
    else: #157
        cv2.putText(img, "tag_id: None", (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #158
        cv2.putText(img, "tag_family: None", (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 255, 255], 2) #159
    
    return img #161

if __name__ == '__main__': #163
    from CameraCalibration.CalibrationConfig import * #164
    
    #加载参数(load parameters) #166
    param_data = np.load(calibration_param_path + '.npz') #167

    #获取参数(get parameters) #169
    mtx = param_data['mtx_array'] #170
    dist = param_data['dist_array'] #171
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #172
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #173
    
    debug = False #175
    if debug: #176
        print('Debug Mode') #177
        
    init() #179
    start() #180
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #182
    if open_once: #183
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #184
    else: #185
        my_camera = Camera.Camera() #186
        my_camera.camera_open()          #187
    AGC.runActionGroup('stand') #188
    while True: #189
        ret, img = my_camera.read() #190
        if ret: #191
            frame = img.copy() #192
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #193
            Frame = run(frame)            #194
            cv2.imshow('Frame', Frame) #195
            key = cv2.waitKey(1) #196
            if key == 27: #197
                break #198
        else: #199
            time.sleep(0.01) #200
    my_camera.camera_close() #201
    cv2.destroyAllWindows() #202
