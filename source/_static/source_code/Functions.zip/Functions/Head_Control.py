#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import time #4
import hiwonder.ros_robot_controller_sdk as rrc #5
from hiwonder.Controller import Controller #6

# 初始化机器人底层驱动(initialize the robot underlying drivers) #8
board = rrc.Board() #9
ctl = Controller(board) #10

def nod_head(): #12
        ctl.set_pwm_servo_pulse(1, 1800, 200) #13
        time.sleep(0.2) #14
        ctl.set_pwm_servo_pulse(1, 1200, 200) #15
        time.sleep(0.2) #16
        ctl.set_pwm_servo_pulse(1, 1800, 200) #17
        time.sleep(0.2) #18
        ctl.set_pwm_servo_pulse(1, 1200, 200) #19
        time.sleep(0.2) #20
        ctl.set_pwm_servo_pulse(1, 1500, 100) #21
        time.sleep(0.1) #22
        

def shake_head(): #25
        ctl.set_pwm_servo_pulse(2, 1800, 200) #26
        time.sleep(0.2) #27
        ctl.set_pwm_servo_pulse(2, 1200, 200) #28
        time.sleep(0.2) #29
        ctl.set_pwm_servo_pulse(2, 1800, 200) #30
        time.sleep(0.2) #31
        ctl.set_pwm_servo_pulse(2, 1200, 200) #32
        time.sleep(0.2) #33
        ctl.set_pwm_servo_pulse(2, 1500, 100) #34
        time.sleep(0.1) #35
        

if __name__ == '__main__': #38

    print("Head_Control Init") #40
    print("Head_Control Start") #41
    while True: #42
        print("I am nodding!") #43
        time.sleep(0.2) #44
        nod_head() #45
        time.sleep(0.5) #46
        
        print("I am shaking head!") #48
        time.sleep(0.2) #49
        shake_head() #50
        time.sleep(0.5) #51

        key = time.sleep(0.1) #53
        if key == 27: #54
            break #55
        
        
