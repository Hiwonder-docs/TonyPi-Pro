#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import cv2 #4
import math #5
import time #6
import numpy as np #7

import hiwonder.Camera as Camera #9
import hiwonder.ros_robot_controller_sdk as rrc #10
import hiwonder.yaml_handle as yaml_handle #11
import hiwonder.apriltag as apriltag #12
# 检测apriltag(detect apriltag) #13

board = rrc.Board() #15

beer = True #17
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #18
def apriltagDetect(img):    #19
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #20
    detections = detector.detect(gray, return_image=False) #21

    if len(detections) != 0: #23
        for detection in detections:                        #24
            corners = np.int0(detection.corners)  # 获取四个角点(get four corner points) #25
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 2) #26
            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #27
            tag_id = int(detection.tag_id)  # 获取tag_id(get tag_id) #28

            object_center_x, object_center_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #30
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation angle) #32
            
            return tag_family, tag_id #34
    return None, None #35

def run(img): #37
    global tag_id #38
    global action_finish #39
    global beer #40

    tag_id = 0 #42
    action_finish = True #43
    img_copy = img.copy() #44
    img_h, img_w = img.shape[:2] #45

    tag_family, tag_id = apriltagDetect(img) # apriltag检测(apriltag detection) #47
    
    if tag_id is not None: #49
        cv2.putText(img, "tag_id: " + str(tag_id), (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 0, 255], 2) #50
        cv2.putText(img, "tag_family: " + tag_family, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 0, 255], 2) #51
        if beer == True: #52
                board.set_buzzer(1900, 0.1, 0.9, 1) # 以1900Hz的频率，持续响0.1秒，关闭0.9秒，重复1次(at a frequency of 1900Hz, sound for 0.1 seconds, then pause for 0.9 seconds, repeat once) #53
                
        beer = False #55
         
    else: #57
        cv2.putText(img, "tag_id: None", (10, img.shape[0] - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 0, 255], 2) #58
        cv2.putText(img, "tag_family: None", (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, [0, 0, 255], 2) #59
    
        beer = True #61
               
    return img #63

if __name__ == '__main__': #65
    from CameraCalibration.CalibrationConfig import * #66
    
    #加载参数(load parameters) #68
    param_data = np.load(calibration_param_path + '.npz') #69

    #获取参数(get parameters) #71
    mtx = param_data['mtx_array'] #72
    dist = param_data['dist_array'] #73
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) # 调节视场大小(adjust the field of view size) #74
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #获取畸变参数(get distortion parameters) #75

    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #77
    if open_once: #78
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #79
    else: #80
        my_camera = Camera.Camera() #81
        my_camera.camera_open() #82


    print("Tag_Detect Init") #85
    print("Tag_Detect Start") #86
    while True: #87
        ret, img = my_camera.read() #88
        if img is not None: #89
            frame = img.copy() #90
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #91
            Frame = run(frame)            #92
            cv2.imshow('Frame', Frame) #93
            key = cv2.waitKey(1) #94
            if key == 27: #95
                break #96
        else: #97
            time.sleep(0.01) #98
    my_camera.camera_close() #99
    cv2.destroyAllWindows() #100
