#!/usr/bin/env python3 #1
# encoding: utf-8 #2
import os #3
import cv2 #4
import math #5
import copy #6
import threading #7
import numpy as np #8
import mediapipe as mp #9
from hiwonder import fps #10
from mediapipe import solutions #11
from mediapipe.tasks import python #12
import hiwonder.yaml_handle as yaml_handle #13
from hiwonder.Controller import Controller #14
from mediapipe.tasks.python import vision #15
import hiwonder.ros_robot_controller_sdk as rrc #16
from mediapipe.framework.formats import landmark_pb2 #17
from mediapipe_visual import draw_pose_landmarks_on_image #18

board = rrc.Board() #20
ctl = Controller(board) #21

servo_data = None #23
# 加载配置文件数据(load configuration file data) #24
def load_config(): #25
    global servo_data #26
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #28

load_config() #30

x_dis = servo_data['servo2'] #32
y_dis = 1500 #33

ctl.set_pwm_servo_pulse(1, y_dis, 500) #35
ctl.set_pwm_servo_pulse(2, x_dis, 500) #36

def val_map(x, in_min, in_max, out_min, out_max): #38
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min #39

def vector_2d_angle(v1, v2): #41
    d_v1_v2 = np.linalg.norm(v1) * np.linalg.norm(v2) #42
    if d_v1_v2 == 0: #43
        return None #44

    cos = np.dot(v1, v2) / d_v1_v2 #46
    cos = np.clip(cos, -1.0, 1.0) #47

    sin = np.cross(v1, v2) / d_v1_v2 #49
    sin = np.clip(sin, -1.0, 1.0) #50
    angle = int(np.degrees(np.arctan2(sin, cos))) #51
    return angle #52

l1 = 0.06 #54
l2 = 0.11 #55
board = rrc.Board() #56
model_path = os.path.join(os.path.abspath(os.path.split(os.path.realpath(__file__))[0]), 'model/pose_landmarker_lite.task') #57
base_options = python.BaseOptions(model_asset_path=model_path) #58
options = vision.PoseLandmarkerOptions( #59
    base_options=base_options, #60
    output_segmentation_masks=True) #61
detector = vision.PoseLandmarker.create_from_options(options) #62
fps = fps.FPS() #63

last_angle = [] #65
cap = cv2.VideoCapture(-1) #66
while True: #67
    ret, image = cap.read() #68
    if ret: #69
        image = cv2.flip(cv2.cvtColor(image, cv2.COLOR_BGR2RGB), 1) #70
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=image) #71
        detection_result = detector.detect(mp_image) #72
        height, width, _ = image.shape #73
        pose_landmarks_list = detection_result.pose_landmarks #74
        annotated_image = np.copy(image) #75
        for idx in range(len(pose_landmarks_list)): #76
            pose_landmarks = pose_landmarks_list[idx] #77

            # Draw the pose landmarks. #79
            pose_landmarks_proto = landmark_pb2.NormalizedLandmarkList() #80
            pose_landmarks_proto.landmark.extend([ #81
              landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in pose_landmarks #82
            ]) #83
            mark = [] #84
            landmarks = pose_landmarks[11:17] #85
            for landmark in landmarks: #86
                result = landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) #87
                mark.append([int(result.x * width) , int(result.y * height)]) #88
            for i in mark: #89
                cv2.circle(annotated_image, i, 10, (255, 255, 0), -1) #90
            left_p1 = mark[0] #91
            left_p2 = mark[2] #92
            left_p3 = mark[4] #93
            right_p1 = mark[1] #94
            right_p2 = mark[3] #95
            right_p3 = mark[5] #96
            # cv2.line(annotated_image, left_p1, (width, left_p1[1]), (255, 255, 0), 5) #97
            cv2.line(annotated_image, left_p1, left_p2, (255, 255, 0), 5) #98
            cv2.line(annotated_image, left_p2, left_p3, (255, 255, 0), 5) #99
            cv2.line(annotated_image, right_p1, right_p2, (255, 255, 0), 5) #100
            cv2.line(annotated_image, right_p2, right_p3, (255, 255, 0), 5) #101
            left_p0 = copy.deepcopy(mark[0]) #102
            left_p0[0] = width #103
            right_p0 = copy.deepcopy(mark[1]) #104
            right_p0[0] = 0 #105
            # up-90 0 90down #106
            # up 0 1000down #107
            angle1 = vector_2d_angle(np.array(left_p1) - np.array(left_p0), np.array(left_p1) - np.array(left_p2)) #108
            angle2 = vector_2d_angle(np.array(left_p2) - np.array(left_p1), np.array(left_p3) - np.array(left_p2))  #109
            # 90 -90 #110
            # 1000 0 #111
            angle3 = vector_2d_angle(np.array(right_p1) - np.array(right_p0), np.array(right_p1) - np.array(right_p2)) #112
            angle4 = vector_2d_angle(np.array(right_p2) - np.array(right_p1), np.array(right_p3) - np.array(right_p2)) #113
            if angle1 is not None and angle2 is not None and angle3 is not None and angle4 is not None: #114
                # print(angle1, angle2, angle3, angle4)  #115
                x1 = l1 * math.cos(math.radians(angle1)) + l2 * math.cos((math.radians(angle2)) + math.radians(angle1)) #116
                x2 = l1 * math.cos(math.radians(angle3)) + l2 * math.cos((math.radians(angle4)) + math.radians(angle3)) #117
                # print(x1, x2) #118
                servo7 = int(val_map(angle1, -90, 90, 125, 875)) #119
                servo6 = int(val_map(angle2, -90, 90, 125, 875)) #120
                servo15 = int(val_map(angle3, -90, 90, 125, 875)) #121
                servo14 = int(val_map(angle4, -90, 90, 125, 875)) #122
                if servo6 > 875: #123
                    servo6 = 875 #124
                if servo6 < 125: #125
                    servo6 = 125 #126
                if servo7 > 875: #127
                    servo7 = 875 #128
                if servo7 < 125: #129
                    servo7 = 125 #130
                if servo14 > 875: #131
                    servo14 = 875 #132
                if servo14 < 125: #133
                    servo14 = 125 #134
                if servo15 > 875: #135
                    servo15 = 875 #136
                if servo15 < 125: #137
                    servo15 = 125 #138
                if last_angle: #139
                    if abs(last_angle[0] - servo6) < 30: #140
                        servo6 = last_angle[0] #141
                    if abs(last_angle[1] - servo7) < 30: #142
                        servo7 = last_angle[1] #143
                    if abs(last_angle[2] - servo14) < 30: #144
                        servo14 = last_angle[2] #145
                    if abs(last_angle[3] - servo15) < 30: #146
                        servo15 = last_angle[3] #147
                if x1 > 0 and x2 > 0: #148
                    board.bus_servo_set_position(0.1, [[7, servo7], [6, servo6], [14, servo14], [15, servo15]]) #149
                elif x1 > 0 and x2 < 0: #150
                    board.bus_servo_set_position(0.05, [[7, servo7], [6, servo6]]) #151
                elif x1 < 0 and x2 > 0: #152
                    board.bus_servo_set_position(0.05, [[14, servo14], [15, servo15]]) #153

                solutions.drawing_utils.draw_landmarks( #155
                  annotated_image, #156
                  pose_landmarks_proto, #157
                  solutions.pose.POSE_CONNECTIONS, #158
                  solutions.drawing_styles.get_default_pose_landmarks_style()) #159
                last_angle = [servo6, servo7, servo14, servo15] #160
        fps.update() #161
        result_image = fps.show_fps(cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR)) #162
        cv2.imshow('pose_landmarker', result_image) #163
        key = cv2.waitKey(1) #164
        if key == ord('q') or key == 27:  # 按q或者esc退出(press q or esc to exit) #165
            break #166
cv2.destroyAllWindows() #167
