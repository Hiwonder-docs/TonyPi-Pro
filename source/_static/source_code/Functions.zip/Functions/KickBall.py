#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9

import hiwonder.PID as PID #11
import hiwonder.Misc as Misc #12
import hiwonder.Camera as Camera #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17
from hiwonder.common import ColorPicker #18


''' #21
    程序功能：自动踢球(program function: auto shooting) #22

    运行效果：将红色小球放置在机器人摄像头前，在识别到后机器人将会调整位置靠向小球，并将其 #24
             踢向前方。(running effect: place the red ball in front of the robot's camera. Once recognized, the robot will adjust its position towards the ball and kick it forward) #25

    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第2课 自动踢球(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\3.AI Vision Game Course\Lesson2 Auto Shooting) #27
''' #28

if __name__ == '__main__': #30
    from CameraCalibration.CalibrationConfig import * #31
else: #32
    from Functions.CameraCalibration.CalibrationConfig import * #33


# 调试模式标志量(debug mode flag variable) #36
debug = False #37

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #39
if sys.version_info.major == 2: #40
    print('Please run this program with python3!') #41
    sys.exit(0) #42

#加载参数(load parameters) #44
param_data = np.load(calibration_param_path + '.npz') #45

#获取参数(get parameters) #47
mtx = param_data['mtx_array'] #48
dist = param_data['dist_array'] #49
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #50
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #51

# 找出面积最大的轮廓(find out the contour with the maximal area) #53
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #54
def getAreaMaxContour(contours): #55
    contour_area_temp = 0 #56
    contour_area_max = 0 #57
    areaMaxContour = None #58

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #60
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #61
        if contour_area_temp > contour_area_max: #62
            contour_area_max = contour_area_temp #63
            if 640*480/100 > contour_area_temp > 2:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #64
                areaMaxContour = c #65

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #67

board = rrc.Board() #69
ctl = Controller(board) #70

target_color = [] #72

# 颜色阈值数据和头部舵机位置数据(color threshold data and head servo position data) #74
servo_data = None #75

# 加载配置文件数据(load configuration file data) #77
def load_config(): #78
    global servo_data #79
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)                                 #81

load_config() #83

# 初始化机器人舵机初始位置(initialize the servo initialization position of robot) #85
def initMove(): #86
    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #87
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #88


# 初始化开始计时的时间戳(initialize the timestamp for starting the timer) #91
t1 = 0 #92

# 初始化舵机移动水平方向和垂直方向的步长(initialize the step size for servo movement in the horizontal and vertical directions) #94
d_x = 20 #95
d_y = 20 #96

# 初始化主步骤step（检测到球时的情况）和子步骤step_（未检测到球时的情况）(initialize the main step (when the ball is detected) and sub-step (when the ball is not detected)) #98
step = 1 #99
step_ = 1 #100

# 设置舵机位置(set servo position) #102
x_dis = servo_data['servo2'] #103
y_dis   = servo_data['servo1'] #104

# 初始化机器人上一步的状态(initialize the previous state of the robot) #106
last_status = '' #107

# 初始化开始计时的标志量(initialize the flag variable for starting the timer) #109
start_count= True #110

# 初始化球的中心坐标(initialize the center coordinates of ball) #112
CenterX, CenterY = -2, -2 #113

# 初始化 PID 控制器(initialize PID controller) #115
x_pid = PID.PID(P=0.145, I=0.00, D=0.0007) #116
y_pid = PID.PID(P=0.145, I=0.00, D=0.0007) #117


# 重置所有变量为初始状态(reset all the variable to initial state) #120
def reset(): #121
    global t1                          #122
    global d_x, d_y #123
    global last_status #124
    global start_count #125
    global step, step_ #126
    global x_dis, y_dis #127
    global target_color #128
    global CenterX, CenterY #129
    global color_picker #130

    t1 = 0 #132
    d_x = 20 #133
    d_y = 20 #134
    step = 1 #135
    step_ = 1 #136
    x_pid.clear() #137
    y_pid.clear() #138
    x_dis = servo_data['servo2'] #139
    y_dis = servo_data['servo1'] #140
    last_status = '' #141
    start_count= True #142
    target_color = [] #143
    CenterX, CenterY = -2, -2 #144
    color_picker = None #145
    
# app初始化调用(app initialization calling) #147
def init(): #148
    global enter #149
    print("kick_ball Init")  #150
    enter = True #151
    load_config() #152
    initMove() #153

# 机器人是否运行的标志量(the flag variable indicating whether the robot is running) #155
enter = False #156
running = False #157
# app开始玩法调用(app start program calling) #158
def start(): #159
    global running  #160
    running = True #161
    print("KickBall Start") #162

# app停止玩法调用(app stop program calling) #164
def stop(): #165
    global running  #166
    
    reset() #168
    running = False #169
    print("KickBall Stop") #170

# app退出玩法调用(app exit program calling) #172
def exit(): #173
    global enter, running #174
    enter = False #175
    running = False #176
    reset() #177
    AGC.runActionGroup('stand_slow') #178
    print("KickBall Exit") #179

color_picker = None #181
def set_point(point): #182
    global color_picker, target_color #183
    x, y = point #184
    target_color = [] #185
    color_picker = ColorPicker([x, y], 20) #186

    return (True, (), 'set_point')  #188

def get_rgb_value(): #190
    if target_color: #191
        return target_color[1] #192
    else: #193
        return [] #194

threshold = 0.3 #196
def set_threshold(value): #197
    global threshold #198
    threshold = value #199
    print(1111, threshold) #200
    return (True, (), 'set_threshold') #201

# 图像中心横坐标(the horizontal coordinate of the image center) #203
CENTER_X = 320 #204

#机器人运动控制(robot movement control) #206
def move(): #207
    global t1                    #208
    global d_x          #209
    global d_y            #210
    global step                     #211
    global step_                      #212
    global x_dis     #213
    global y_dis      #214
    global last_status             #215
    global start_count            #216
    global enter              #217
    
    while True: #219
        if debug:      # 如果 debug 模式打开，则直接返回不执行后面的操作(if the debug mode is enabled, return directly without executing the subsequent operations) #220
            return #221
        if enter and running: #222
            if CenterX >= 0 :      # 如果检测到了球(if the ball is detected) #223
                step_ = 1                       #224
                d_x, d_y = 20, 20 #225
                start_count= True            # 开始计时标志置为True，在后面找不到球的情况下使用(the flag for starting the timer is set to True, to be used when the ball is not found later on) #226
               
                if step == 1:       #228
                    # 球不在画面中心，则根据方向让机器人转向一步，直到满足条件进入步骤2(if the ball is not in the center of the frame, instruct the robot to turn one step in the direction until the condition is met to enter step 2) #229
                    if x_dis - servo_data['servo2'] > 150: #230
                        AGC.runActionGroup('turn_left_small_step') #231
                    elif x_dis - servo_data['servo2'] < -150: #232
                        AGC.runActionGroup('turn_right_small_step') #233
                    else: #234
                        step = 2 #235

                elif step == 2: #237
                    # 当控制头部垂直运动的舵机位置等于设定的位置(when the position of the servo controlling vertical head movement equals the set position) #238
                    if y_dis == servo_data['servo1']:      #239
                        # 根据当前水平舵机位置调整机器人运动(adjust the robot's movement based on the current horizontal servo position) #240
                        if x_dis == servo_data['servo2'] - 400: #241
                            AGC.runActionGroup('turn_right',2) #242
                        elif x_dis == servo_data['servo2'] + 400: #243
                            AGC.runActionGroup('turn_left',2) #244
                        elif 350 < CenterY <= 380:    # ball_center_y值越大，与球的距离越近(the larger the value of ball_center_y, the closer the distance to the ball) #245
                            AGC.runActionGroup('go_forward_one_step') #246
                            last_status = 'go'        # 记录上一步的状态是往前走(record the previous step state as walking forward) #247
                            step = 1 #248
                        elif 120 < CenterY <= 350: #249
                            AGC.runActionGroup('go_forward') #250
                            last_status = 'go' #251
                            step = 1 #252
                        elif 0 <= CenterY <= 120 and abs(x_dis - servo_data['servo2']) <= 200: #253
                            AGC.runActionGroup('go_forward_fast') #254
                            last_status = 'go' #255
                            step = 1 #256
                        else: #257
                            step = 3 #258
                    else: #259
                        # 当控制头部垂直运动的舵机位置不等于设定的位置，机器人调整位置往前走，直到两个位置相等(when the position of the servo controlling vertical head movement is not equal to the set position, the robot adjusts its position to move forward until the two positions are equal) #260
                        if x_dis == servo_data['servo2'] - 400: #261
                            AGC.runActionGroup('turn_right',2) #262
                        elif x_dis == servo_data['servo2'] + 400: #263
                            AGC.runActionGroup('turn_left',2) #264
                        else: #265
                            AGC.runActionGroup('go_forward_fast') #266
                            last_status = 'go' #267

                elif step == 3: #269
                    if y_dis == servo_data['servo1']: #270
                        # 根据球在画面的x坐标左右平移调整位置(adjust the position based on the left-right movement of the ball's x-coordinate in the frame) #271
                        if abs(CenterX - CENTER_X) <= 40: #272
                            AGC.runActionGroup('left_move') #273
                        elif 0 < CenterX < CENTER_X - 50 - 40: #274
                            AGC.runActionGroup('left_move_fast') #275
                            time.sleep(0.2) #276
                        elif CENTER_X + 50 + 40 < CenterX:                       #277
                            AGC.runActionGroup('right_move_fast') #278
                            time.sleep(0.2) #279
                        else: #280
                            step = 4  #281
                    else: #282
                        if 270 <= x_dis - servo_data['servo2'] < 480: #283
                            AGC.runActionGroup('left_move_fast') #284
                            time.sleep(0.2) #285
                        elif abs(x_dis - servo_data['servo2']) < 170: #286
                            AGC.runActionGroup('left_move') #287
                        elif -480 < x_dis - servo_data['servo2'] <= -270:                       #288
                            AGC.runActionGroup('right_move_fast') #289
                            time.sleep(0.2) #290
                        else: #291
                            step = 4                    #292
                elif step == 4: #293
                    if y_dis == servo_data['servo1']: #294
                        # 小步伐靠近到合适的距离(take small steps to approach at the appropriate distance) #295
                        if 380 < CenterY <= 440: #296
                            AGC.runActionGroup('go_forward_one_step') #297
                            last_status = 'go' #298
                        elif 0 <= CenterY <= 380: #299
                            AGC.runActionGroup('go_forward') #300
                            last_status = 'go' #301
                        else:   # 根据最后球的x坐标，采用离得近的脚去踢球(use closest foot to kick the ball based on the final x-coordinates of the ball) #302
                            AGC.runActionGroup('go_forward_one_step') #303
                            if CenterX < CENTER_X: #304
                                AGC.runActionGroup('left_shot_fast') #305
                            else: #306
                                AGC.runActionGroup('right_shot_fast') #307
                            step = 1 #308
                    else: #309
                        step = 1 #310

            elif CenterX == -1:   # 如果没检测到球(if no ball is detected) #312
                # 如果机器人上次状态为“前进”，快速后退一步(if the robot's previous state was 'forward,' quickly take one step backward) #313
                if last_status == 'go': #314
                    last_status = '' #315
                    AGC.runActionGroup('back_fast', with_stand=True)                    #316
                elif start_count:  # 开始计时的标志变量为True(the flag variable for starting the timer is set to True) #317
                    start_count= False #318
                    t1 = time.time()    # 记录当前的时间，开始计时(record the current time and start the timer) #319
                else: #320
                    if time.time() - t1 > 0.5: #321
                        
                        if step_ == 5: #323
                            x_dis += d_x #324
                            if abs(x_dis - servo_data['servo2']) <= abs(d_x): #325
                                AGC.runActionGroup('turn_right') #326
                                step_ = 1 #327
                        if step_ == 1 or step_ == 3: #328
                            x_dis += d_x             #329
                            if x_dis > servo_data['servo2'] + 400: #330
                                if step_ == 1: #331
                                    step_ = 2 #332
                                d_x = -d_x #333
                            elif x_dis < servo_data['servo2'] - 400: #334
                                if step_ == 3: #335
                                    step_ = 4 #336
                                d_x = -d_x #337
                        elif step_ == 2 or step_ == 4: #338
                            y_dis += d_y #339
                            if y_dis > 1200: #340
                                if step_ == 2: #341
                                    step_ = 3 #342
                                d_y = -d_y #343
                            elif y_dis < servo_data['servo1']: #344
                                if step_ == 4:                                 #345
                                    step_ = 5 #346
                                d_y = -d_y #347
                        ctl.set_pwm_servo_pulse(1, y_dis, 20) #348
                        ctl.set_pwm_servo_pulse(2, x_dis, 20) #349
                        
                        time.sleep(0.02) #351
            else: #352
                time.sleep(0.01) #353
        else: #354
            time.sleep(0.1) #355

#启动动作的线程(start the thread of executing action) #357
th = threading.Thread(target=move) #358
th.daemon = True #359
th.start() #360

size = (320, 240) #362

imgw, img_h = None, None #364
def run(img): #365
    global x_dis, y_dis #366
    global CenterX, CenterY #367
    global last_status #368
    global target_color #369
    global img_w, img_h #370
    global color_picker #371

    display_image = img.copy() #373
    img_h, img_w = img.shape[:2]    # 获取图像高度和宽度(get the height and width of the image) #374
    
    if not enter: #376
        # 如果robot_is_running不为True或者没有设置球的颜色(if robot_is_running is not True or the ball color is not set) #377
        if debug: #378
            # 在调试模式下输出参考线(in debug mode, output reference lines) #379
            cv2.line(display_image, (0, 450), (img_w, 450), (0, 255, 255), 2) #380
            cv2.line(display_image, (0, 380), (img_w, 380), (0, 255, 255), 2) #381
            cv2.line(display_image, (0, 300), (img_w, 300), (0, 255, 255), 2) #382
        return display_image #383
    # print(color_picker, target_color) #384
    if color_picker is not None and not target_color:   #385
        target_color, display_image = color_picker(img, display_image) #386
        if target_color: #387
            color_picker = None #388
        # print(target_color) #389
    elif target_color: #390
        # 重新调整图像大小(resize the image) #391
        frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #392
        # 高斯模糊(Gaussian blur) #393
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #394
        # 将图像转换到LAB色彩空间(convert the image to LAB color space) #395
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)   #396
        
        min_color = [int(target_color[0][0] - 50 * threshold * 2), #398
                     int(target_color[0][1] - 50 * threshold), #399
                     int(target_color[0][2] - 50 * threshold)] #400
        max_color = [int(target_color[0][0] + 50 * threshold * 2), #401
                     int(target_color[0][1] + 50 * threshold), #402
                     int(target_color[0][2] + 50 * threshold)] #403
        #对原图像和掩模进行位运算(perform bitwise operation to the original image and mask) #404
        frame_mask = cv2.inRange(frame_lab, tuple(min_color), tuple(max_color)) #405
        #腐蚀(corrosion) #406
        eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))   #407
        #膨胀(dilation) #408
        dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #409
        if debug: #410
            # 在调试模式下显示掩模(display mask in the debug mode) #411
            cv2.imshow('dilate', dilated) #412
        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contour) #413
        # 找出设定范围内的最大轮廓，返回轮廓和轮廓的面积(find the largest contour within the specified range and return the contour and its area) #414
        areaMaxContour, area_max = getAreaMaxContour(contours)   #415
        if areaMaxContour is not None:  # 如果找到最大面积的轮廓(if the contour with the maximal area is found) #416
            try: #417
                (CenterX, CenterY), radius = cv2.minEnclosingCircle(areaMaxContour) #获取最小外接圆(get the minimum circumcircle) #418
            except BaseException as e: #419
                print(e) #420
                # display_image = cv2.remap(img, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #421
                return display_image #422
            # 将球的中心坐标和半径映射回原始图像尺寸(map the center coordinates and radius of the ball back to the original image size) #423
            CenterX = int(Misc.map(CenterX, 0, size[0], 0, img_w)) #424
            CenterY = int(Misc.map(CenterY, 0, size[1], 0, img_h)) #425
            radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #426
            use_time = 0        #427
            if running:  #428
                if y_dis == servo_data['servo1'] and abs(x_dis - servo_data['servo2']) < 150: #429
                    x_dis = servo_data['servo2'] #430
                else: #431
                    # 设置水平舵机位置PID的目标值为图像宽度的一半(set the target value of the PID for the horizontal servo position to half of the image width) #432
                    x_pid.SetPoint = img_w / 2 #433
                    
                    x_pid.update(CenterX) #435

                    d_x = int(x_pid.output) #437
                   
                    last_status = 'left' if d_x > 0 else 'right' #439
                    # 计算使用时间(calculate usage time) #440
                    use_time = abs(d_x * 0.00025) #441
                    x_dis += d_x     #442

                    # 将控制头部水平移动的舵机位置限制在预设范围内(limit the position of the servo controlling horizontal head movement within the preset range) #444
                    x_dis = servo_data['servo2'] - 400 if x_dis < servo_data['servo2'] - 400 else x_dis           #445
                    x_dis = servo_data['servo2'] + 400 if x_dis > servo_data['servo2'] + 400 else x_dis #446
                    
                # 设置垂直舵机位置PID的目标值为图像高度的一半(set the target value of the PID for the vertical servo position to half of the image height) #448
                y_pid.SetPoint = img_h / 2 #449
                y_pid.update(CenterY) #450
                
                d_y = int(y_pid.output) #452
                # 计算使用时间(calculate usage time) #453
                use_time = round(max(use_time, abs(d_y * 0.00025)), 5) #454
                # 更新垂直舵机位置(update vertical servo position) #455
                y_dis += d_y #456
                
                # 将控制头部垂直移动的舵机位置限制在预设范围内(limit the position of the servo controlling vertical head movement within the preset range) #458
                y_dis = servo_data['servo1'] if y_dis < servo_data['servo1'] else y_dis #459
                y_dis = 1200 if y_dis > 1200 else y_dis     #460
                
                ctl.set_pwm_servo_pulse(1, y_dis, use_time*1000) #462
                ctl.set_pwm_servo_pulse(2, x_dis, use_time*1000) #463
                time.sleep(use_time) #464
            
            # 在图像上绘制球的轮廓和参考线(draw the contour of the ball and reference lines on the image) #466
            cv2.circle(display_image, (CenterX, CenterY), radius, (0, 255, 255), 2) #467
            cv2.line(display_image, (int(CenterX - radius/2), CenterY), (int(CenterX + radius/2), CenterY), (0, 255, 255), 2) #468
            cv2.line(display_image, (CenterX, int(CenterY - radius/2)), (CenterX, int(CenterY + radius/2)), (0, 255, 255), 2) #469
        else: #470
            # 未识别到球时x，y坐标均返回-1(when the ball is not recognized, both the x and y coordinates return -1) #471
            CenterX, CenterY = -1, -1 #472
   
    if debug: #474
        # 在调试模式下显示舵机位置和参考线(in debug mode, display the servo position and reference lines) #475
        cv2.putText(display_image, "x_dis: " + str(x_dis), (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 255), 2) #476
        cv2.line(display_image, (0, 450), (img_w, 450), (0, 255, 255), 2) #477
        cv2.line(display_image, (0, 380), (img_w, 380), (0, 255, 255), 2) #478
        cv2.line(display_image, (0, 300), (img_w, 300), (0, 255, 255), 2)  #479

    return display_image #481

if __name__ == '__main__': #483
    def mouse_callback(event, x, y, flags, param): #484
        global color_picker #485
        if event == cv2.EVENT_LBUTTONDOWN: #486
            color_picker = ColorPicker([x/img_w, y/img_h], 20) #487
            # print(x, y) #488
        elif event == cv2.EVENT_RBUTTONDOWN: #489
            color_picker = None #490
            init() #491
            reset() #492
    debug = False #493
    if debug: #494
        print('Debug Mode') #495
    
    init() #497
    start() #498
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #500
    if open_once: #501
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #502
    else: #503
        my_camera = Camera.Camera() #504
        my_camera.camera_open()               #505
    AGC.runActionGroup('stand') #506
    t = time.time() #507
    while True: #508
        ret, img = my_camera.read() #509
        if ret: #510
            frame = img.copy() #511
            Frame = run(frame)            #512
            cv2.imshow('result_image', Frame) #513
            cv2.setMouseCallback("result_image", mouse_callback) #514
            d = time.time() - t #515
            if d < 0.02: #516
                key = cv2.waitKey(int((0.02 - d)*1000)) #517
            else: #518
                key = cv2.waitKey(1) #519
            if key == 27: #520
                break #521
            t = time.time() #522
        else: #523
            time.sleep(0.01) #524
    my_camera.camera_close() #525
    cv2.destroyAllWindows() #526
