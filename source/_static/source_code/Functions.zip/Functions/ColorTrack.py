#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9

import hiwonder.PID as PID #11
import hiwonder.Misc as Misc #12
import hiwonder.Camera as Camera #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17
from hiwonder.common import ColorPicker #18

''' #20
    程序功能：颜色追踪(program function: color tracking) #21

    运行效果：玩法开启后，手持红色小球进行缓慢移动，机器人头部将随着目标颜色的移动而跟随转动(running effect: after the game mode is activated, move the red ball slowly by hand. The robot's head will follow the movement of the target color) #23

    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第5课 颜色追踪(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\3.AI Intelligent Game Course\Lesson5 Color Tracking) #25
''' #26

# 调试模式标志量(debug mode flag variable) #28
debug = False #29
color_picker = None #30
# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #31
if sys.version_info.major == 2: #32
    print('Please run this program with python3!') #33
    sys.exit(0) #34

target_color = [] #36

# 找出面积最大的轮廓(find the contour with the maximal area) #38
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #39
def getAreaMaxContour(contours): #40
    contour_area_temp = 0 #41
    contour_area_max = 0 #42
    areaMaxContour = None #43

    for c in contours:  # 历遍所有轮廓(iterate through all the contours) #45
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #46
        if contour_area_temp > contour_area_max: #47
            contour_area_max = contour_area_temp #48
            if contour_area_temp > 10:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #49
                areaMaxContour = c #50

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #52

board = rrc.Board() #54
ctl = Controller(board) #55

servo_data = None #57
# 加载配置文件数据(load configuration file data) #58
def load_config(): #59
    global servo_data #60
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #62

load_config() #64

x_dis = servo_data['servo2'] #66
y_dis = 1500 #67

# 初始位置(initial position) #69
def initMove(): #70
    ctl.set_pwm_servo_pulse(1, y_dis, 500) #71
    ctl.set_pwm_servo_pulse(2, x_dis, 500) #72
    
    
x_pid = PID.PID(P=0.145, I=0.00, D=0.0007)#pid初始化(pid initialization) #75
y_pid = PID.PID(P=0.145, I=0.00, D=0.0007) #76

# 变量重置(variable reset) #78
def reset(): #79
    global x_dis, y_dis #80
    global target_color #81
    global color_picker #82
       
    x_dis = servo_data['servo2'] #84
    y_dis = 1500 #85
    x_pid.clear() #86
    y_pid.clear() #87
    target_color = [] #88
    color_picker = None #89

# app初始化调用(app initialization calling) #91
def init(): #92
    global enter #93
    print("ColorTrack Init") #94
    initMove() #95
    # load_config() #96
    enter = True #97

enter = False #99
running = False #100
# app开始玩法调用(app start program calling) #101
def start(): #102
    global running #103
    running = True #104
    print("ColorTrack Start") #105

# app停止玩法调用(app stop program calling) #107
def stop(): #108
    global running #109
    running = False #110
    reset() #111
    
    initMove() #113
    print("ColorTrack Stop") #114

# app退出玩法调用(app exit program calling) #116
def exit(): #117
    global enter, running #118
    enter = False #119
    running = False #120
    reset() #121
    AGC.runActionGroup('stand_slow') #122
    print("ColorTrack Exit") #123

color_picker = None #125
def set_point(point): #126
    global color_picker, target_color #127
    x, y = point #128
    target_color = [] #129
    color_picker = ColorPicker([x, y], 20) #130

    return (True, (), 'set_point')  #132

def get_rgb_value(): #134
    if target_color: #135
        return target_color[1]  #136
    else: #137
        return [] #138

threshold = 0.3 #140
def set_threshold(value): #141
    global threshold #142
    threshold = value #143
    return (True, (), 'set_threshold') #144

size = (320, 240) #146
img_w, img_h = None, None #147
def run(img): #148
    global x_dis, y_dis, target_color #149
    global img_w, img_h #150
    global color_picker #151

    display_image = img.copy() #153
    img_h, img_w = img.shape[:2] #154
    
    if not enter: #156
        return display_image #157

    cv2.line(display_image, (int(img_w/2 - 10), int(img_h/2)), (int(img_w/2 + 10), int(img_h/2)), (0, 255, 255), 2) #159
    cv2.line(display_image, (int(img_w/2), int(img_h/2 - 10)), (int(img_w/2), int(img_h/2 + 10)), (0, 255, 255), 2) #160

    if color_picker is not None and not target_color:   #162
        target_color, display_image = color_picker(img, display_image) #163
        if target_color: #164
            color_picker = None #165
    elif target_color: #166
        frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #167
        frame_gb = cv2.GaussianBlur(frame_resize, (5, 5), 5)    #168
        frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #169
        
        min_color = [int(target_color[0][0] - 50 * threshold * 2), #171
                     int(target_color[0][1] - 50 * threshold), #172
                     int(target_color[0][2] - 50 * threshold)] #173
        max_color = [int(target_color[0][0] + 50 * threshold * 2), #174
                     int(target_color[0][1] + 50 * threshold), #175
                     int(target_color[0][2] + 50 * threshold)] #176
        #对原图像和掩模进行位运算(perform bitwise operation to the original image and mask) #177
        frame_mask = cv2.inRange(frame_lab, tuple(min_color), tuple(max_color)) #178
        eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #179
        dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #180
        if debug: #181
            cv2.imshow('dilate', dilated) #182
        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contours) #183
        areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #184
        if areaMaxContour is not None:  # 有找到最大面积(find the maximal area) #185
            (centerX, centerY), radius = cv2.minEnclosingCircle(areaMaxContour) #获取最小外接圆(get the minimum bounding circumcircle) #186
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #187
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #188
            radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #189
            cv2.circle(display_image, (int(centerX), int(centerY)), int(radius), (0, 255, 255), 2) #190
            if running:  #191
                use_time = 0     #192
                
                if abs(centerX - img_w/2.0) < 20: # 移动幅度比较小，则不需要动(if the movement amplitude is small, then no need to move) #194
                    centerX = img_w/2.0  #195

                x_pid.SetPoint = img_w/2 #设定(set) #197
                x_pid.update(centerX) #当前(current) #198
                dx = int(x_pid.output) #199
                use_time = abs(dx*0.00025) #200
                x_dis += dx #输出(output) #201
                
                x_dis = 500 if x_dis < 500 else x_dis           #203
                x_dis = 2500 if x_dis > 2500 else x_dis #204


                if abs(centerY - img_h/2.0) < 20: # 移动幅度比较小，则不需要动(if the movement amplitude is small, then no need to move) #207
                    centerY = img_h/2.0   #208
               
                y_pid.SetPoint = img_h/2 #210
                y_pid.update(centerY) #211
                dy = int(y_pid.output) #212
            
                use_time = round(max(use_time, abs(dy*0.00025)), 5) #214
                
                y_dis += dy #216
                
                y_dis = 1000 if y_dis < 1000 else y_dis #218
                y_dis = 2000 if y_dis > 2000 else y_dis     #219
                
                if not debug: #221
                    ctl.set_pwm_servo_pulse(1, y_dis, use_time*1000) #222
                    ctl.set_pwm_servo_pulse(2, x_dis, use_time*1000) #223
                    time.sleep(use_time) #224
            
    return display_image #226

if __name__ == '__main__': #228
    from CameraCalibration.CalibrationConfig import * #229
    def mouse_callback(event, x, y, flags, param): #230
        global color_picker #231
        if event == cv2.EVENT_LBUTTONDOWN: #232
            color_picker = ColorPicker([x/img_w, y/img_h], 20) #233
            # print(x, y) #234
        elif event == cv2.EVENT_RBUTTONDOWN: #235
            color_picker = None #236
            init() #237
            reset()     #238
    #加载参数(load parameters) #239
    param_data = np.load(calibration_param_path + '.npz') #240

    #获取参数(get parameters) #242
    mtx = param_data['mtx_array'] #243
    dist = param_data['dist_array'] #244
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #245
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #246
    
    debug = False #248
    if debug: #249
        print('Debug Mode') #250
    
    init() #252
    start() #253
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #255
    if open_once: #256
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #257
    else: #258
        my_camera = Camera.Camera() #259
        my_camera.camera_open()                 #260
    AGC.runActionGroup('stand') #261
    while True: #262
        ret, img = my_camera.read() #263
        if ret: #264
            frame = img.copy() #265
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #266
            Frame = run(frame)            #267
            cv2.imshow('result_image', Frame) #268
            cv2.setMouseCallback("result_image", mouse_callback)  #269
            key = cv2.waitKey(1) #270
            if key == 27: #271
                break #272
        else: #273
            time.sleep(0.01) #274
    my_camera.camera_close() #275
    cv2.destroyAllWindows() #276
