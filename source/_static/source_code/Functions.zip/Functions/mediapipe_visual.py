import cv2 #1
import math #2
import numpy as np #3
import mediapipe as mp #4
from mediapipe import solutions #5
from typing import Tuple, Union #6
from mediapipe.framework.formats import landmark_pb2 #7

MARGIN = 10  # pixels #9
ROW_SIZE = 10  # pixels #10
FONT_SIZE = 1 #11
FONT_THICKNESS = 1 #12
FACE_TEXT_COLOR = (255, 255, 0)  # yellow #13
HANDEDNESS_TEXT_COLOR = (255, 255, 0) # yellow #14

def _normalized_to_pixel_coordinates( #16
    normalized_x: float, normalized_y: float, image_width: int, #17
    image_height: int) -> Union[None, Tuple[int, int]]: #18
  """Converts normalized value pair to pixel coordinates.""" #19

  # Checks if the float value is between 0 and 1. #21
  def is_valid_normalized_value(value: float) -> bool: #22
    return (value > 0 or math.isclose(0, value)) and (value < 1 or #23
                                                      math.isclose(1, value)) #24

  if not (is_valid_normalized_value(normalized_x) and #26
          is_valid_normalized_value(normalized_y)): #27
    # TODO: Draw coordinates even if it's outside of the image bounds. #28
    return None #29
  x_px = min(math.floor(normalized_x * image_width), image_width - 1) #30
  y_px = min(math.floor(normalized_y * image_height), image_height - 1) #31
  return x_px, y_px #32


def visualize( #35
    image, #36
    detection_result #37
) -> np.ndarray: #38
  """Draws bounding boxes and keypoints on the input image and return it. #39
  Args: #40
    image: The input RGB image. #41
    detection_result: The list of all "Detection" entities to be visualize. #42
  Returns: #43
    Image with bounding boxes. #44
  """ #45
  annotated_image = image.copy() #46
  height, width, _ = image.shape #47

  for detection in detection_result.detections: #49
    # Draw bounding_box #50
    bbox = detection.bounding_box #51
    start_point = bbox.origin_x, bbox.origin_y #52
    end_point = bbox.origin_x + bbox.width, bbox.origin_y + bbox.height #53
    cv2.rectangle(annotated_image, start_point, end_point, FACE_TEXT_COLOR, 3) #54

    # Draw keypoints #56
    for keypoint in detection.keypoints: #57
      keypoint_px = _normalized_to_pixel_coordinates(keypoint.x, keypoint.y, #58
                                                     width, height) #59
      color, thickness, radius = (0, 255, 255), 2, 2 #60
      cv2.circle(annotated_image, keypoint_px, thickness, color, radius) #61

    # Draw label and score #63
    category = detection.categories[0] #64
    category_name = category.category_name #65
    category_name = '' if category_name is None else category_name #66
    probability = round(category.score, 2) #67
    result_text = category_name + ' (' + str(probability) + ')' #68
    text_location = (MARGIN + bbox.origin_x, #69
                     MARGIN + ROW_SIZE + bbox.origin_y) #70
    cv2.putText(annotated_image, result_text, text_location, cv2.FONT_HERSHEY_PLAIN, #71
                FONT_SIZE, FACE_TEXT_COLOR, FONT_THICKNESS, cv2.LINE_AA) #72

  return annotated_image #74

def draw_face_landmarks_on_image(rgb_image, detection_result): #76
  face_landmarks_list = detection_result.face_landmarks #77
  annotated_image = np.copy(rgb_image) #78

  # Loop through the detected faces to visualize. #80
  for idx in range(len(face_landmarks_list)): #81
    face_landmarks = face_landmarks_list[idx] #82

    # Draw the face landmarks. #84
    face_landmarks_proto = landmark_pb2.NormalizedLandmarkList() #85
    face_landmarks_proto.landmark.extend([ #86
      landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in face_landmarks #87
    ]) #88

    solutions.drawing_utils.draw_landmarks( #90
        image=annotated_image, #91
        landmark_list=face_landmarks_proto, #92
        connections=mp.solutions.face_mesh.FACEMESH_TESSELATION, #93
        landmark_drawing_spec=None, #94
        connection_drawing_spec=mp.solutions.drawing_styles #95
        .get_default_face_mesh_tesselation_style()) #96
    solutions.drawing_utils.draw_landmarks( #97
        image=annotated_image, #98
        landmark_list=face_landmarks_proto, #99
        connections=mp.solutions.face_mesh.FACEMESH_CONTOURS, #100
        landmark_drawing_spec=None, #101
        connection_drawing_spec=mp.solutions.drawing_styles #102
        .get_default_face_mesh_contours_style()) #103
    solutions.drawing_utils.draw_landmarks( #104
        image=annotated_image, #105
        landmark_list=face_landmarks_proto, #106
        connections=mp.solutions.face_mesh.FACEMESH_IRISES, #107
          landmark_drawing_spec=None, #108
          connection_drawing_spec=mp.solutions.drawing_styles #109
          .get_default_face_mesh_iris_connections_style()) #110

  return annotated_image #112

def draw_hand_landmarks_on_image(rgb_image, detection_result): #114
  hand_landmarks_list = detection_result.hand_landmarks #115
  handedness_list = detection_result.handedness #116
  annotated_image = np.copy(rgb_image) #117

  # Loop through the detected hands to visualize. #119
  for idx in range(len(hand_landmarks_list)): #120
    hand_landmarks = hand_landmarks_list[idx] #121
    handedness = handedness_list[idx] #122

    # Draw the hand landmarks. #124
    hand_landmarks_proto = landmark_pb2.NormalizedLandmarkList() #125
    hand_landmarks_proto.landmark.extend([ #126
      landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in hand_landmarks #127
    ]) #128
    solutions.drawing_utils.draw_landmarks( #129
      annotated_image, #130
      hand_landmarks_proto, #131
      solutions.hands.HAND_CONNECTIONS, #132
      solutions.drawing_styles.get_default_hand_landmarks_style(), #133
      solutions.drawing_styles.get_default_hand_connections_style()) #134

    # Get the top left corner of the detected hand's bounding box. #136
    height, width, _ = annotated_image.shape #137
    x_coordinates = [landmark.x for landmark in hand_landmarks] #138
    y_coordinates = [landmark.y for landmark in hand_landmarks] #139
    text_x = int(min(x_coordinates) * width) #140
    text_y = int(min(y_coordinates) * height) - MARGIN #141
    
    if handedness[0].category_name == "Left": #143
        handedness[0].category_name = 'Right' #144
    elif handedness[0].category_name == "Right": #145
        handedness[0].category_name = 'Left' #146

    # Draw handedness (left or right hand) on the image. #148
    cv2.putText(annotated_image, f"{handedness[0].category_name}", #149
                (text_x, text_y), cv2.FONT_HERSHEY_DUPLEX, #150
                FONT_SIZE, HANDEDNESS_TEXT_COLOR, FONT_THICKNESS, cv2.LINE_AA) #151

  return annotated_image #153

def draw_pose_landmarks_on_image(rgb_image, detection_result): #155
  pose_landmarks_list = detection_result.pose_landmarks #156
  annotated_image = np.copy(rgb_image) #157

  # Loop through the detected poses to visualize. #159
  for idx in range(len(pose_landmarks_list)): #160
    pose_landmarks = pose_landmarks_list[idx] #161

    # Draw the pose landmarks. #163
    pose_landmarks_proto = landmark_pb2.NormalizedLandmarkList() #164
    pose_landmarks_proto.landmark.extend([ #165
      landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in pose_landmarks #166
    ]) #167
    solutions.drawing_utils.draw_landmarks( #168
      annotated_image, #169
      pose_landmarks_proto, #170
      solutions.pose.POSE_CONNECTIONS, #171
      solutions.drawing_styles.get_default_pose_landmarks_style()) #172
  return annotated_image #173
