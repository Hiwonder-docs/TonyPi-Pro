#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9

import hiwonder.apriltag as apriltag #11
import hiwonder.Camera as Camera #12
import hiwonder.Misc as Misc #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17

''' #19
    程序功能：智能搬运(program function: intelligent transportation) #20

    运行效果：   将机器人和红绿蓝三种颜色的海绵块随机放置到地图的放置区内。启动智能搬运玩法 #22
                后，机器人将会按照距离的远近依次搬运海绵块到对应的 AprilTag 标签上，直至三 #23
                个色块搬运完成。(running effect: place the robot and the red, green, and blue sponge blocks randomly in the placement area of the map.  #24
                After starting the smart handling gameplay, the robot will sequentially transport the sponge blocks to the corresponding AprilTag labels based on distance, until all three blocks are transported) #25
                    

    对应教程文档路径：  TonyPi智能视觉人形机器人\4.拓展课程学习\1.语音交互及智能搬运课程（语音模块选配）\第4课 智能搬运(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\4.Expanded Courses\1.Voice Interaction and Intelligent Transportation(voice module optional)\Lesson4 Intelligent Transportation) #28
''' #29

if __name__ == '__main__': #31
    from CameraCalibration.CalibrationConfig import * #32
else: #33
    from Functions.CameraCalibration.CalibrationConfig import * #34

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #36
if sys.version_info.major == 2: #37
    print('Please run this program with python3!') #38
    sys.exit(0) #39

#加载参数(load parameters) #41
param_data = np.load(calibration_param_path + '.npz') #42

#获取参数(get parameters) #44
mtx = param_data['mtx_array'] #45
dist = param_data['dist_array'] #46
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #47
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #48

# 搬运用到的动作组名称(the names of action groups used for transportation) #50
go_forward = 'go_forward' #51
back = 'back_fast' #52
turn_left = 'turn_left_small_step' #53
turn_right = 'turn_right_small_step' #54
left_move = 'left_move' #55
right_move = 'right_move' #56
left_move_large = 'left_move_30' #57
right_move_large = 'right_move_30' #58

range_rgb = { #60
    'red': (0, 0, 255), #61
    'blue': (255, 0, 0), #62
    'green': (0, 255, 0), #63
    'black': (0, 0, 0), #64
    'white': (255, 255, 255), #65
} #66

# 颜色对应的tag编号(the tag numbers corresponding to colors) #68
color_tag = {'red': 1, #69
             'green': 2, #70
             'blue': 3 #71
             } #72

lab_data = None #74
servo_data = None #75
# 加载配置文件数据(load configuration file data) #76
def load_config(): #77
    global lab_data, servo_data #78
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #80
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #81

load_config() #83

board = rrc.Board() #85
ctl = Controller(board) #86

# 初始化机器人舵机初始位置(initialize the servo initialization position of robot) #88
def initMove(): #89
    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #90
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #91

# 初始化舵机移动水平方向和垂直方向的步长(initialize the step size for servo movement in the horizontal and vertical directions) #93
d_x = 15 #94
d_y = 15 #95

step = 1 #97

# 初始化开始计时的时间戳(initialize the timestamp for starting the timer) #99
time_start = 0 #100

# 设置舵机位置(set the servo position) #102
x_dis = servo_data['servo2'] #103
y_dis = servo_data['servo1'] #104

# 初始化机器人上一步的状态(initialize the previous state of the robot) #106
last_status = '' #107

# 初始化开始计时的标志量(initialize the flag variable for starting the timer) #109
start_count = True #110

# 初始化海绵块的中心坐标和对角线角度(initialize the center coordinates and diagonal angle of the sponge block) #112
object_center_x, object_center_y, object_angle = -2, -2, 0 #113

# 转向方向(turning direction) #115
turn = 'None' #116

# 画面中心x坐标(the x-coordinate of the image center) #118
CENTER_X = 350 #119

# True为搬运阶段，False为放置变量(True indicates the transportation stage, False indicates the placement stage) #121
find_box = True #122

# 执行前进动作组的次数(the number of times the forward action group is executed) #124
go_step = 3 #125

# 舵机锁，用来固定搬运时手部舵机的位置(servo lock, used to fix the position of the hand servo during transportation) #127
lock_servos = '' #128

stop_detect = False #130
object_color = 'red' #131
haved_find_tag = False #132
head_turn = 'left_right' #133
color_list = ['red', 'green', 'blue'] #134
color_center_x, color_center_y = -1, -1 #135

# 变量重置(variable reset) #137
def reset(): #138
    global color_list #139
    global time_start #140
    global d_x, d_y #141
    global last_status #142
    global start_count #143
    global step, head_turn #144
    global x_dis, y_dis #145
    global object_center_x, object_center_y, object_angle #146
    global turn #147
    global find_box #148
    global go_step #149
    global lock_servos #150
    global stop_detect #151
    global object_color #152
    global haved_find_tag #153
    global color_center_x, color_center_y #154

    d_x = 15 #156
    d_y = 15 #157
    step = 1 #158
    time_start = 0 #159
    x_dis = servo_data['servo2'] #160
    y_dis = servo_data['servo1'] #161
    last_status = '' #162
    start_count = True #163
    head_turn = 'left_right' #164
    object_center_x, object_center_y, object_angle = -2, -2, 0 #165
 
    turn = 'None' #167
    find_box = True #168
    go_step = 3 #169
    lock_servos = '' #170
    stop_detect = False #171
    object_color = 'red' #172
    haved_find_tag = False #173
    color_list = ['red', 'green', 'blue'] #174
    color_center_x, color_center_y = -1, -1 #175

# app初始化调用(app initialization calling) #177
def init(): #178
    print("Transport Init") #179
    load_config() #180
    initMove() #181

__isRunning = False #183
# app开始玩法调用(app start program calling) #184
def start(): #185
    global __isRunning #186
    reset() #187
    __isRunning = True #188
    print("Transport Start") #189

# app停止玩法调用(app stop program calling) #191
def stop(): #192
    global __isRunning #193
    __isRunning = False #194
    print("Transport Stop") #195

# app退出玩法调用(app exit program calling) #197
def exit(): #198
    global __isRunning #199
    __isRunning = False #200
    AGC.runActionGroup('stand_slow') #201
    print("Transport Exit") #202

# 找出面积最大的轮廓(find out the contour with the maximal area) #204
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #205
def getAreaMaxContour(contours): #206
    contour_area_temp = 0 #207
    contour_area_max = 0 #208
    areaMaxContour = None #209

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #211
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #212
        if contour_area_temp > contour_area_max: #213
            contour_area_max = contour_area_temp #214
            if contour_area_temp > 10:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #215
                areaMaxContour = c #216

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #218


# 红绿蓝颜色识别(red-green-blue color recognition) #221
size = (320, 240) #222
def colorDetect(img): #223
    img_h, img_w = img.shape[:2] #224
    
    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #226
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #227
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #228
    
    center_max_distance = pow(img_w/2, 2) + pow(img_h, 2) #230
    color, center_x, center_y, angle = 'None', -1, -1, 0 #231
    for i in lab_data: #232
        if i in color_list: #233
            frame_mask = cv2.inRange(frame_lab, #234
                                     (lab_data[i]['min'][0], #235
                                      lab_data[i]['min'][1], #236
                                      lab_data[i]['min'][2]), #237
                                     (lab_data[i]['max'][0], #238
                                      lab_data[i]['max'][1], #239
                                      lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #240
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #241
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #242
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contours) #243
            areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #244
            
            if area_max > 500:  # 有找到最大面积(the maximal area is found) #246
                rect = cv2.minAreaRect(areaMaxContour)#最小外接矩形(the minimum bounding rectangle) #247
                angle_ = rect[2] #248
        
                box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(four vertices of the minimum bounding rectangle) #250
                for j in range(4): #251
                    box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w)) #252
                    box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h)) #253

                cv2.drawContours(img, [box], -1, (0,255,255), 2)#画出四个点组成的矩形(draw a rectangle formed by four points) #255
            
                #获取矩形的对角点(obtain the diagonal points of a rectangle) #257
                ptime_start_x, ptime_start_y = box[0, 0], box[0, 1] #258
                pt3_x, pt3_y = box[2, 0], box[2, 1]             #259
                center_x_, center_y_ = int((ptime_start_x + pt3_x) / 2), int((ptime_start_y + pt3_y) / 2)#中心点(center point) #260
                cv2.circle(img, (center_x_, center_y_), 5, (0, 255, 255), -1)#画出中心点(draw center point) #261
                
                distance = pow(center_x_ - img_w/2, 2) + pow(center_y_ - img_h, 2) #263
                if distance < center_max_distance:  # 寻找距离最近的物体来搬运(find the nearest object to transport) #264
                    center_max_distance = distance #265
                    color = i #266
                    center_x, center_y, angle = center_x_, center_y_, angle_ #267
                    
    return color, center_x, center_y, angle #269

# 检测apriltag(detect apriltag) #271
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #272
def apriltagDetect(img):    #273
    gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY) #274
    detections = detector.detect(gray, return_image=False) #275
    tag_1 = [-1, -1, 0] #276
    tag_2 = [-1, -1, 0] #277
    tag_3 = [-1, -1, 0] #278

    if len(detections) != 0: #280
        for detection in detections:                        #281
            corners = np.rint(detection.corners)  # 获取四个角点(get four corner points) #282
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 2) #283

            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #285
            tag_id = str(detection.tag_id)  # 获取tag_id(get tag_id) #286

            object_center_x, object_center_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #288
            cv2.circle(frame, (object_center_x, object_center_y), 5, (0, 255, 255), -1) #289
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation angle) #291
            
            if tag_family == 'tag36h11': #293
                if tag_id == '1': #294
                    tag_1 = [object_center_x, object_center_y, object_angle] #295
                elif tag_id == '2': #296
                    tag_2 = [object_center_x, object_center_y, object_angle] #297
                elif tag_id == '3': #298
                    tag_3 = [object_center_x, object_center_y, object_angle] #299
        
    return tag_1, tag_2, tag_3 #301

# 通过其他apriltag判断目标apriltag位置(determine the position of the target apriltag using Other apriltags) #303
# apriltag摆放位置：红(tag36h11_1)，绿(tag36h11_2)，蓝(tag36h11_3)(apriltag placement: red(tag36h_11_1), green(tag36h11_2), blue(tag36h11_3)) #304
def getTurn(tag_id, tag_data): #305
    tag_1 = tag_data[0] #306
    tag_2 = tag_data[1] #307
    tag_3 = tag_data[2] #308

    if tag_id == 1:  # 目标apriltag为1(target apriltag is 1) #310
        if tag_2[0] == -1:  # 没有检测到apriltag 2(apriltag 2 is not detected) #311
            if tag_3[0] != -1:  # 检测到apriltag 3， 则apriltag 1在apriltag 3左边，所以左转(detected apriltag 3, therefore apriltag 1 is to the left of apriltag 3, so turn left) #312
                return 'left' #313
        else:  # 检测到apriltag 2，则则apriltag 1在apriltag 2左边，所以左转(detected apriltag 2, therefore apriltag 1 is to the left of apriltag 2, so turn left) #314
            return 'left' #315
    elif tag_id == 2: #316
        if tag_1[0] == -1: #317
            if tag_3[0] != -1: #318
                return 'left' #319
        else: #320
            return 'right' #321
    elif tag_id == 3: #322
        if tag_1[0] == -1: #323
            if tag_2[0] != -1: #324
                return 'right' #325
        else: #326
            return 'right' #327

    return 'None' #329

LOCK_SERVOS = {'6': 650, '7': 850, '8': 0, '14': 350, '15': 150, '16': 1000} #331
#执行动作组(perform action group) #332
def move():  #333
    global d_x #334
    global d_y #335
    global step #336
    global turn #337
    global x_dis #338
    global y_dis #339
    global go_step #340
    global lock_servos #341
    global start_count #342
    global find_box #343
    global head_turn #344
    global time_start #345
    global color_list #346
    global stop_detect #347
    global haved_find_tag     #348
    
    while True: #350
        if __isRunning: #351
            if object_center_x == -3:  # -3表示放置阶段，且没有找到目标apriltag，但是找到其他apriltag(-3 indicates the placement phase, and the target apriltag was not found, but other AprilTags were detected) #352
                # 根据其他arpiltag的相对位置来判断转向(determine the turning direction based on the relative positions of other apriltags) #353
                if turn == 'left': #354
                    AGC.runActionGroup(turn_left, lock_servos=lock_servos) #355
                elif turn == 'right': #356
                    AGC.runActionGroup(turn_right, lock_servos=lock_servos) #357
            elif haved_find_tag and object_center_x == -1:  # 如果转头过程找到了apriltag，且头回中时apriltag不在视野中(if an apriltag is found during the turning process, but it is not in view when the head returns to center position) #358
                # 根据头转向来判断apriltag位置(determine the position of the apriltag based on the head orientation) #359
                if x_dis > servo_data['servo2']:                     #360
                    AGC.runActionGroup(turn_left, lock_servos=lock_servos) #361
                elif x_dis < servo_data['servo2']: #362
                    AGC.runActionGroup(turn_right, lock_servos=lock_servos) #363
                else: #364
                    haved_find_tag = False #365
            elif object_center_x >= 0:  # 如果找到目标(if target is found) #366
                if not find_box:  # 如果是放置阶段(if it is placement stage) #367
                    if color_center_y > 350:  # 搬运过程中，当太靠近其他物体时，需要绕开(during the transportation process, when too close to other objects, it's necessary to navigate around them) #368
                        if (color_center_x - CENTER_X) > 80: #369
                            AGC.runActionGroup(go_forward, lock_servos=lock_servos) #370
                        elif (color_center_x > CENTER_X and object_center_x >= CENTER_X) or (color_center_x <= CENTER_X and object_center_x >= CENTER_X): #371
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #372
                            #time.sleep(0.2) #373
                        elif (color_center_x > CENTER_X and object_center_x < CENTER_X) or (color_center_x <= CENTER_X and object_center_x < CENTER_X): #374
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #375
                            #time.sleep(0.2) #376

                # 如果是转头阶段找到物体， 头回中(if an object is found during the head turning phase, return the head to the center position) #378
                if x_dis != servo_data['servo2'] and not haved_find_tag: #379
                    # 重置转头寻找的相关变量(reset the relevant variables for head scanning) #380
                    head_turn == 'left_right' #381
                    start_count = True #382
                    d_x, d_y = 15, 15 #383
                    haved_find_tag = True #384
                    
                    # 头回中(head returns to center) #386
                    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #387
                    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #388
                    time.sleep(0.6) #389
                elif step == 1:  # 左右调整，保持在正中(adjust left or right to maintain in the center) #390
                    x_dis = servo_data['servo2'] #391
                    y_dis = servo_data['servo1']                    #392
                    turn = '' #393
                    haved_find_tag = False #394
                    
                    if (object_center_x - CENTER_X) > 170 and object_center_y > 330: #396
                        AGC.runActionGroup(back, lock_servos=lock_servos)    #397
                    elif object_center_x - CENTER_X > 80:  # 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #398
                        AGC.runActionGroup(turn_right, lock_servos=lock_servos) #399
                    elif object_center_x - CENTER_X < -80: #400
                        AGC.runActionGroup(turn_left, lock_servos=lock_servos)                         #401
                    elif 0 < object_center_y <= 250: #402
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #403
                    else: #404
                        step = 2 #405
                elif step == 2:  # 接近物体(approach the object) #406
                    if 330 < object_center_y: #407
                        AGC.runActionGroup(back, lock_servos=lock_servos) #408
                    if find_box: #409
                        if object_center_x - CENTER_X > 150:   #410
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #411
                        elif object_center_x - CENTER_X < -150: #412
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos)                         #413
                        elif -10 > object_angle > -45:# 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #414
                            AGC.runActionGroup(turn_left, lock_servos=lock_servos) #415
                        elif -80 < object_angle <= -45: #416
                            AGC.runActionGroup(turn_right, lock_servos=lock_servos) #417
                        elif object_center_x - CENTER_X > 40:   #418
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #419
                        elif object_center_x - CENTER_X < -40: #420
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #421
                        else: #422
                            step = 3 #423
                    else:                         #424
                        if object_center_x - CENTER_X > 150:   #425
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #426
                        elif object_center_x - CENTER_X < -150: #427
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos)                         #428
                        elif object_angle < -5:# 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #429
                            AGC.runActionGroup(turn_left, lock_servos=lock_servos) #430
                        elif 5 < object_angle: #431
                            AGC.runActionGroup(turn_right, lock_servos=lock_servos) #432
                        elif object_center_x - CENTER_X > 40:   #433
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #434
                        elif object_center_x - CENTER_X < -40: #435
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #436
                        else: #437
                            step = 3 #438
                elif step == 3: #439
                    if 340 < object_center_y: #440
                        AGC.runActionGroup(back, lock_servos=lock_servos) #441
                    elif 0 < object_center_y <= 250: #442
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #443
                    elif object_center_x - CENTER_X >= 40:  # 不在中心，根据位置让机器人左右移动一步(not in the center, move the robot left or right one step according to the position) #444
                        AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #445
                    elif object_center_x - CENTER_X <= -40: #446
                        AGC.runActionGroup(left_move_large, lock_servos=lock_servos)  #447
                    elif 20 <= object_center_x - CENTER_X < 40:   #448
                        AGC.runActionGroup(right_move, lock_servos=lock_servos) #449
                    elif -40 < object_center_x - CENTER_X < -20:                       #450
                        AGC.runActionGroup(left_move, lock_servos=lock_servos) #451
                    else: #452
                        step = 4  #453
                elif step == 4:  #靠近物体(approach the object) #454
                    if 280 < object_center_y <= 340: #455
                        AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos) #456
                        time.sleep(0.2) #457
                    elif 0 <= object_center_y <= 280: #458
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #459
                    else: #460
                        if object_center_y >= 370: #461
                            go_step = 2 #462
                        else: #463
                            go_step = 3 #464
                        if abs(object_center_x - CENTER_X) <= 40: #465
                            stop_detect = True #466
                            step = 5 #467
                        else: #468
                            step = 3 #469
                elif step == 5:  # 拿起或者放下物体(pick up or put down the object) #470
                    if find_box: #471
                        AGC.runActionGroup('go_forward_one_step', times=2) #472
                        AGC.runActionGroup('stand', lock_servos=lock_servos) #473
                        AGC.runActionGroup('move_up') #474
                        lock_servos = LOCK_SERVOS #475
                        step = 6     #476
                    else: #477
                        AGC.runActionGroup('go_forward_one_step', times=go_step, lock_servos=lock_servos) #478
                        AGC.runActionGroup('stand', lock_servos=lock_servos) #479
                        AGC.runActionGroup('put_down') #480
                        AGC.runActionGroup(back, times=5, with_stand=True) #481
                        color_list.remove(object_color) #482
                        if color_list == []: #483
                            color_list = ['red', 'green', 'blue'] #484
                        lock_servos = '' #485
                        step = 6 #486
            elif object_center_x == -1:  # 找不到目标时，转头，转身子来寻找(when the target cannot be found, turn the head or rotate the body to search) #487
                if start_count: #488
                    start_count = False #489
                    time_start = time.time() #490
                else: #491
                    if time.time() - time_start > 0.5: #492
                        if 0 < servo_data['servo2'] - x_dis <= abs(d_x) and d_y > 0: #493
                            x_dis = servo_data['servo2'] #494
                            y_dis = servo_data['servo1'] #495
                            ctl.set_pwm_servo_pulse(1, y_dis, 20) #496
                            ctl.set_pwm_servo_pulse(2, x_dis, 20) #497
                            
                            AGC.runActionGroup(turn_right, times=3, lock_servos=lock_servos) #499
                        elif head_turn == 'left_right': #500
                            x_dis += d_x             #501
                            if x_dis > servo_data['servo2'] + 400 or x_dis < servo_data['servo2'] - 200: #502
                                if head_turn == 'left_right': #503
                                    head_turn = 'up_down' #504
                                d_x = -d_x #505
                        elif head_turn == 'up_down': #506
                            y_dis += d_y #507
                            if y_dis > servo_data['servo1'] + 300 or y_dis < servo_data['servo1']: #508
                                if head_turn == 'up_down': #509
                                    head_turn = 'left_right' #510
                                d_y = -d_y #511
                        ctl.set_pwm_servo_pulse(1, y_dis, 20) #512
                        ctl.set_pwm_servo_pulse(2, x_dis, 20) #513
                        
                        time.sleep(0.02) #515
            else: #516
                time.sleep(0.01) #517
        else: #518
            time.sleep(0.01) #519

#启动动作的线程(start the action thread) #521
th = threading.Thread(target=move) #522
th.daemon = True #523
th.start() #524

def run(img): #526
    global step  #527
    global turn #528
    global stop_detect, find_box #529
    global color, color_center_x, color_center_y, color_angle #530
    global object_color, object_center_x, object_center_y, object_angle #531

    if not __isRunning or stop_detect: #533
        if step == 5: #534
            object_center_x = 0 #535
        elif step == 6: #536
            find_box = not find_box #537
            object_center_x = -2 #538
            step = 1 #539
            stop_detect = False #540
       

        return img #543
    
    color, color_center_x, color_center_y, color_angle = colorDetect(img)  # 颜色检测，返回颜色，中心坐标，角度(color detection, return color, center coordinates, angle) #545
    
    # 如果是搬运阶段(if it is the transportation stage) #547
    if find_box: #548
        object_color, object_center_x, object_center_y, object_angle = color, color_center_x, color_center_y, color_angle #549
    else: #550
        tag_data = apriltagDetect(img) # apriltag检测(apriltag detection) #551

        if tag_data[color_tag[object_color] - 1][0] != -1:  # 如果检测到目标arpiltag(if the target apriltag is detected) #553
            object_center_x, object_center_y, object_angle = tag_data[color_tag[object_color] - 1] #554
        else:  # 如果没有检测到目标arpiltag，就通过其他arpiltag来判断相对位置(if the target AprilTag is not detected, then determine the relative position using other apriltags) #555
            turn = getTurn(color_tag[object_color], tag_data) #556
            if turn == 'None': #557
                object_center_x, object_center_y, object_angle = -1, -1, 0 #558
            else:  # 完全没有检测到apriltag(if no AprilTag is detected at all) #559
                object_center_x, object_center_y, object_angle = -3, -1, 0 #560
    
    return img #562

if __name__ == '__main__': #564
    init() #565
    start() #566
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #568
    if open_once: #569
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #570
    else: #571
        my_camera = Camera.Camera() #572
        my_camera.camera_open()          #573
    AGC.runActionGroup('stand_slow') #574
    while True: #575
        ret, img = my_camera.read() #576
        if ret: #577
            frame = img.copy() #578
            Frame = run(frame) #579
            cv2.imshow('Frame', Frame) #580
            key = cv2.waitKey(1) #581
            if key == 27: #582
                break #583
        else: #584
            time.sleep(0.01) #585
    my_camera.camera_close() #586
    cv2.destroyAllWindows() #587
