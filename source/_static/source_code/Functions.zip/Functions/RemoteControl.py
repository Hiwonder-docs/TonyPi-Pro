#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import hiwonder.ros_robot_controller_sdk as rrc #4
from hiwonder.Controller import Controller #5
import hiwonder.ActionGroupControl as AGC #6
import hiwonder.yaml_handle as yaml_handle #7
if sys.version_info.major == 2: #8
    print('Please run this program with python3!') #9
    sys.exit(0) #10

board = rrc.Board() #12
ctl = Controller(board) #13
servo_data = None #14

def load_config(): #16
    global servo_data #17
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)                                 #19
load_config() #20
# 初始位置(initial position) #21
def initMove(): #22
    ctl.set_pwm_servo_pulse(1, 1500, 500) #23
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #24
    AGC.runActionGroup('stand') #25

def reset(): #27
    return None #28

def init(): #30
    initMove() #31
    print("RemoteControl Init") #32
    return None #33

def start(): #35
    print("RemoteControl Start") #36
    return None #37

def stop(): #39
    print("RemoteControl Stop") #40
    return None #41

def exit(): #43
    print("RemoteControl Exit") #44
    return None #45

def run(img): #47
    return img #48
