#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import time #4
import threading #5

import Functions.KickBall as KickBall #7
import Functions.Transport as Transport #8
import Functions.ColorTrack as ColorTrack #9
import Functions.FaceDetect as FaceDetect #10
import Functions.lab_adjust as lab_adjust #11
import Functions.ColorDetect as ColorDetect #12
import Functions.VisualPatrol as VisualPatrol #13
import Functions.RemoteControl as RemoteControl #14
import Functions.ApriltagDetect as ApriltagDetect #15
import Functions.gesture_control as GestureControl  #16
import Extend.athletics_course.hurdles as Hurdles #17
import Extend.athletics_course.stairway as Stairway #18
import Extend.vision_grab_course.color_classify as ColorClassify #19

RunningFunc = 0 #21
LastHeartbeat = 0 #22
cam = None #23
open_once = False #24

FUNCTIONS = { #26
    1: RemoteControl, # 机体控制(remote control) #27
    2: KickBall,      # 自动踢球(auto shooting) #28
    3: GestureControl,# 颜色识别(color recognition) #29
    4: VisualPatrol,  # 智能巡线 (intelligent line follow) #30
    5: ColorTrack,    # 云台跟踪(pan-tilt tracking) #31
    6: FaceDetect,    # 人脸识别(face recognition) #32
    7: ApriltagDetect,# 标签识别(tag recognition) #33
    8: Transport,     # 智能搬运(intelligent transportation) #34
    9: lab_adjust,     # lab阈值调节(lab threshold adjustment) #35
    10: Hurdles ,     # 跨栏避障(hurdles) #36
    11: Stairway ,    # 上下台阶(go up and down stairs) #37
    12: ColorClassify # 色块分类(color block classification) #38
} #39

def doHeartbeat(tmp=()): #41
    global LastHeartbeat #42
    LastHeartbeat = time.time() + 7 #43
    return (True, ()) #44

def CurrentEXE(): #46
    global RunningFunc #47
    return FUNCTIONS[RunningFunc] #48

def loadFunc(newf): #50
    global RunningFunc #51
    new_func = newf[0] #52

    doHeartbeat() #54

    if new_func < 1 or new_func > 12: #56
        return (False,  sys._getframe().f_code.co_name + ": Invalid argument") #57
    else: #58
        try: #59
            if RunningFunc > 1: #60
                FUNCTIONS[RunningFunc].exit() #61
            RunningFunc = newf[0] #62
            if not open_once: #63
                cam.camera_close() #64
                cam.camera_open() #65
            FUNCTIONS[RunningFunc].init() #66
        except Exception as e: #67
            print(e) #68
    return (True, (RunningFunc,)) #69

def unloadFunc(tmp = ()): #71
    global RunningFunc #72
    if RunningFunc != 0: #73
        FUNCTIONS[RunningFunc].exit() #74
        RunningFunc = 0 #75
    if not open_once: #76
        cam.camera_close() #77
    return (True, (0,)) #78

def getLoadedFunc(newf): #80
    global RunningFunc #81
    return (True, (RunningFunc,)) #82

def startFunc(tmp): #84
    global RunningFunc #85
    FUNCTIONS[RunningFunc].start() #86
    return (True, (RunningFunc,)) #87

def stopFunc(tmp): #89
    global RunningFunc #90
    FUNCTIONS[RunningFunc].stop() #91
    return (True, (RunningFunc,)) #92

def heartbeatTask(): #94
    global LastHeartbeat #95
    global RunningFunc #96
    while True: #97
        try: #98
            if LastHeartbeat < time.time(): #99
                if RunningFunc != 0: #100
                    unloadFunc() #101
            time.sleep(0.1) #102
        except Exception as e: #103
            print(e) #104

        except KeyboardInterrupt: #106
            break #107

threading.Thread(target=heartbeatTask, daemon=True).start() #109
