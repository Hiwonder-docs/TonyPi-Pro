#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import time #4
import math #5
import hiwonder.ros_robot_controller_sdk as rrc #6
import hiwonder.ActionGroupControl as AGC #7



count1 = 0 #11
count2 = 0 #12

def stand_up(): #14
    global count1, count2  #15
    
    try: #17
        accel_date = board.get_imu() #18
        angle_y = int(math.degrees(math.atan2(accel_date[0], accel_date[2]))) #将获得的数据转化为角度值(convert the obtained data into angle values) #19
        
        if abs(angle_y) > 160: #y轴角度大于160，count1加1，否则清零(if the y-axis angle is greater than 160, increment count1 by 1; otherwise, reset it to zero) #21
            count1 += 1 #22
        else: #23
            count1 = 0 #24

        if abs(angle_y) < 10: #y轴角度小于10，count2加1，否则清零(if the y-axis angle is less than 10, increment count2 by 1; otherwise, reset it to zero) #26
            count2 += 1 #27
        else: #28
            count2 = 0 #29

        time.sleep(0.1) #31
        
        if count1 >= 5: #往后倒了一定时间后起来(after a certain amount of time has passed, rise up from the backward position) #33
            count1 = 0   #34
            print("stand up back！")#打印执行的动作名(print the name of performed action) #35
            AGC.runActionGroup('stand_up_back')#执行动作(execute action) #36
        
        elif count2 >= 5: #往前倒了一定时间后起来(after tilting forward for a certain amount of time, rise up) #38
            count2 = 0 #39
            print("stand up front！")#打印执行的动作名(print the name of the executed action) #40
            AGC.runActionGroup('stand_up_front')#执行动作 (execute action) #41
        
    except BaseException as e: #43
        print(e) #44

if __name__ == '__main__': #46
    # 初始化机器人底层驱动(initialize robot underlying driver) #47
    board = rrc.Board() #48
    board.enable_reception()   # 使能数据接收(enable data reception) #49
    time.sleep(1) #50

    print("Fall_and_Stand Init") #52
    print("Fall_and_Stand Start") #53

    try: #55
        while True :#循环检测机器人的状态(loop to check the status of the robot) #56
            stand_up() #57
            time.sleep(0.1) #58
    except KeyboardInterrupt:       #59
        print("接收到中断信号。退出循环。") #60
