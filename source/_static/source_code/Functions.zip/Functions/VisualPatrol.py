#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9

import hiwonder.Camera as Camera #11
import hiwonder.Misc as Misc #12
import hiwonder.ros_robot_controller_sdk as rrc #13
from hiwonder.Controller import Controller #14
import hiwonder.ActionGroupControl as AGC #15
import hiwonder.yaml_handle as yaml_handle #16
from hiwonder.common import ColorPicker #17

''' #19
    程序功能：视觉巡线(program function: vision line following) #20

    运行效果：将机器人放置在黑线上，程序启动后，机器人会沿着黑线轨迹前进(running effect: place the robot on the black line. Upon program startup, the robot will move forward along the black line track) #22

    对应教程文档路径：  TonyPi智能视觉人形机器人\3.AI视觉玩法学习\第4课 视觉巡线(corresponding tutorial file path: TonyPi Intelligent Vision Humanoid Robot\4.Expanded Courses\1.Voice Interaction and Intelligent Transportation(voice module optional)\Lesson4 Vision Line Following) #24
''' #25

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3, if not, print a prompt message and exit the program) #27
if sys.version_info.major == 2: #28
    print('Please run this program with python3!') #29
    sys.exit(0) #30

target_color = [] #32

board = rrc.Board() #34
ctl = Controller(board) #35

servo_data = None #37

# 加载配置文件数据(load configuration file data) #39
def load_config(): #40
    global servo_data #41
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #43

load_config() #45

# 初始化机器人舵机初始位置(initial servo initialization position of robot) #47
def initMove(): #48
    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #49
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #50

line_center_x = -1 #52

# 变量重置(variable reset) #54
def reset(): #55
    global line_center_x #56
    global target_color #57
    global color_picker #58
    
    line_center_x = -1 #60
    target_color = [] #61
    color_picker = None #62

# app初始化调用(app initialization calling) #64
def init(): #65
    global enter #66
    print("VisualPatrol Init") #67
    load_config() #68
    initMove() #69
    enter = True #70

enter = False #72
running = False #73
# app开始玩法调用(app start program calling) #74
def start(): #75
    global running #76
    running = True #77
    print("VisualPatrol Start") #78

# app停止玩法调用(app stop program calling) #80
def stop(): #81
    global running #82
    running = False #83
    reset() #84
    print("VisualPatrol Stop") #85

# app退出玩法调用(app exit program calling) #87
def exit(): #88
    global enter, running #89
    enter = False #90
    running = False #91
    reset() #92
    AGC.runActionGroup('stand_slow') #93
    print("VisualPatrol Exit") #94

color_picker = None #96
def set_point(point): #97
    global color_picker, target_color #98
    x, y = point #99
    target_color = [] #100
    color_picker = ColorPicker([x, y], 20) #101

def get_rgb_value(): #103
    if target_color: #104
        return target_color[1]  #105
    else: #106
        return [] #107

threshold = 0.3 #109
def set_threshold(value): #110
    global threshold #111
    threshold = value #112

# 找出面积最大的轮廓(find out the contour with the maximal area) #114
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #115
def getAreaMaxContour(contours): #116
    contour_area_temp = 0 #117
    contour_area_max = 0 #118
    area_max_contour = None #119

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #121
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #122
        if contour_area_temp > contour_area_max: #123
            contour_area_max = contour_area_temp #124
            if contour_area_temp > 5:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #125
                area_max_contour = c #126

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #128

img_centerx = 320 #130
def move(): #131
    global line_center_x #132
    
    while True: #134
        if enter: #135
            if line_center_x != -1: #136
                if abs(line_center_x - img_centerx) <= 50: #137
                    AGC.runActionGroup('go_forward') #138
                elif line_center_x - img_centerx > 50: #139
                    AGC.runActionGroup('turn_right_small_step') #140
                elif line_center_x - img_centerx < -50: #141
                    AGC.runActionGroup('turn_left_small_step') #142
            else: #143
                time.sleep(0.01) #144
        else: #145
            time.sleep(0.1) #146

# 运行子线程(run sub-thread) #148
th = threading.Thread(target=move) #149
th.daemon = True #150
th.start() #151

roi = [ # [ROI, weight] #153
        (240, 280,  0, 640, 0.1),  #154
        (340, 380,  0, 640, 0.3),  #155
        (440, 480,  0, 640, 0.6) #156
       ] #157

roi_h1 = roi[0][0] #159
roi_h2 = roi[1][0] - roi[0][0] #160
roi_h3 = roi[2][0] - roi[1][0] #161

roi_h_list = [roi_h1, roi_h2, roi_h3] #163

size = (640, 480) #165
img_w, img_h = None, None #166
def run(img): #167
    global line_center_x #168
    global target_color #169
    global img_w, img_h #170
    global color_picker #171
    
    display_image = img.copy() #173
    img_h, img_w = img.shape[:2] #174
    
    if not enter: #176
        return display_image #177
    if color_picker is not None and not target_color:   #178
        target_color, display_image = color_picker(img, display_image) #179
        if target_color: #180
            color_picker = None #181
    elif target_color:     #182
        frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #183
        frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #184
                
        centroid_x_sum = 0 #186
        weight_sum = 0 #187
        center_ = [] #188
        n = 0 #189

        #将图像分割成上中下三个部分，这样处理速度会更快，更精确(divide the image into three parts: top, middle, and bottom. This will result in faster and more accurate processing) #191
        for r in roi: #192
            roi_h = roi_h_list[n] #193
            n += 1        #194
            blobs = frame_gb[r[0]:r[1], r[2]:r[3]] #195
            frame_lab = cv2.cvtColor(blobs, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #196
            
            min_color = [int(target_color[0][0] - 50 * threshold * 2), #198
                         int(target_color[0][1] - 50 * threshold), #199
                         int(target_color[0][2] - 50 * threshold)] #200
            max_color = [int(target_color[0][0] + 50 * threshold * 2), #201
                         int(target_color[0][1] + 50 * threshold), #202
                         int(target_color[0][2] + 50 * threshold)] #203
            #对原图像和掩模进行位运算(perform bitwise operation to the original image and mask) #204
            frame_mask = cv2.inRange(frame_lab, tuple(min_color), tuple(max_color)) #205
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #206
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #207
            dilated[:, 0:160] = 0 #208
            dilated[:, 480:640] = 0         #209
            cnts = cv2.findContours(dilated , cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)[-2]#找出所有轮廓(find out all contours) #210
            cnt_large, area = getAreaMaxContour(cnts)#找到最大面积的轮廓(find out the contour with the maximal area) #211
            if cnt_large is not None:#如果轮廓不为空(if contour is not NONE) #212
                rect = cv2.minAreaRect(cnt_large)#最小外接矩形(the minimum bounding rectangle) #213
                box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #214
                for i in range(4): #215
                    box[i, 1] = box[i, 1] + (n - 1)*roi_h + roi[0][0] #216
                    box[i, 1] = int(Misc.map(box[i, 1], 0, size[1], 0, img_h)) #217
                for i in range(4):                 #218
                    box[i, 0] = int(Misc.map(box[i, 0], 0, size[0], 0, img_w)) #219
                    
                cv2.drawContours(display_image, [box], -1, (0,0,255,255), 2)#画出四个点组成的矩形(draw the rectangle formed by four points) #221
                
                #获取矩形的对角点(get the diagonal points of the rectangle) #223
                pt1_x, pt1_y = box[0, 0], box[0, 1] #224
                pt3_x, pt3_y = box[2, 0], box[2, 1]             #225
                center_x, center_y = (pt1_x + pt3_x) / 2, (pt1_y + pt3_y) / 2#中心点(center point) #226
                cv2.circle(display_image, (int(center_x), int(center_y)), 5, (0,0,255), -1)#画出中心点(draw center point) #227
                
                center_.append([center_x, center_y])                         #229
                #按权重不同对上中下三个中心点进行求和(sum the three central points of the top, middle, and bottom sections according to different weights) #230
                centroid_x_sum += center_x * r[4] #231
                weight_sum += r[4] #232

        if weight_sum != 0: #234
            #求最终得到的中心点(seeking the final obtained center point) #235
            cv2.circle(display_image, (line_center_x, int(center_y)), 10, (0,255,255), -1)#画出中心点(draw center point) #236
            if running: #237
                line_center_x = int(centroid_x_sum / weight_sum)   #238
        else: #239
            line_center_x = -1 #240

    return display_image #242

if __name__ == '__main__': #244
    from CameraCalibration.CalibrationConfig import * #245
    def mouse_callback(event, x, y, flags, param): #246
        global color_picker #247
        if event == cv2.EVENT_LBUTTONDOWN: #248
            color_picker = ColorPicker([x/img_w, y/img_h], 20) #249
            # print(x, y) #250
        elif event == cv2.EVENT_RBUTTONDOWN: #251
            color_picker = None #252
            init() #253
            reset()      #254
    #加载参数(load parameters) #255
    param_data = np.load(calibration_param_path + '.npz') #256

    #获取参数(get parameters) #258
    mtx = param_data['mtx_array'] #259
    dist = param_data['dist_array'] #260
    newcameramtx, _ = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #261
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #262
    
    init() #264
    start() #265
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #267
    if open_once: #268
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #269
    else: #270
        my_camera = Camera.Camera() #271
        my_camera.camera_open()               #272
    AGC.runActionGroup('stand') #273

    while True: #275
        ret, img = my_camera.read() #276
        if ret: #277
            frame = img.copy() #278
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #279
            Frame = run(frame)            #280
            cv2.imshow('result_image', Frame) #281
            cv2.setMouseCallback("result_image", mouse_callback) #282
            key = cv2.waitKey(1) #283
            if key == 27: #284
                break #285
        else: #286
            time.sleep(0.01) #287
    my_camera.camera_close() #288
    cv2.destroyAllWindows() #289
