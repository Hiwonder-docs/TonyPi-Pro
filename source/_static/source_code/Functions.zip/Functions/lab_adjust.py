#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import numpy as np #8

import hiwonder.Camera as Camera #10
import hiwonder.yaml_handle as yaml_handle #11

# 颜色跟踪(color tracking) #13
if sys.version_info.major == 2: #14
    print('Please run this program with python3!') #15
    sys.exit(0) #16


__target_color = ('red') #19

def setLABValue(lab_value): #21
    global lab_data #22
    global __target_color #23
    
    __target_color = (lab_value[0]['color'], ) #25
    lab_data[__target_color[0]]['min'][0] = lab_value[0]['min'][0] #26
    lab_data[__target_color[0]]['min'][1] = lab_value[0]['min'][1] #27
    lab_data[__target_color[0]]['min'][2] = lab_value[0]['min'][2] #28
    lab_data[__target_color[0]]['max'][0] = lab_value[0]['max'][0] #29
    lab_data[__target_color[0]]['max'][1] = lab_value[0]['max'][1] #30
    lab_data[__target_color[0]]['max'][2] = lab_value[0]['max'][2] #31
    
    return (True, (), 'SetLABValue') #33

def getLABValue(): #35
    _lab_value = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #36
    return (True, (_lab_value, )) #37

def saveLABValue(color): #39
    yaml_handle.save_yaml_data(lab_data, yaml_handle.lab_file_path) #40
    
    return (True, (), 'SaveLABValue') #42



lab_data = None #46
servo_data = None #47
def load_config(): #48
    global lab_data, servo_data #49
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #51
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #52


# 变量重置(variable reset) #55
def reset(): #56
    global __target_color #57
       
    __target_color = () #59

# app初始化调用(app initialization calling) #61
def init(): #62
    print("lab_adjust Init") #63
    load_config() #64
    reset() #65

__isRunning = False #67
# app开始玩法调用(app start program calling) #68
def start(): #69
    global __isRunning #70
    __isRunning = True #71
    print("lab_adjust Start") #72

# app停止玩法调用(app stop program calling) #74
def stop(): #75
    global __isRunning #76
    __isRunning = False #77
    reset() #78
    print("lab_adjust Stop") #79

# app退出玩法调用(app exit program calling) #81
def exit(): #82
    global __isRunning #83
    __isRunning = False #84
    print("lab_adjust Exit") #85

def run(img):   #87
    img_copy = img.copy() #88
    
    if not __isRunning or __target_color == (): #90
        return img #91
    
    frame_gb = cv2.GaussianBlur(img_copy, (3, 3), 3)    #93
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #94
    
    for i in lab_data: #96
        if i in __target_color: #97
            frame_mask = cv2.inRange(frame_lab, #98
                                         (lab_data[i]['min'][0], #99
                                          lab_data[i]['min'][1], #100
                                          lab_data[i]['min'][2]), #101
                                         (lab_data[i]['max'][0], #102
                                          lab_data[i]['max'][1], #103
                                          lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #104
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #105
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #106
            frame_bgr = cv2.cvtColor(dilated, cv2.COLOR_GRAY2BGR) #107
            img = frame_bgr #108
            
    return img #110

if __name__ == '__main__':  #112

    init() #114
    start() #115
   
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #117
    if open_once: #118
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #119
    else: #120
        my_camera = Camera.Camera() #121
        my_camera.camera_open()         #122
    while True: #123
        ret, img = my_camera.read() #124
        if ret: #125
            frame = img.copy() #126
            Frame = run(frame)            #127
            cv2.imshow('Frame', Frame) #128
            key = cv2.waitKey(1) #129
            if key == 27: #130
                break #131
        else: #132
            time.sleep(0.01) #133
    my_camera.camera_close() #134
    cv2.destroyAllWindows() #135
