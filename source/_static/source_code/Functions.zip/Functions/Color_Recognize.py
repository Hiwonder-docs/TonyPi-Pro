import sys #1
import os #2
import cv2 #3
import math #4
import time #5
import numpy as np #6

import hiwonder.Camera as Camera #8
import hiwonder.Misc as Misc #9
import hiwonder.yaml_handle as yaml_handle #10

range_rgb = { #12
    'red': (0, 0, 255), #13
    'green': (0, 255, 0), #14
    'blue': (255, 0, 0),   # 注意：OpenCV中BGR，蓝色通道在开头 #15
} #16

def getAreaMaxContour(contours): #18
    contour_area_temp = 0 #19
    contour_area_max = 0 #20
    areaMaxContour = None #21
    for c in contours: #22
        contour_area_temp = math.fabs(cv2.contourArea(c)) #23
        if contour_area_temp > contour_area_max: #24
            contour_area_max = contour_area_temp #25
            if contour_area_temp > 50: #26
                areaMaxContour = c #27
    return areaMaxContour, contour_area_max #28

lab_data = None #30
def load_config(): #31
    global lab_data #32
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #33
load_config() #34

size = (320, 240) #36
def run(img): #37
    img_copy = img.copy() #38
    img_h, img_w = img.shape[:2] #39
    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #40
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3) #41
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB) #42

    detected_colors = [] #44

    # 循环处理三种颜色 #46
    for color in ['red', 'green', 'blue']: #47
        if color not in lab_data: #48
            continue   # YAML中没有该颜色阈值就跳过 #49

        # 获取该颜色的LAB阈值 #51
        min_lab = tuple(lab_data[color]['min']) #52
        max_lab = tuple(lab_data[color]['max']) #53

        frame_mask = cv2.inRange(frame_lab, min_lab, max_lab) #55
        eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #56
        dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #57
        contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2] #58

        areaMaxContour, area_max = getAreaMaxContour(contours) #60
        if areaMaxContour is not None and area_max > 200: #61
            ((centerX, centerY), radius) = cv2.minEnclosingCircle(areaMaxContour) #62
            centerX = int(Misc.map(centerX, 0, size[0], 0, img_w)) #63
            centerY = int(Misc.map(centerY, 0, size[1], 0, img_h)) #64
            radius = int(Misc.map(radius, 0, size[0], 0, img_w)) #65
            draw_color = range_rgb[color] #66

            if radius > 1: #68
                cv2.circle(img, (centerX, centerY), radius, draw_color, 2) #69
                cv2.putText(img, "Color: " + color, (centerX - 30, centerY - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, draw_color, 2) #70
                cv2.putText(img, f"Pos:({centerX},{centerY})", (centerX - 30, centerY + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, draw_color, 2) #71

    # 标记所有发现的颜色 #73
    if detected_colors: #74
        cv2.putText(img, "Detected: " + ', '.join(detected_colors), (10, img.shape[0] - 10),  #75
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2) #76
    return img #77

if __name__ == '__main__': #79
    from CameraCalibration.CalibrationConfig import * #80

    param_data = np.load(calibration_param_path + '.npz') #82
    mtx = param_data['mtx_array'] #83
    dist = param_data['dist_array'] #84
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #85
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #86

    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #88
    if open_once: #89
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #90
    else: #91
        my_camera = Camera.Camera() #92
        my_camera.camera_open() #93
        
    print("Color_Recognize Init") #95
    print("Color_Recognize Start") #96
    while True: #97
        ret, img = my_camera.read() #98
        if img is not None: #99
            frame = img.copy() #100
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR) #101
            Frame = run(frame) #102
            cv2.imshow('Frame', Frame) #103
            key = cv2.waitKey(1) #104
            if key == 27: #105
                break #106
        else: #107
            time.sleep(0.01) #108
    my_camera.camera_close() #109
    cv2.destroyAllWindows() #110
