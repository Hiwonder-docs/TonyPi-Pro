#!/usr/bin/python3 #1
# coding=utf8 #2
import serial, os, sys #3
from speech import speech #4
from hiwonder.Controller import Controller #5
import hiwonder.ActionGroupControl as AGC #6
import hiwonder.yaml_handle as yaml_handle #7
import hiwonder.ros_robot_controller_sdk as rrc #8

''' #10
	程序功能：语音控制TonyPi(program function: voice control TonyPi) #11

    运行效果：说唤醒词“小幻小幻”。听到回答“我在”之后，说出以下指令之一，机器人会执行相应动作, #13
              唤醒15秒之内不用再次唤醒，15秒之后会dong的表示进入休眠状态，此时需要再次唤醒，如果15秒内 #14
              有持续的指令控制，会刷新15秒间隔 #15
              指令：前进/后退/左转/右转 #16

    对应教程文档路径：1 教程资料\10.语音交互课程\11.2 语音控制TonyPi #18
''' #19

# 添加当前脚本所在目录的上一级目录的绝对路径(add the absolute path of the parent directory of the directory where the current script is located) #21
last_dir_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) #22
sys.path.append(last_dir_path) #23
from ActionGroupDict import action_group_dict #24

# 初始化机器人底层驱动(initialize the robot's low-level drivers) #26
board = rrc.Board() #27
ctl = Controller(board) #28

#获取舵机配置数据(get servo configuration data) #30
servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #31

ctl.set_pwm_servo_pulse(1, 1500, 500) #33
ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #34
AGC.runActionGroup('stand') #35
speech.set_volume(60) #36
cmd_dict = {b"\xaa\x55\x03\x00\xfb": 'wakeup', #37
            b"\xaa\x55\x02\x00\xfb": 'sleep', #38
            b"\xaa\x55\x00\x01\xfb": 'forward', #39
            b"\xaa\x55\x00\x02\xfb": 'back', #40
            b"\xaa\x55\x00\x03\xfb": 'turn_left', #41
            b"\xaa\x55\x00\x04\xfb": 'turn_right'} #42

audio_path = os.path.join(os.path.abspath(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'audio')))  #44

class WonderEcho: #46
    def __init__(self, port): #47
        self.serialHandle = serial.Serial(None, 115200, serial.EIGHTBITS, serial.PARITY_NONE, serial.STOPBITS_ONE, timeout=0.02) #48
        self.serialHandle.rts = False #49
        self.serialHandle.dtr = False #50
        self.serialHandle.setPort(port) #51
        self.serialHandle.open() #52
        self.serialHandle.reset_input_buffer() #53

    def detect(self): #55
        return self.serialHandle.read(5) #56

    def exit(self): #58
        self.serialHandle.close() #59

if __name__ == '__main__': #61
    wonderecho = WonderEcho('/dev/ttyUSB0') #62
    speech.play_audio(os.path.join(audio_path, 'ready.wav')) #63
    while True: #64
        try: #65
            res = wonderecho.detect() #66
            if res != b'': #67
                if res in cmd_dict: #68
                    if cmd_dict[res] == 'wakeup': #69
                        speech.play_audio(os.path.join(audio_path, 'wakeup.wav')) #70
                        print('wakeup') #71
                    elif cmd_dict[res] == 'sleep': #72
                        speech.play_audio(os.path.join(audio_path, 'dong.wav'))  #73
                        print('sleep') #74
                    elif cmd_dict[res] == 'forward': #75
                        speech.play_audio(os.path.join(audio_path, 'ok.wav')) #76
                        AGC.runActionGroup('go_forward', 2 , True) #77
                        print('forward') #78
                    elif cmd_dict[res] == 'back': #79
                        speech.play_audio(os.path.join(audio_path, 'ok.wav')) #80
                        AGC.runActionGroup('back', 2 , True) #81
                        print('back') #82
                    elif cmd_dict[res] == 'turn_left': #83
                        speech.play_audio(os.path.join(audio_path, 'ok.wav')) #84
                        AGC.runActionGroup('turn_left', 2 , True) #85
                        print('turn_left') #86
                    elif cmd_dict[res] == 'turn_right': #87
                        speech.play_audio(os.path.join(audio_path, 'ok.wav')) #88
                        AGC.runActionGroup('turn_right', 2 , True) #89
                        print('turn_right') #90
        except KeyboardInterrupt: #91
            wonderecho.exit() #92
            break #93
