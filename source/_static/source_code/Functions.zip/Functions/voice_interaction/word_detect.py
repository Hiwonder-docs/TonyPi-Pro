#!/usr/bin/python3 #1
# coding=utf8 #2
import serial, os, sys #3
from speech import speech #4

cmd_dict = {b"\xaa\x55\x03\x00\xfb": 'wakeup', #6
            b"\xaa\x55\x02\x00\xfb": 'sleep', #7
            b"\xaa\x55\x00\x01\xfb": 'forward', #8
            b"\xaa\x55\x00\x02\xfb": 'back', #9
            b"\xaa\x55\x00\x03\xfb": 'turn_left', #10
            b"\xaa\x55\x00\x04\xfb": 'turn_right'} #11

class WonderEcho: #13
    def __init__(self, port): #14
        self.serialHandle = serial.Serial(None, 115200, serial.EIGHTBITS, serial.PARITY_NONE, serial.STOPBITS_ONE, timeout=0.02) #15
        self.serialHandle.rts = False #16
        self.serialHandle.dtr = False #17
        self.serialHandle.setPort(port) #18
        self.serialHandle.open() #19
        self.serialHandle.reset_input_buffer() #20

    def detect(self): #22
        return self.serialHandle.read(5) #23

    def exit(self): #25
        self.serialHandle.close() #26

if __name__ == '__main__': #28
    wonderecho = WonderEcho('/dev/ttyUSB0') #29
    while True: #30
        try: #31
            res = wonderecho.detect() #32
            if res != b'': #33
                if res in cmd_dict: #34
                    print(cmd_dict[res]) #35
        except KeyboardInterrupt: #36
            wonderecho.exit() #37
            break #38
