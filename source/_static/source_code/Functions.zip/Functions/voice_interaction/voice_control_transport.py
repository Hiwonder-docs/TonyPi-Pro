#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import time #6
import math #7
import threading #8
import numpy as np #9
import serial #10
from speech import speech #11
import hiwonder.apriltag as apriltag #12
import hiwonder.Camera as Camera #13
import hiwonder.Misc as Misc #14
import hiwonder.ros_robot_controller_sdk as rrc #15
from hiwonder.Controller import Controller #16
import hiwonder.ActionGroupControl as AGC #17
import hiwonder.yaml_handle as yaml_handle #18

''' #20
    程序功能：语音控制搬运(program function: voice control transportation) #21

    运行效果：  程序启动之后，TonyPi 机器人的头部会朝下，并反馈“我准备好了”的语音信息。此时， #23
                对 TonyPi 进行唤醒（说出唤醒词“小幻小幻”）。等播报“我在”后，可以向机器人下达搬运指令。 #24
                例如，我们说“搬运红色”，机器人接收后会反馈“收到，开始找红色”的语音信息，然后开始寻找并搬运红色物品， #25
                并放置到对应的 AprilTag 区域 #26

    对应教程文档路径：  1 教程资料\9.AI视觉项目课程 #28
''' #29


if __name__ == '__main__': #32
    sys.path.append("/home/pi/TonyPi/Functions") #33
    from CameraCalibration.CalibrationConfig import * #34
else: #35
    from Functions.CameraCalibration.CalibrationConfig import * #36

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3, if not, print a prompt message and exit the program) #38
if sys.version_info.major == 2: #39
    print('Please run this program with python3!') #40
    sys.exit(0) #41
audio_path = os.path.join(os.path.abspath(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'audio')))  #42
#加载参数(load parameters) #43
param_data = np.load(calibration_param_path + '.npz') #44
# speech.set_volume(70) #设置音量 #45
#获取参数(get parameters) #46
mtx = param_data['mtx_array'] #47
dist = param_data['dist_array'] #48
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #49
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #50

# 搬运用到的动作组名称(the name of the action group used for transportation) #52
go_forward = 'go_forward' #53
back = 'back_fast' #54
turn_left = 'turn_left_small_step' #55
turn_right = 'turn_right_small_step' #56
left_move = 'left_move' #57
right_move = 'right_move' #58
left_move_large = 'left_move_30' #59
right_move_large = 'right_move_30' #60

range_rgb = { #62
    'red': (0, 0, 255), #63
    'blue': (255, 0, 0), #64
    'green': (0, 255, 0), #65
    'black': (0, 0, 0), #66
    'white': (255, 255, 255), #67
} #68

# 颜色对应的tag编号(color corresponds to the tag number) #70
color_tag = {'red': 1, #71
             'green': 2, #72
             'blue': 3 #73
             } #74

lab_data = None #76
servo_data = None #77
# 加载配置文件数据(load configuration file data) #78
def load_config(): #79
    global lab_data, servo_data #80
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #82
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #83

load_config() #85

# 初始化机器人底层驱动(initialize robot underlying driver) #87
board = rrc.Board() #88
ctl = Controller(board) #89

# 初始位置(initial position) #91
def initMove(): #92
    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #93
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #94


# 初始化舵机移动水平方向和垂直方向的步长(initialize the step size for moving the servo motor in the horizontal and vertical directions) #97
d_x = 15 #98
d_y = 15 #99

step = 1 #101

# 初始化开始计时的时间戳(initialize the timestamp for starting the timer) #103
time_start = 0 #104

# 设置舵机位置(set servo position) #106
x_dis = servo_data['servo2'] #107
y_dis = servo_data['servo1'] #108

# 初始化机器人上一步的状态(initialize the previous state of the robot) #110
last_status = '' #111

# 初始化开始计时的标志量(initialize the flag variable for starting the timer) #113
start_count = True #114

head_turn = 'left_right' #116
object_center_x, object_center_y, object_angle = -2, -2, 0 #117
# 变量重置(variable reset) #118
def reset(): #119
    global time_start #120
    global d_x, d_y #121
    global last_status #122
    global start_count #123
    global step, head_turn #124
    global x_dis, y_dis #125
    global object_center_x, object_center_y, object_angle #126

    d_x = 15 #128
    d_y = 15 #129
    step = 1 #130
    time_start = 0 #131
    x_dis = servo_data['servo2'] #132
    y_dis = servo_data['servo1'] #133
    last_status = '' #134
    start_count = True #135
    head_turn = 'left_right' #136
    object_center_x, object_center_y, object_angle = -2, -2, 0 #137
    
# app初始化调用(app initialization calling) #139
def init(): #140
    print("Transport Init") #141
    load_config() #142
    initMove() #143

__isRunning = False #145
# app开始玩法调用(app start program calling) #146
def start(): #147
    global __isRunning #148
    reset() #149
    __isRunning = True #150
    print("Transport Start") #151

# app停止玩法调用(app stop program calling) #153
def stop(): #154
    global __isRunning #155
    __isRunning = False #156
    print("Transport Stop") #157

# app退出玩法调用(app exit program calling) #159
def exit(): #160
    global __isRunning #161
    __isRunning = False #162
    AGC.runActionGroup('stand_slow') #163
    print("Transport Exit") #164

# 找出面积最大的轮廓(find out the contour with the maximal area) #166
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #167
def getAreaMaxContour(contours): #168
    contour_area_temp = 0 #169
    contour_area_max = 0 #170
    area_max_contour = None #171

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #173
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate the contour area) #174
        if contour_area_temp > contour_area_max: #175
            contour_area_max = contour_area_temp #176
            if contour_area_temp > 300:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid, where the largest contour within this threshold is selected to filter out noise) #177
                area_max_contour = c #178

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #180

# 红绿蓝颜色识别(red-green-blur color recognition) #182
size = (320, 240) #183
def colorDetect(img, _color_): #184
    img_h, img_w = img.shape[:2] #185
    
    frame_resize = cv2.resize(img, size, interpolation=cv2.INTER_NEAREST) #187
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)    #188
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #189
    
    center_max_distance = pow(img_w/2, 2) + pow(img_h, 2) #191
    color, center_x, center_y, angle = 'None', -1, -1, 0 #192
    for i in lab_data: #193
        if i == _color_: #194
            frame_mask = cv2.inRange(frame_lab, #195
                                     (lab_data[i]['min'][0], #196
                                      lab_data[i]['min'][1], #197
                                      lab_data[i]['min'][2]), #198
                                     (lab_data[i]['max'][0], #199
                                      lab_data[i]['max'][1], #200
                                      lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #201
            eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #202
            dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #203
            contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  # 找出轮廓(find out contours) #204
            areaMaxContour, area_max = getAreaMaxContour(contours)  # 找出最大轮廓(find out the contour with the maximal area) #205
            
            if area_max > 500:  # 有找到最大面积(the maximal area is found) #207
                rect = cv2.minAreaRect(areaMaxContour)#最小外接矩形(the minimal bounding rectangle) #208
                angle_ = rect[2] #209
        
                box = np.int0(cv2.boxPoints(rect))#最小外接矩形的四个顶点(the four vertices of the minimum bounding rectangle) #211
                for j in range(4): #212
                    box[j, 0] = int(Misc.map(box[j, 0], 0, size[0], 0, img_w)) #213
                    box[j, 1] = int(Misc.map(box[j, 1], 0, size[1], 0, img_h)) #214

                cv2.drawContours(img, [box], -1, (0,255,255), 2)#画出四个点组成的矩形(draw a rectangle formed by four points) #216
            
                #获取矩形的对角点(get the diagonal points of the rectangle) #218
                ptime_start_x, ptime_start_y = box[0, 0], box[0, 1] #219
                pt3_x, pt3_y = box[2, 0], box[2, 1]             #220
                center_x_, center_y_ = int((ptime_start_x + pt3_x) / 2), int((ptime_start_y + pt3_y) / 2)#中心点(center point) #221
                cv2.circle(img, (center_x_, center_y_), 5, (0, 255, 255), -1)#画出中心点(draw center point) #222
                
                distance = pow(center_x_ - img_w/2, 2) + pow(center_y_ - img_h, 2) #224
                if distance < center_max_distance:  # 寻找距离最近的物体来搬运(find the nearest object to transport) #225
                    center_max_distance = distance #226
                    color = i #227
                    center_x, center_y, angle = center_x_, center_y_, angle_ #228
                    
    return color, center_x, center_y, angle #230

# 检测apriltag(detect pariltag) #232
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #233
def apriltagDetect(img):    #234
    gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY) #235
    detections = detector.detect(gray, return_image=False) #236
    tag_1 = [-1, -1, 0] #237
    tag_2 = [-1, -1, 0] #238
    tag_3 = [-1, -1, 0] #239

    if len(detections) != 0: #241
        for detection in detections:                        #242
            corners = np.rint(detection.corners)  # 获取四个角点(get four corner points) #243
            cv2.drawContours(img, [np.array(corners, np.int)], -1, (0, 255, 255), 2) #244

            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #246
            tag_id = str(detection.tag_id)  # 获取tag_id(get tag_id) #247

            object_center_x, object_center_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #249
            cv2.circle(frame, (object_center_x, object_center_y), 5, (0, 255, 255), -1) #250
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation point) #252
            
            if tag_family == 'tag36h11': #254
                if tag_id == '1': #255
                    tag_1 = [object_center_x, object_center_y, object_angle] #256
                elif tag_id == '2': #257
                    tag_2 = [object_center_x, object_center_y, object_angle] #258
                elif tag_id == '3': #259
                    tag_3 = [object_center_x, object_center_y, object_angle] #260
        
    return tag_1, tag_2, tag_3 #262

# 通过其他apriltag判断目标apriltag位置(determine the position of the target apriltag using other apriltags) #264
# apriltag摆放位置：红(tag36h11_1)，绿(tag36h11_2)，蓝(tag36h11_3)(apriltag placement: red(tag36h11_1), green(tag36h11_2), blue(tag36h11_3)) #265
def getTurn(tag_id, tag_data): #266
    tag_1 = tag_data[0] #267
    tag_2 = tag_data[1] #268
    tag_3 = tag_data[2] #269

    if tag_id == 1:  # 目标apriltag为1(target apriltag is 1) #271
        if tag_2[0] == -1:  # 没有检测到apriltag 2(apriltag 2 is not detected) #272
            if tag_3[0] != -1:  # 检测到apriltag 3， 则apriltag 1在apriltag 3左边，所以左转(apriltag 3 is not detected, then apriltag 1 is to the left of apriltag 3, so turn left) #273
                return 'left' #274
        else:  # 检测到apriltag 2，则则apriltag 1在apriltag 2左边，所以左转(apriltag 2 is  detected, then apriltag 1 is to the left of apriltag 2, so turn left) #275
            return 'left' #276
    elif tag_id == 2: #277
        if tag_1[0] == -1: #278
            if tag_3[0] != -1: #279
                return 'left' #280
        else: #281
            return 'right' #282
    elif tag_id == 3: #283
        if tag_1[0] == -1: #284
            if tag_2[0] != -1: #285
                return 'right' #286
        else: #287
            return 'right' #288

    return 'None' #290


# 转向方向(turning direction) #293
turn = 'None' #294

# 画面中心x坐标(the x-coordinate of the center of the screen) #296
CENTER_X = 350 #297

# True为搬运阶段，False为放置变量(True is the transportation state, False is the placement variable) #299
find_box = True #300

# 执行前进动作组的次数(the number of times the forward action group is executed) #302
go_step = 3 #303

# 舵机锁，用来固定搬运时手部舵机的位置(servo lock, used to fix the position of the hand servo during transportation) #305
lock_servos = '' #306

stop_detect = False #308
object_color = None #309
haved_find_tag = False #310
head_turn = 'left_right' #311
color_list = ['red', 'green', 'blue'] #312
color_center_x, color_center_y = -1, -1 #313
LOCK_SERVOS = {'6': 650, '7': 850, '8': 0, '14': 350, '15': 150, '16': 1000} #314

#执行动作组(execute action group) #316
def move():  #317
    global d_x #318
    global d_y #319
    global step #320
    global turn #321
    global x_dis #322
    global y_dis #323
    global go_step #324
    global lock_servos #325
    global start_count #326
    global find_box #327
    global head_turn #328
    global time_start #329
    global color_list #330
    global stop_detect #331
    global haved_find_tag     #332
    global object_color #333

    while True: #335
        if __isRunning: #336
            if object_center_x == -3:  # -3表示放置阶段，且没有找到目标apriltag，但是找到其他apriltag(-3 indicates the placement phase, and the target AprilTag was not found, but other AprilTags were detected) #337
                # 根据其他arpiltag的相对位置来判断转向(determine the turning direction based on the relative positions of other apriltags) #338
                if turn == 'left': #339
                    AGC.runActionGroup(turn_left, lock_servos=lock_servos) #340
                elif turn == 'right': #341
                    AGC.runActionGroup(turn_right, lock_servos=lock_servos) #342
            elif haved_find_tag and object_center_x == -1:  # 如果转头过程找到了apriltag，且头回中时apriltag不在视野中(if an AprilTag is found during the turning process, but it is not in view when the head returns to center position) #343
                # 根据头转向来判断apriltag位置(determine the position of the AprilTag based on the head orientation) #344
                if x_dis > servo_data['servo2']:                     #345
                    AGC.runActionGroup(turn_left, lock_servos=lock_servos) #346
                elif x_dis < servo_data['servo2']: #347
                    AGC.runActionGroup(turn_right, lock_servos=lock_servos) #348
                else: #349
                    haved_find_tag = False #350
            elif object_center_x >= 0:  # 如果找到目标(if the target is found) #351
                if not find_box:  # 如果是放置阶段(if it isi the placement stage) #352
                    if color_center_y > 350:  # 搬运过程中，当太靠近其他物体时，需要绕开(when too close to other objects during the transportation process, it is necessary to navigate around them) #353
                        if (color_center_x - CENTER_X) > 80: #354
                            AGC.runActionGroup(go_forward, lock_servos=lock_servos) #355
                        elif (color_center_x > CENTER_X and object_center_x >= CENTER_X) or (color_center_x <= CENTER_X and object_center_x >= CENTER_X): #356
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #357
                            #time.sleep(0.2) #358
                        elif (color_center_x > CENTER_X and object_center_x < CENTER_X) or (color_center_x <= CENTER_X and object_center_x < CENTER_X): #359
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #360
                            #time.sleep(0.2) #361

                # 如果是转头阶段找到物体， 头回中(if an object is found during the head turning phase, return the head to the center position) #363
                if x_dis != servo_data['servo2'] and not haved_find_tag: #364
                    # 重置转头寻找的相关变量(reset the relevant variables for head scanning) #365
                    head_turn == 'left_right' #366
                    start_count = True #367
                    d_x, d_y = 15, 15 #368
                    haved_find_tag = True #369
                    
                    # 头回中(the head returns to the center) #371
                    ctl.set_pwm_servo_pulse(1, servo_data['servo1'], 500) #372
                    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #373
                    time.sleep(0.6) #374
                elif step == 1:  # 左右调整，保持在正中(adjust left or right to maintain in the center) #375
                    x_dis = servo_data['servo2'] #376
                    y_dis = servo_data['servo1']                    #377
                    turn = '' #378
                    haved_find_tag = False #379
                    
                    if (object_center_x - CENTER_X) > 170 and object_center_y > 330: #381
                        AGC.runActionGroup(back, lock_servos=lock_servos)    #382
                    elif object_center_x - CENTER_X > 80:  # 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #383
                        AGC.runActionGroup(turn_right, lock_servos=lock_servos) #384
                    elif object_center_x - CENTER_X < -80: #385
                        AGC.runActionGroup(turn_left, lock_servos=lock_servos)                         #386
                    elif 0 < object_center_y <= 250: #387
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #388
                    else: #389
                        step = 2 #390
                elif step == 2:  # 接近物体(approach the object) #391
                    if 330 < object_center_y: #392
                        AGC.runActionGroup(back, lock_servos=lock_servos) #393
                    if find_box: #394
                        if object_center_x - CENTER_X > 150:   #395
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #396
                        elif object_center_x - CENTER_X < -150: #397
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos)                         #398
                        elif -10 > object_angle > -45:# 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #399
                            AGC.runActionGroup(turn_left, lock_servos=lock_servos) #400
                        elif -80 < object_angle <= -45: #401
                            AGC.runActionGroup(turn_right, lock_servos=lock_servos) #402
                        elif object_center_x - CENTER_X > 40:  # 不在中心，根据位置让机器人移动一步(not in the center, turn the robot one step according to the position) #403
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #404
                        elif object_center_x - CENTER_X < -40: #405
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #406
                        else: #407
                            step = 3 #408
                    else:                         #409
                        if object_center_x - CENTER_X > 150:  # 不在中心，根据位置让机器人移动一步(not in the center, turn the robot one step according to the position) #410
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #411
                        elif object_center_x - CENTER_X < -150: #412
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos)                         #413
                        elif object_angle < -5:# 不在中心，根据方向让机器人转向一步(not in the center, turn the robot one step according to the direction) #414
                            AGC.runActionGroup(turn_left, lock_servos=lock_servos) #415
                        elif 5 < object_angle: #416
                            AGC.runActionGroup(turn_right, lock_servos=lock_servos) #417
                        elif object_center_x - CENTER_X > 40:   #418
                            AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #419
                        elif object_center_x - CENTER_X < -40: #420
                            AGC.runActionGroup(left_move_large, lock_servos=lock_servos) #421
                        else: #422
                            step = 3 #423
                elif step == 3: #424
                    if 340 < object_center_y: #425
                        AGC.runActionGroup(back, lock_servos=lock_servos) #426
                    elif 0 < object_center_y <= 250: #427
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #428
                    elif object_center_x - CENTER_X >= 40:  # 不在中心，根据位置让机器人移动一步(not in the center, turn the robot one step according to the position) #429
                        AGC.runActionGroup(right_move_large, lock_servos=lock_servos) #430
                    elif object_center_x - CENTER_X <= -40: #431
                        AGC.runActionGroup(left_move_large, lock_servos=lock_servos)  #432
                    elif 20 <= object_center_x - CENTER_X < 40:  # 不在中心，根据位置让机器人移动一步(not in the center, turn the robot one step according to the position) #433
                        AGC.runActionGroup(right_move, lock_servos=lock_servos) #434
                    elif -40 < object_center_x - CENTER_X < -20:                       #435
                        AGC.runActionGroup(left_move, lock_servos=lock_servos) #436
                    else: #437
                        step = 4  #438
                elif step == 4:  #靠近物体(approach the object) #439
                    if 300 < object_center_y <= 340: #440
                        AGC.runActionGroup('go_forward_one_step', lock_servos=lock_servos) #441
                        time.sleep(0.2) #442
                    elif 0 <= object_center_y <= 300: #443
                        AGC.runActionGroup(go_forward, lock_servos=lock_servos) #444
                    else: #445
                        if object_center_y >= 370: #446
                            go_step = 2 #447
                        else: #448
                            go_step = 3 #449
                        if abs(object_center_x - CENTER_X) <= 20: #450
                            stop_detect = True #451
                            step = 5 #452
                        else: #453
                            step = 3 #454
                elif step == 5:  # 拿起或者放下物体(pick up or put down the object) #455
                    if find_box: #456
                        AGC.runActionGroup('go_forward_one_step', times=3) #457
                        AGC.runActionGroup('stand', lock_servos=lock_servos) #458
                        AGC.runActionGroup('move_up') #459
                        lock_servos = LOCK_SERVOS #460
                        step = 6     #461
                    else: #462
                        AGC.runActionGroup('go_forward_one_step', times=go_step, lock_servos=lock_servos) #463
                        AGC.runActionGroup('stand', lock_servos=lock_servos) #464
                        AGC.runActionGroup('put_down') #465
                        AGC.runActionGroup(back, times=5, with_stand=True) #466
                        speech.play_audio(os.path.join(audio_path, 'transport_finish.wav')) #467
                        lock_servos = '' #468
                        step = 6 #469
                        object_color = None #470
            elif object_center_x == -1:  # 找不到目标时，转头，转身子来寻找(when unable to find the target, turn the head or rotate the body to search) #471
                if start_count: #472
                    start_count = False #473
                    time_start = time.time() #474
                else: #475
                    if time.time() - time_start > 0.5: #476
                        if 0 < servo_data['servo2'] - x_dis <= abs(d_x) and d_y > 0: #477
                            x_dis = servo_data['servo2'] #478
                            y_dis = servo_data['servo1'] #479
                            
                            ctl.set_pwm_servo_pulse(1, y_dis, 20) #481
                            ctl.set_pwm_servo_pulse(2, x_dis, 20) #482
                            
                            AGC.runActionGroup(turn_right, times=5, lock_servos=lock_servos) #484
                        elif head_turn == 'left_right': #485
                            x_dis += d_x             #486
                            if x_dis > servo_data['servo2'] + 400 or x_dis < servo_data['servo2'] - 400: #487
                                if head_turn == 'left_right': #488
                                    head_turn = 'up_down' #489
                                d_x = -d_x #490
                        elif head_turn == 'up_down': #491
                            y_dis += d_y #492
                            if y_dis > servo_data['servo1'] + 300 or y_dis < servo_data['servo1']: #493
                                if head_turn == 'up_down': #494
                                    head_turn = 'left_right' #495
                                d_y = -d_y #496

                        ctl.set_pwm_servo_pulse(1, y_dis, 20) #498
                        ctl.set_pwm_servo_pulse(2, x_dis, 20) #499
                        time.sleep(0.02) #500
            else: #501
                time.sleep(0.01) #502
        else: #503
            time.sleep(0.01) #504

#启动动作的线程(start action thread) #506
th = threading.Thread(target=move) #507
th.daemon = True #508
th.start() #509

cmd_dict = {b"\xaa\x55\x03\x00\xfb": 'wakeup', #511
            b"\xaa\x55\x02\x00\xfb": 'sleep', #512
            b"\xaa\x55\x00\x05\xfb": 'transport_red', #513
            b"\xaa\x55\x00\x06\xfb": 'transport_green', #514
            b"\xaa\x55\x00\x07\xfb": 'transport_blue' #515
            } #516

def run(img): #518
    global step  #519
    global turn #520
    global stop_detect, find_box #521
    global color, color_center_x, color_center_y, color_angle #522
    global object_color, object_center_x, object_center_y, object_angle #523

    if not __isRunning or stop_detect: #525
        if step == 5: #526
            object_center_x = 0 #527
        elif step == 6: #528
            find_box = not find_box #529
            object_center_x = -2 #530
            step = 1 #531
            stop_detect = False #532
       
        return img #534
    
    data = wonderecho.detect() #536
    if data in cmd_dict: #537
        if cmd_dict[data] == 'transport_red': #538
           object_color = 'red' #539
           speech.play_audio(os.path.join(audio_path, 'transport_red.wav')) #540
        elif cmd_dict[data] == 'transport_green': #541
            object_color = 'green' #542
            speech.play_audio(os.path.join(audio_path, 'transport_green.wav')) #543
        elif cmd_dict[data] == 'transport_blue': #544
            object_color = 'blue' #545
            speech.play_audio(os.path.join(audio_path, 'transport_blue.wav')) #546
            speech.play_audio(os.path.join(audio_path, 'transport_blue.wav')) #547
    
    if object_color is None: #549
        object_center_x = -4 #550
        return img #551
    
    color, color_center_x, color_center_y, color_angle = colorDetect(img, object_color)  # 颜色检测，返回颜色，中心坐标，角度 #553
    
    # 如果是搬运阶段(if it is the transportation stage) #555
    if find_box: #556
        object_center_x, object_center_y, object_angle = color_center_x, color_center_y, color_angle #557
    else: #558
        tag_data = apriltagDetect(img) # apriltag检测(apriltag detection) #559
        
        if object_color is None: #561
            return img #562
        if tag_data[color_tag[object_color] - 1][0] != -1:  # 如果检测到目标arpiltag(if the target apriltag is detected) #563
            object_center_x, object_center_y, object_angle = tag_data[color_tag[object_color] - 1] #564
        else:  # 如果没有检测到目标arpiltag，就通过其他arpiltag来判断相对位置(if the target apriltag is not detected, then determine the relative position using other apriltags) #565
            turn = getTurn(color_tag[object_color], tag_data) #566
            if turn == 'None': #567
                object_center_x, object_center_y, object_angle = -1, -1, 0 #568
            else:  # 完全没有检测到apriltag(if no apriltag is detected at all) #569
                object_center_x, object_center_y, object_angle = -3, -1, 0 #570
    
    return img #572

class WonderEcho: #574
    def __init__(self, port): #575
        self.serialHandle = serial.Serial(None, 115200, serial.EIGHTBITS, serial.PARITY_NONE, serial.STOPBITS_ONE, timeout=0.02) #576
        self.serialHandle.rts = False #577
        self.serialHandle.dtr = False #578
        self.serialHandle.setPort(port) #579
        self.serialHandle.open() #580
        self.serialHandle.reset_input_buffer() #581

    def detect(self): #583
        return self.serialHandle.read(5) #584

    def exit(self): #586
        self.serialHandle.close() #587


if __name__ == '__main__': #590
    init() #591
    start() #592
    
    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #594
    if open_once: #595
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #596
    else: #597
        my_camera = Camera.Camera() #598
        my_camera.camera_open()           #599
    AGC.runActionGroup('stand_slow') #600
    wonderecho = WonderEcho('/dev/ttyUSB0') #601
    speech.play_audio(os.path.join(audio_path, 'ready.wav')) #602
    while True: #603
        ret, img = my_camera.read() #604
        if ret: #605
            frame = img.copy() #606
            Frame = run(frame) #607
            cv2.imshow('Frame', Frame) #608
            key = cv2.waitKey(1) #609
            if key == 27: #610
                break #611
        else: #612
            time.sleep(0.01) #613
    my_camera.camera_close() #614
    cv2.destroyAllWindows() #615
