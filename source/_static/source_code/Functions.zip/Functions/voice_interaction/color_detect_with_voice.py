#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import os #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9

from speech import speech #11
import hiwonder.Camera as Camera #12
import hiwonder.Misc as Misc #13
import hiwonder.ros_robot_controller_sdk as rrc #14
from hiwonder.Controller import Controller #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17

''' #19
    程序功能：颜色识别播报(program function: color recognition announcement) #20

    运行效果：   当听到机器人播报“我准备好了”的语音后，可将不同颜色的物品依次置于摄像头前。 #22
                当识别到后，便会播报该颜色对应的词条，并且播报音色各不相同。(running effect: when you hear the robot say 'I'm ready,' you can place items of different colors in front of the camera one by one.  #23
                Once recognized, it will announce the corresponding word for that color, with each color having a different tone) #24
                    

    对应教程文档路径：  1 教程资料\10.语音交互课程\11.3 颜色识别播报 #27
''' #28

# 检查 Python 版本是否为 Python 3，若不是则打印提示信息并退出程序(check if the Python version is Python 3. If not, print a prompt message and exit the program) #30
if sys.version_info.major == 2: #31
    print('Please run this program with python3!') #32
    sys.exit(0) #33
audio_path = os.path.join(os.path.abspath(os.path.join(os.path.split(os.path.realpath(__file__))[0], 'audio')))  #34
# 调试模式标志量(debug mode flag variable) #35
debug = False #36
speech.set_volume(70) #37
range_rgb = { #38
    'red': (0, 0, 255), #39
    'blue': (255, 0, 0), #40
    'green': (0, 255, 0), #41
    'black': (0, 0, 0), #42
    'white': (255, 255, 255), #43
} #44

lab_data = None #46
servo_data = None #47
# 加载配置文件数据(load configuration file data) #48
def load_config(): #49
    global lab_data, servo_data #50
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #52
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #53


# 找出面积最大的轮廓(find the contour with the maximal area) #56
# 参数为要比较的轮廓的列表(parameter is the list of contour to be compared) #57
def getAreaMaxContour(contours): #58
    contour_area_temp = 0 #59
    contour_area_max = 0 #60
    areaMaxContour = None #61

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #63
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour area) #64
        if contour_area_temp > contour_area_max: #65
            contour_area_max = contour_area_temp #66
            if contour_area_temp > 50:  # 只有在面积大于300时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 300 are considered valid; the contour with the largest area is used to filter out interference) #67
                areaMaxContour = c #68

    return areaMaxContour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal area) #70

# 初始化机器人底层驱动(initialize robot underlying drivers) #72
board = rrc.Board() #73
ctl = Controller(board) #74

# 初始化机器人舵机初始位置(initialize tge servo initialization position of robot) #76
def initMove(): #77
  ctl.set_pwm_servo_pulse(1, 1500, 500) #78
  ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #79

color_list = [] #81
detect_color = 'None' #82
action_finish = True #83
draw_color = range_rgb["black"] #84
# 变量重置(variable reset) #85
def reset(): #86
    global draw_color #87
    global color_list #88
    global detect_color #89
    global action_finish #90
    
    color_list = [] #92
    detect_color = 'None' #93
    action_finish = True #94
    draw_color = range_rgb["black"] #95
    
# app初始化调用(app initialization calling) #97
def init(): #98
    print("ColorDetect Init") #99
    load_config() #100
    initMove() #101
        
__isRunning = False #103
# app开始玩法调用(app start program calling) #104
def start(): #105
    global __isRunning #106
    reset() #107
    __isRunning = True #108
    print("ColorDetect Start") #109

# app停止玩法调用(app stop program calling) #111
def stop(): #112
    global __isRunning #113
    __isRunning = False #114
    print("ColorDetect Stop") #115

# app退出玩法调用(app exit program calling) #117
def exit(): #118
    global __isRunning #119
    __isRunning = False #120
    AGC.runActionGroup('stand_slow') #121
    print("ColorDetect Exit") #122

color_dict = {'red': '红色', #124
        'green': '绿色', #125
        'blue': '蓝色' #126
        } #127

def move(): #129
    global draw_color #130
    global detect_color #131
    global action_finish #132
    
    while True: #134
        if debug: #135
            return #136
        if __isRunning: #137
            # 根据识别到的颜色，采用不同的音色去播报(based on the recognized color, use different tones to announce) #138
            if detect_color != 'None': #139
                if detect_color == 'red': #140
                    speech.play_audio(os.path.join(audio_path, 'red.wav')) #141
                elif detect_color == 'green': #142
                    speech.play_audio(os.path.join(audio_path, 'green.wav')) #143
                elif detect_color == 'blue': #144
                    speech.play_audio(os.path.join(audio_path, 'blue.wav')) #145
                time.sleep(2) #146
                detect_color = 'None' #147
                draw_color = range_rgb["black"] #148
            else: #149
                time.sleep(0.01) #150
        else: #151
            time.sleep(0.01) #152

# 运行子线程(run sub-thread) #154
th = threading.Thread(target=move) #155
th.daemon = True #156
th.start() #157

size = (320, 240) #159
def run(img): #160
    global draw_color #161
    global color_list #162
    global detect_color #163
    global action_finish #164
    
    img_copy = img.copy() #166
    img_h, img_w = img.shape[:2] #167

    if not __isRunning: #169
        return img #170

    frame_resize = cv2.resize(img_copy, size, interpolation=cv2.INTER_NEAREST) #172
    frame_gb = cv2.GaussianBlur(frame_resize, (3, 3), 3)       #173
    frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to the LAB space) #174

    max_area = 0 #176
    color_area_max = None     #177
    areaMaxContour_max = 0 #178
    
    if action_finish: #180
        for i in lab_data: #181
            if i != 'black' and i != 'white': #182
                frame_mask = cv2.inRange(frame_lab, #183
                                         (lab_data[i]['min'][0], #184
                                          lab_data[i]['min'][1], #185
                                          lab_data[i]['min'][2]), #186
                                         (lab_data[i]['max'][0], #187
                                          lab_data[i]['max'][1], #188
                                          lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform bitwise operation to original image and mask) #189
                eroded = cv2.erode(frame_mask, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))  #腐蚀(corrosion) #190
                dilated = cv2.dilate(eroded, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))) #膨胀(dilation) #191
                if debug: #192
                    cv2.imshow(i, dilated) #193
                contours = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out contours) #194
                areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #195
                if areaMaxContour is not None: #196
                    if area_max > max_area:#找最大面积(find the maximal area) #197
                        max_area = area_max #198
                        color_area_max = i #199
                        areaMaxContour_max = areaMaxContour #200
        if max_area > 200:  # 有找到最大面积(the maximal area is found) #201
            ((object_center_x, object_center_y), radius) = cv2.minEnclosingCircle(areaMaxContour_max)  # 获取最小外接圆(get the minimum bounding circumcircle) #202
            object_center_x = int(Misc.map(object_center_x, 0, size[0], 0, img_w)) #203
            object_center_y = int(Misc.map(object_center_y, 0, size[1], 0, img_h)) #204
            radius = int(Misc.map(radius, 0, size[0], 0, img_w))             #205
            cv2.circle(img, (object_center_x, object_center_y), radius, range_rgb[color_area_max], 2)#画圆(draw circle) #206

            if color_area_max == 'red':  #红色最大(red is the maximal area) #208
                color = 1 #209
            elif color_area_max == 'green':  #绿色最大(green is the maximal area) #210
                color = 2 #211
            elif color_area_max == 'blue':  #蓝色最大(blue is the maximal area) #212
                color = 3 #213
            else: #214
                color = 0 #215
            color_list.append(color) #216

            if len(color_list) == 5:  #多次判断(multiple judgement) #218
                # 取平均值(take average value) #219
                color = int(round(np.mean(np.array(color_list)))) #220
                color_list = [] #221
                if color == 1: #222
                    detect_color = 'red' #223
                    draw_color = range_rgb["red"] #224
                elif color == 2: #225
                    detect_color = 'green' #226
                    draw_color = range_rgb["green"] #227
                elif color == 3: #228
                    detect_color = 'blue' #229
                    draw_color = range_rgb["blue"] #230
                else: #231
                    detect_color = 'None' #232
                    draw_color = range_rgb["black"]                #233
        else: #234
            detect_color = 'None' #235
            draw_color = range_rgb["black"] #236
            
    cv2.putText(img, "Color: " + detect_color, (10, img.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65, draw_color, 2) #238
    
    return img #240

if __name__ == '__main__': #242
    sys.path.append("/home/pi/TonyPi/Functions") #243
    from CameraCalibration.CalibrationConfig import * #244
    
    #加载参数(load parameters) #246
    param_data = np.load(calibration_param_path + '.npz') #247

    #获取参数(get parameters) #249
    mtx = param_data['mtx_array'] #250
    dist = param_data['dist_array'] #251
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #252
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #253

    debug = False #255
    if debug: #256
        print('Debug Mode') #257
        
    init() #259
    start() #260

    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #262
    if open_once: #263
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #264
    else: #265
        my_camera = Camera.Camera() #266
        my_camera.camera_open()   #267
    AGC.runActionGroup('stand') #268
    speech.play_audio(os.path.join(audio_path, 'ready.wav')) #269
    while True: #270
        ret, img = my_camera.read() #271
        if img is not None: #272
            frame = img.copy() #273
            frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)  # 畸变矫正(distortion correction) #274
            Frame = run(frame) #275
            cv2.imshow('Frame', Frame) #276
            key = cv2.waitKey(1) #277
            if key == 27: #278
                break #279
        else: #280
            time.sleep(0.01) #281
    my_camera.camera_close() #282
    cv2.destroyAllWindows() #283
