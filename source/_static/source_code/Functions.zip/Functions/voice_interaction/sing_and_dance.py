#!/usr/bin/python3 #1
# coding=utf8 #2
from speech import speech #3
import hiwonder.ActionGroupControl as AGC #4

action_name = '21' #6
speech.set_volume(20) #7
#speech.play_audio("/home/pi/TonyPi/audio/{}.wav".format(action_name), volume=70, block=False) #8
speech.play_audio("/home/pi/TonyPi/audio/{}.wav".format(action_name), block=False) #9
AGC.runActionGroup(action_name) #10

