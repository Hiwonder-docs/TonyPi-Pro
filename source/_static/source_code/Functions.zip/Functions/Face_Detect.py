#!/usr/bin/python3 #1
# coding=utf8 #2
import sys #3
import cv2 #4
import math #5
import time #6
import threading #7
import numpy as np #8
import mediapipe as mp #9
import hiwonder.ros_robot_controller_sdk as rrc #10
import hiwonder.yaml_handle as yaml_handle #11
import hiwonder.Camera as Camera #12

# 人脸检测(face detection) #14

# 初始化机器人底层驱动(initialize robot underlying driver) #16
board = rrc.Board() #17


# 导入人脸识别模块(import human face recognition module) #20
face = mp.solutions.face_detection #21
# 自定义人脸识别方法，最小的人脸检测置信度0.5(custom human face recognition method, the minimum face detection confidence is 0.5) #22
face_detection = face.FaceDetection(min_detection_confidence=0.5) #23

di_once = True #25
detect_people = False #26
def buzzer(): #27
    global di_once #28
    global detect_people #29
    
    while True: #31
        if detect_people and di_once: #32
            board.set_buzzer(1900, 0.3, 0.7, 1) # 以1900Hz的频率，持续响0.3秒，关闭0.7秒，重复1次(at a frequency of 1900Hz, sound for 0.1 seconds, then pause for 0.9 seconds, repeat once) #33
            di_once = False #34
        else: #35
            time.sleep(0.01) #36
            
# 运行子线程(run sub-thread) #38
th = threading.Thread(target=buzzer) #39
th.daemon = True #40
th.start() #41

detect_count = 0 #43
miss_count = 0 #44
size = (320, 240) #45
def run(img): #46
    global detect_count, miss_count #47
    global di_once #48
    global detect_people #49
    
    img_copy = img.copy() #51
    img_h, img_w = img.shape[:2] #52

    image_rgb = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB) # 将BGR图像转为RGB图像(convert the BGR image to RGB image) #54
    results = face_detection.process(image_rgb) # 将每一帧图像传给人脸识别模块(pass each frame of the image to the face recognition module) #55
    if results.detections:   # 如果检测不到人脸那就返回None(if no face is detected, return None) #56
        for index, detection in enumerate(results.detections): # 返回人脸索引index(第几张脸)，和关键点的坐标信息(return the face index (which face) and the coordinate information of the keypoints) #57
            bboxC = detection.location_data.relative_bounding_box # 设置一个边界框，接收所有的框的xywh及关键点信息(set up a bounding box to receive the xywh and keypoint information for all boxes) #58
            
             # 将边界框的坐标点,宽,高从比例坐标转换成像素坐标(convert the coordinates, width, and height of the bounding box from relative coordinates to pixel coordinates) #60
            bbox = (int(bboxC.xmin * img_w), int(bboxC.ymin * img_h),   #61
                   int(bboxC.width * img_w), int(bboxC.height * img_h)) #62
            cv2.rectangle(img, bbox, (0,255,0), 2)  # 在每一帧图像上绘制矩形框(draw a rectangle on each frame of the image) #63
    
        detect_count += 1 #65
        if detect_count > 20: #66
            detect_people = True #67
    else: #68
        detect_count = 0 #69
        detect_people = False #70
        miss_count += 1 #71
        if miss_count > 20: #72
            di_once = True #73

    return img #75

if __name__ == '__main__': #77
    from CameraCalibration.CalibrationConfig import * #78
    
    #加载参数(load parameters) #80
    param_data = np.load(calibration_param_path + '.npz') #81

    #获取参数(get parameters) #83
    mtx = param_data['mtx_array'] #84
    dist = param_data['dist_array'] #85
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #86
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5)     #87

    open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once'] #89
    if open_once: #90
        my_camera = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg') #91
    else: #92
        my_camera = Camera.Camera() #93
        my_camera.camera_open() #94
    
    print("Face_Detect Init") #96
    print("Face_Detect Start") #97
    
    while True: #99
        ret, img = my_camera.read() #100
        if img is not None: #101
            frame = img.copy() #102
            Frame = run(frame)            #103
            cv2.imshow('Frame', Frame) #104
           
            key = cv2.waitKey(1) #106
            if key == 27: #107
                break #108
        else: #109
            time.sleep(0.01) #110
    my_camera.camera_close() #111
    cv2.destroyAllWindows() #112
