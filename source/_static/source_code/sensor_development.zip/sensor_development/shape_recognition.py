#!/usr/bin/python3 #1
# coding=utf8 #2
#4.拓展课程学习\8.拓展课程之传感器应用开发课程\第4课 形状识别\第2节 形状识别(4.Advanced Lessons\8.Sensor Development Course\Lesson4 Shape Recognition\2.Shape Recognition) #3
import sys #4
import cv2 #5
import math #6
import time #7
import signal #8
import threading #9
import numpy as np #10
import hiwonder.ros_robot_controller_sdk as rrc #11
from hiwonder.Controller import Controller #12
from hiwonder import dot_matrix_sensor #13
import hiwonder.Camera as Camera #14
import hiwonder.ActionGroupControl as AGC #15
import hiwonder.yaml_handle as yaml_handle #16


if sys.version_info.major == 2: #19
    print('Please run this program with python3!') #20
    sys.exit(0) #21
 
# 点阵显示形状(dot-matrix display shape) #23
# 点阵接口：扩展板io7、io8(dot-matrix interface: expansion board io7、io8) #24

dms = dot_matrix_sensor.TM1640(dio=7, clk=8) #26

lab_data = None #28
servo_data = None #29
move_st = True #30

def load_config(): #32
    global lab_data, servo_data #33
    
    lab_data = yaml_handle.get_yaml_data(yaml_handle.lab_file_path) #35
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #36

board = rrc.Board() #38
ctl = Controller(board) #39

# 初始位置(initial position) #41
def inidmsove(): #42
    ctl.set_pwm_servo_pulse(1, 1350, 500) #43
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #44


# 找出面积最大的轮廓(find out the contour with the maximal area) #47
# 参数为要比较的轮廓的列表(the parameter is the list of contour to be compared) #48
def getAreaMaxContour(contours): #49
    contour_area_temp = 0 #50
    contour_area_max = 0 #51
    area_max_contour = None #52

    for c in contours:  # 历遍所有轮廓(iterate through all contours) #54
        contour_area_temp = math.fabs(cv2.contourArea(c))  # 计算轮廓面积(calculate contour mask) #55
        if contour_area_temp > contour_area_max: #56
            contour_area_max = contour_area_temp #57
            if contour_area_temp > 50:  # 只有在面积大于50时，最大面积的轮廓才是有效的，以过滤干扰(only contours with an area greater than 50 are considered valid, representing the largest area, to filter out interference) #58
                area_max_contour = c #59

    return area_max_contour, contour_area_max  # 返回最大的轮廓(return the contour with the maximal contour) #61

shape_length = 0 #63

def run(): #65
    global shape_length #66
    
    while move_st: #68
        if shape_length == 3: #69
            print('三角形') #70
            ## 显示'三角形' (display 'triangle') #71
            dms.display_buf = (0x01, 0x03, 0x05, 0x09, 0x11, 0x21, 0x41, 0x81, #72
                              0x41, 0x21, 0x11, 0x09, 0x05, 0x03, 0x01, 0x00) #73
            dms.update_display() #74
            
        elif shape_length == 4: #76
            print('矩形') #77
            ## 显示'矩形'(display 'rectangle') #78
            dms.display_buf = (0x00, 0x00, 0x00, 0x00, 0xff, 0x81, 0x81, 0x81, #79
                              0x81, 0x81, 0x81,0xff, 0x00, 0x00, 0x00, 0x00) #80
            dms.update_display() #81
            
        elif shape_length >= 6:            #83
            print('圆') #84
            ## 显示'圆形'(display 'circle') #85
            dms.display_buf = (0x00, 0x00, 0x00, 0x00, 0x1c, 0x22, 0x41, 0x41, #86
                              0x41, 0x22, 0x1c,0x00, 0x00, 0x00, 0x00, 0x00) #87
            dms.update_display() #88
            
        else: #90
            ## 清屏(clear screen) #91
            dms.display_buf = [0] * 16 #92
            dms.update_display() #93
            print('None') #94
            
       
        
# 运行子线程(run sub-thread) #98
th = threading.Thread(target=run) #99
th.daemon = True #100
th.start() #101

shape_list = [] #103
action_finish = True #104

def Stop(signum, frame): #106
    global move_st #107
    move_st = False #108
    dms.display_buf = [0] * 16 #109
    dms.update_display() #110
    print('关闭中...') #111
    AGC.runActionGroup('lift_down') #112

signal.signal(signal.SIGINT, Stop) #114


if __name__ == '__main__': #117
    from hiwonder.CalibrationConfig import * #118
    
    param_data = np.load(calibration_param_path + '.npz') #120
    
    mtx = param_data['mtx_array'] #122
    dist = param_data['dist_array'] #123
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #124
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #125
    
    load_config() #127
    inidmsove() #128
    my_camera = Camera.Camera() #129
    my_camera.camera_open() #130
    AGC.runActionGroup('stand_slow') #131
    AGC.runActionGroup('lift_up') #132
    while move_st: #133
        ret, img = my_camera.read() #134
        if ret: #135
            img_copy = img.copy() #136
            img_h, img_w = img.shape[:2] #137
            frame_gb = cv2.GaussianBlur(img_copy, (3, 3), 3)       #138
            frame_lab = cv2.cvtColor(frame_gb, cv2.COLOR_BGR2LAB)  # 将图像转换到LAB空间(convert the image to LAB space) #139
            max_area = 0 #140
            color_area_max = None     #141
            areaMaxContour_max = 0 #142

            if action_finish: #144
                for i in lab_data: #145
                    if i != 'white' and i != 'black': #146
                        frame_mask = cv2.inRange(frame_lab, #147
                                         (lab_data[i]['min'][0], #148
                                          lab_data[i]['min'][1], #149
                                          lab_data[i]['min'][2]), #150
                                         (lab_data[i]['max'][0], #151
                                          lab_data[i]['max'][1], #152
                                          lab_data[i]['max'][2]))  #对原图像和掩模进行位运算(perform the bitwise operation to original image and mask) #153
                        opened = cv2.morphologyEx(frame_mask, cv2.MORPH_OPEN, np.ones((6,6),np.uint8))  #开运算(opening operation) #154
                        closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((6,6),np.uint8)) #闭运算(closing operation) #155
                        contours = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[-2]  #找出轮廓(find out the contour) #156
                        areaMaxContour, area_max = getAreaMaxContour(contours)  #找出最大轮廓(find out the contour with the maximal area) #157
                        if areaMaxContour is not None: #158
                            if area_max > max_area:#找最大面积(find the maximal area) #159
                                max_area = area_max #160
                                color_area_max = i #161
                                areaMaxContour_max = areaMaxContour #162
            if max_area > 200:                    #163
                cv2.drawContours(img, areaMaxContour_max, -1, (0, 0, 255), 2) #164
                # 识别形状(recognize shape) #165
                # 周长  0.035 根据识别情况修改，识别越好，越小(perimeter: 0.035. Modify according to recognition. The better the recognition, the smaller) #166
                epsilon = 0.035 * cv2.arcLength(areaMaxContour_max, True) #167
                # 轮廓相似(contour similarity) #168
                approx = cv2.approxPolyDP(areaMaxContour_max, epsilon, True) #169
                shape_list.append(len(approx)) #170
                if len(shape_list) == 30: #171
                    shape_length = int(round(np.mean(shape_list)))                             #172
                    shape_list = [] #173
                    print(shape_length) #174
            # 纠正镜头畸变(correcting lens distortion) #175
            img = cv2.remap(img.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)   #176
            frame_resize = cv2.resize(img, (320, 240)) #177
            cv2.imshow('frame', frame_resize) #178
            key = cv2.waitKey(1) #179
            if key == 27: #180
                break #181
        else: #182
            time.sleep(0.01) #183
    my_camera.camera_close() #184
    cv2.destroyAllWindows() #185

