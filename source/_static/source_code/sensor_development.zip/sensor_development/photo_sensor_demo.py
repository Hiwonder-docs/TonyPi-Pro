#!/usr/bin/python3 #1
# coding=utf8 #2
#4.拓展课程学习\8.拓展课程之传感器应用开发课程\第5课 智能补光\第2节 智能补光(4.Advanced Lessons\8.Sensor Development Course\Lesson5 Intelligent Fill Light\2.Intelligent Fill Light) #3
import os #4
import sys #5
import cv2 #6
import math #7
import time #8
import threading #9
import numpy as np #10
import gpiod #11
import hiwonder.ros_robot_controller_sdk as rrc #12
from hiwonder.Controller import Controller #13
import hiwonder.Camera as Camera #14
import hiwonder.Sonar as Sonar #15
import hiwonder.apriltag as apriltag #16
import hiwonder.ActionGroupControl as AGC #17
import hiwonder.yaml_handle as yaml_handle #18

if sys.version_info.major == 2: #20
    print('Please run this program with python3!') #21
    sys.exit(0) #22

# 光敏控制超声波RGB(photosensitive control ultrasonic RGB) #24


servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #27

board = rrc.Board() #29
ctl = Controller(board) #30
# 初始位置(initial position) #31
def initMove(): #32
    ctl.set_pwm_servo_pulse(1, 1500, 500) #33
    ctl.set_pwm_servo_pulse(2, servo_data['servo2'], 500) #34
    AGC.runActionGroup('lift_up') #35


st = 0 #38
s = Sonar.Sonar() #39
s.setRGBMode(0) #40
s.setRGB(1, (0,0,0)) #设置超声波RGB关闭(set ultrasonic RGB to off) #41
s.setRGB(0, (0,0,0)) #42

chip = gpiod.Chip('gpiochip4') #44
light = chip.get_line(8) #45
light.request(consumer="light", type=gpiod.LINE_REQ_DIR_IN, flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP) #46
def move(): #47
    global st #48
    
    while True: #50
        state = light.get_value() #读取引脚数字值(read pin numerical value) #51
        
        if state: #53
            time.sleep(0.1) #54
            if state: #55
                if st :            #这里做一个判断，防止反复响(make a judgment to prevent repeated echoes here) #56
                    st = 0 #57
                    board.set_buzzer(1900, 0.1, 0.9, 1)   #设置蜂鸣器响0.1秒(set the buzzer to emit for 0.1 seconds) #58
                    s.setRGB(1, (255,255,255))  #设置超声波RGB亮白色(set the ultrasonic RGB to bright white) #59
                    s.setRGB(0, (255,255,255)) #60
        else: #61
            if not st: #62
                st = 1 #63
                s.setRGB(1, (0,0,0)) #设置超声波RGB关闭(set ultrasonic RGB to close) #64
                s.setRGB(0, (0,0,0)) #65
            
        time.sleep(0.01) #67

# 运行子线程(run sub-thread) #69
th = threading.Thread(target=move) #70
th.daemon = True #71
th.start() #72

# 检测apriltag(detect apriltag) #74
detector = apriltag.Detector(searchpath=apriltag._get_demo_searchpath()) #75

def apriltagDetect(img):    #77
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #78
    detections = detector.detect(gray, return_image=False) #79

    if len(detections) != 0: #81
        for detection in detections:                        #82
            corners = np.int0(detection.corners)  # 获取四个角点(get four corner points) #83
            cv2.drawContours(img, [np.array(corners, int)], -1, (0, 255, 255), 2) #84

            tag_family = str(detection.tag_family, encoding='utf-8')  # 获取tag_family(get tag_family) #86
            tag_id = int(detection.tag_id)  # 获取tag_id(get tag_id) #87

            objective_x, objective_y = int(detection.center[0]), int(detection.center[1])  # 中心点(center point) #89
            
            object_angle = int(math.degrees(math.atan2(corners[0][1] - corners[1][1], corners[0][0] - corners[1][0])))  # 计算旋转角(calculate rotation angle) #91
            
            return [tag_family, tag_id, objective_x, objective_y] #93
            
    return None, None, None, None #95


def run(img): #98
    
    tag_family, tag_id, objective_x, objective_y = apriltagDetect(img) # apriltag检测(apriltag detection) #100
    print('Apriltag:',objective_x,objective_y) #101
        
    return img #103

if __name__ == '__main__': #105
    from hiwonder.CalibrationConfig import * #106
    
    param_data = np.load(calibration_param_path + '.npz') #108
    
    mtx = param_data['mtx_array'] #110
    dist = param_data['dist_array'] #111
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #112
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #113
  
    initMove() #115
    camera = cv2.VideoCapture(-1) #116
    
    while True: #118
        ret,img = camera.read() #119
        if ret: #120
            frame = img.copy() #121
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT) #122
            Frame = run(frame)            #123
            cv2.imshow('Frame', Frame) #124
            key = cv2.waitKey(1) #125
            if key == 27: #126
                break #127
        else: #128
            time.sleep(0.01) #129
    my_camera.camera_close() #130
    cv2.destroyAllWindows() #131
    
