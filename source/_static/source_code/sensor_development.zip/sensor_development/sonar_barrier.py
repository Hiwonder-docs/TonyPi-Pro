#!/usr/bin/python3 #1
# coding=utf8 #2
#4.拓展课程学习\8.拓展课程之传感器应用开发课程\第3课 躲避障碍\第2节 躲避障碍(4.Advanced Lessons\8.Sensor Development Course\Lesson3 Obstacle Avoidance\2.Obstacle Avoidance) #3
import os #4
import sys #5
import time #6
import threading #7
import numpy as np #8
import hiwonder.ros_robot_controller_sdk as rrc #9
from hiwonder.Controller import Controller #10
import hiwonder.Sonar as Sonar #11
import hiwonder.ActionGroupControl as AGC #12

if sys.version_info.major == 2: #14
    print('Please run this program with python3!') #15
    sys.exit(0) #16

# 超声波避障(ultrasonic obstacle avoidance) #18

board = rrc.Board() #20
ctl = Controller(board) #21

# 抬起左手(raise your left hand) #23
def hand_up(): #24
    ctl.set_bus_servo_pulse(8, 330, 1000) #25
    time.sleep(0.3) #26
    ctl.set_bus_servo_pulse(7,860,1000) #27
    ctl.set_bus_servo_pulse(6,860,1000) #28
    time.sleep(1) #29
# 放下左手(put down your left hand) #30
def hand_down(): #31
    ctl.set_bus_servo_pulse(7,800,1000) #32
    ctl.set_bus_servo_pulse(6,575,1000) #33
    time.sleep(0.3) #34
    ctl.set_bus_servo_pulse(8,725,1000) #35
    time.sleep(1) #36
# 向左边伸手(reach your hand to the left) #37
def hand_left(): #38
    ctl.set_bus_servo_pulse(8,330,1000) #39
    time.sleep(0.3) #40
    ctl.set_bus_servo_pulse(7,500,1000) #41
    ctl.set_bus_servo_pulse(6,920,1000) #42
    time.sleep(1) #43

distance = 99999 #45
#机器人移动子线程(robot movement sub-thread) #46
def move(): #47
    global distance #48
    
    dist_left = [] #50
    dist_right = [] #51
    distance_left = 99999 #52
    distance_right = 99999 #53
    
    while True: #55
        if distance != 99999: #56
            if distance <= 300: #检测前方障碍物(detect obstacles ahead) #57
                distance = 99999 #58
                hand_left() #向左边伸手(reach your hand to the left) #59
                time.sleep(1) #60
                #连续检测左边三次(continuously detect left side three times) #61
                for i in range(3): #62
                    dist_left.append(distance) #63
                    time.sleep(0.05) #64
                #取平均值(take average value) #65
                distance_left = round(np.mean(np.array(dist_left))) #66
                dist_left = [] #67
                hand_up() #68
                
                if distance_left <= 300: #检测左边障碍物(detect obstacles on the left side) #70
                    distance_left = 99999 #71
                    hand_down() # 放下左手(put down your left hand) #72
                    for i in range(5): #向右转(turn right) #73
                        AGC.runActionGroup('turn_right') #74
                        print("turn_right") #75
                        time.sleep(0.2) #76
                        
                    hand_up() #78
                    time.sleep(1) #79
                    # 连续检测右边三次(continuously detect right side three times) #80
                    for i in range(3): #81
                        dist_right.append(distance) #82
                        time.sleep(0.05) #83
                        
                    distance_right = round(np.mean(np.array(dist_right))) #85
                    dist_right = [] #86
                    
                    if distance_right <= 300: #检测右边障碍物(detect obstacles on the right side) #88
                        distance_right = 99999 #89
                        hand_down() #90
                        for i in range(5): #向左转(turn left) #91
                            AGC.runActionGroup('turn_left') #92
                            print("turn_left") #93
                            time.sleep(0.2) #94
                            
                        for i in range(5):#后退(move backward) #96
                            AGC.runActionGroup('back') #97
                            print("back") #98
                        hand_up() #99
                    else: #右边没有障碍物,则直走,前面已经右转(if there are no obstacles on the right, proceed straight. You have already turned right ahead) #100
                        AGC.runActionGroup('go_hand_up1') #101
                        print("go") #102
                else: #左边没有障碍物,则向左转(if there are no obstacles on the left, turn left) #103
                    hand_down() #104
                    for i in range(5): #105
                        AGC.runActionGroup('turn_left') #106
                        print("turn_left") #107
                        time.sleep(0.2) #108
                    hand_up() #109
            else:#前方没有障碍物,则直走(if there are no obstacles ahead, proceed straight) #110
                AGC.runActionGroup('go_hand_up1') #111
                print("go") #112
        else:    #113
            time.sleep(0.01) #114
            
#作为子线程开启(start as a sub-thread) #116
th = threading.Thread(target=move) #117
th.daemon = True #118
th.start() #119

if __name__ == "__main__": #121
    
    distance_list = [] #123
    s = Sonar.Sonar() #124
    s.startSymphony() #125
    
    AGC.runActionGroup('stand_slow') #127
    time.sleep(1) #128
    hand_up() #129
    
    while True: #131
        
        distance_list.append(s.getDistance()) #133
        #print("distance:",s.getDistance()) #134
        #连续检测6次，取平均值(continuously detect 6 times and take the average) #135
        if len(distance_list) >= 6:  #136
            #print(distance_list) #137
            distance = int(round(np.mean(np.array(distance_list)))) #138
            print(distance, 'mm') #139
            distance_list = [] #140
            
        time.sleep(0.01) #142
            
        
                       
    
