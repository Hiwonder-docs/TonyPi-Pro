#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/09/21 #4
import smbus #5
import gpiod #6
import time #7

class AHT10: #9
    CONFIG = [0x08, 0x00] #10
    MEASURE = [0x33, 0x00] #11

    def __init__(self, bus=1, addr=0x38): #13
        self.bus = smbus.SMBus(bus) #14
        self.addr = addr #15
        time.sleep(0.2)  #16

    def getData(self): #18
        # 发送测量命令 #19
        self.bus.write_i2c_block_data(self.addr, 0xAC, self.MEASURE) #20
        time.sleep(0.5)  # 等待传感器完成测量 #21

        # 读取6个字节的数据 #23
        data = self.bus.read_i2c_block_data(self.addr, 0x00, 6) #24
        
        # 调试：打印原始数据 #26
        #print("原始数据:", data) #27

        # 提取温度数据 #29
        temp = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5] #30
        ctemp = ((temp * 200) / 1048576) - 50  # 转换为摄氏度 #31
        
        # 提取湿度数据 #33
        hum = ((data[1] << 16) | (data[2] << 8) | data[3]) >> 4 #34
        chum = int(hum * 100 / 1048576)  # 转换为百分比 #35
        
        return (ctemp, chum) #37

aht10 = AHT10() #39

## 初始化GPIO引脚 #41
chip = gpiod.Chip("gpiochip4") #42
fanPin1 = chip.get_line(8) #43
fanPin1.request(consumer="pin1", type=gpiod.LINE_REQ_DIR_OUT) #44

fanPin2 = chip.get_line(7) #46
fanPin2.request(consumer="pin2", type=gpiod.LINE_REQ_DIR_OUT) #47

def set_fan(start): #49
    if start == 1: #50
        ## 开启风扇, 顺时针 #51
        fanPin1.set_value(1)  # 设置引脚输出高电平 #52
        fanPin2.set_value(0)  # 设置引脚输出低电平 #53
    else: #54
        ## 关闭风扇 #55
        fanPin1.set_value(0)  # 设置引脚输出低电平 #56
        fanPin2.set_value(0)  # 设置引脚输出低电平 #57

count = 0 #59
while True: #60
    try: #61
        temp, hum = aht10.getData() #62
        t = int(temp)  # 转换为整数用于比较 #63
        print(f"温度: {t}°C, 湿度: {hum}%")  # 调试输出 #64
        if t > 20: #65
            count += 1 #66
            if count > 5: #67
                set_fan(1) #68
                count = 0 #69
        else: #70
            count = 0 #71
            set_fan(0) #72
    except KeyboardInterrupt: #73
        set_fan(0) #74
        break #75
