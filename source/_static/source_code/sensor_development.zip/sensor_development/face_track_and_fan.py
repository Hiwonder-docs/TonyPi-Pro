#!/usr/bin/python3 #1
# coding=utf8 #2
#4.拓展课程学习\8.拓展课程之传感器应用开发课程\第1课 人脸追踪风扇\第2节 人脸风扇追踪(4.Advanced Lessons\8.Sensor Development Course\Lesson1 Face Tracking Fan\2. Human Fan Tracking) #3
import sys #4
import cv2 #5
import math #6
import time #7
import threading #8
import numpy as np #9
import mediapipe as mp #10
import gpiod #11
import hiwonder.ros_robot_controller_sdk as rrc #12
from hiwonder.Controller import Controller #13
import hiwonder.Misc as Misc #14
import hiwonder.Camera as Camera #15
import hiwonder.ActionGroupControl as AGC #16
import hiwonder.yaml_handle as yaml_handle #17

# 人脸追踪控制风扇(face tracking control fan) #19

if sys.version_info.major == 2: #21
    print('Please run this program with python3!') #22
    sys.exit(0) #23

# 导入人脸识别模块(import human face recognition module) #25
face = mp.solutions.face_detection #26
# 自定义人脸识别方法，最小的人脸检测置信度0.5(custom human face recognition method, the minimum face detection confidence is 0.5) #27
face_detection = face.FaceDetection(min_detection_confidence=0.5) #28

servo_data = None #30
def load_config(): #31
    global servo_data #32
    
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path) #34

load_config() #36
servo2_pulse = servo_data['servo2'] #37

board = rrc.Board() #39
ctl = Controller(board) #40
# 初始位置(initial position) #41
def initMove(): #42
    ctl.set_pwm_servo_pulse(1, 1600, 500) #43
    ctl.set_pwm_servo_pulse(2, servo2_pulse, 500) #44

d_pulse = 5 #46
start_greet = False #47
robot_is_running = False #48

# 变量重置(variable reset) #50
def reset(): #51
    global d_pulse #52
    global start_greet #53
    global servo2_pulse     #54

    d_pulse = 10 #56
    start_greet = False #57
    servo2_pulse = servo_data['servo2'] #58
    
# 初始化(initialization) #60
def init(): #61
    print("FaceDetect Init") #62
    reset() #63
    initMove() #64

## 初始化引脚模式(initial pin mode) #66
chip = gpiod.Chip("gpiochip4") #67
fanPin1 = chip.get_line(8) #68
fanPin1.request(consumer="pin1", type=gpiod.LINE_REQ_DIR_OUT) #69

fanPin2 = chip.get_line(7) #71
fanPin2.request(consumer="pin2", type=gpiod.LINE_REQ_DIR_OUT) #72

def set_fan(start): #74
               
    if start == 1: #76
        ## 开启风扇, 顺时针(turn on the fan, clockwise) #77
        fanPin1.set_value(1)  # 设置引脚输出高电平(set pin output high voltage) #78
        fanPin2.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #79
    else: #80
        ## 关闭风扇(close fan) #81
        fanPin1.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #82
        fanPin2.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #83


start_ = False #86
def move(): #87
    global start_greet, start_ #88
    global d_pulse, servo2_pulse     #89
    
    while True: #91
        if robot_is_running: #92
            if start_greet: #判断是否识别到人脸的标志(the flag indicating whether a face is recognized) #93
                start_greet = False #94
                pulse = int(Misc.map(servo2_pulse, 1000, 2000, 600, 200)) #把头部舵机的脉宽映射到手部舵机(map the pulse width of the head servo to the hand servo) #95
                # 驱动手部舵机(drive the hand servo) #96
                ctl.set_bus_servo_pulse(16,700,1500)   #97
                time.sleep(1.5) #98
                if pulse < 500: #99
                    ctl.set_bus_servo_pulse(15,200,600)   #100
                    ctl.set_bus_servo_pulse(14,pulse,600) #101
                    time.sleep(0.6) #102
                else: #103
                    ctl.set_bus_servo_pulse(15,pulse-300,600)   #104
                    ctl.set_bus_servo_pulse(14,445,500) #105
                    time.sleep(0.6) #106
                set_fan(1) #开启风扇(turn on fan) #107
              
            else: #109
                set_fan(0) #关闭风扇(turn off fan) #110
                if servo2_pulse > 2000 or servo2_pulse < 1000: #111
                    d_pulse = -d_pulse #112
                #左右转动，检测(rotate left and right, and perform detection) #113
                servo2_pulse += d_pulse        #114
                ctl.set_pwm_servo_pulse(2, servo2_pulse, 60) #115
                time.sleep(0.06) #116
        else: #117
            time.sleep(0.01) #118
            
# 运行子线程(run sub-thread) #120
th = threading.Thread(target=move) #121
th.daemon = True #122
th.start() #123

size = (320, 240) #125
def run(img): #126
    global start_greet #127
       
    img_copy = img.copy() #129
    img_h, img_w = img.shape[:2] #130

    if not robot_is_running: #132
        return img #133

    image_rgb = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB) # 将BGR图像转为RGB图像(convert BGR image to RGB image) #135
    results = face_detection.process(image_rgb) # 将每一帧图像传给人脸识别模块(pass each frame image to the face recognition module) #136
    if results.detections:   # 如果检测不到人脸那就返回None(if no face is detected, return None) #137
        for index, detection in enumerate(results.detections): # 返回人脸索引index(第几张脸)，和关键点的坐标信息(return the face index (which face), and the coordinates of the keypoints) #138
            bboxC = detection.location_data.relative_bounding_box # 设置一个边界框，接收所有的框的xywh及关键点信息(set a bounding box to receive the xywh (x-coordinate, y-coordinate, width, height) and keypoints information for all boxes) #139
            
            # 将边界框的坐标点,宽,高从比例坐标转换成像素坐标(convert the coordinates, width, and height of the bounding box from relative coordinates to pixel coordinates) #141
            bbox = (int(bboxC.xmin * img_w), int(bboxC.ymin * img_h),   #142
                   int(bboxC.width * img_w), int(bboxC.height * img_h)) #143
            cv2.rectangle(img, bbox, (0,255,0), 2)  # 在每一帧图像上绘制矩形框(draw a rectangle on each frame image) #144
            x, y, w, h = bbox  # 获取识别框的信息,xy为左上角坐标点(retrieve information about the recognition box, where xy represents the coordinates of the top-left corner) #145
            center_x =  int(x + (w/2)) #146
            if abs(center_x - img_w/2) < img_w/4: #147
                start_greet = True #148
            else: #149
                set_fan(0) #150
                start_greet = False #151
    
    return img #153

if __name__ == '__main__': #155
    from hiwonder.CalibrationConfig import * #156
    param_data = np.load(calibration_param_path + '.npz') #157
    mtx = param_data['mtx_array'] #158
    dist = param_data['dist_array'] #159
    newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (640, 480), 0, (640, 480)) #160
    mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (640, 480), 5) #161
  
    init() #163
    robot_is_running = True #164
    my_camera = Camera.Camera() #165
    my_camera.camera_open() #166
    AGC.runActionGroup('stand_slow') #167
    while True: #168
        ret,img = my_camera.read() #169
        if ret: #170
            frame = img.copy() #171
            # 纠正镜头畸变(correct lens distortion) #172
            frame = cv2.remap(frame.copy(), mapx, mapy, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)  #173
            Frame = run(frame)            #174
            cv2.imshow('Frame', Frame) #175
            key = cv2.waitKey(1) #176
            if key == 27: #177
                break #178
        else: #179
            time.sleep(0.01) #180
    set_fan(0) #181
    my_camera.camera_close() #182
    cv2.destroyAllWindows() #183
