#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import cv2 #5
from config import * #6
from speech import speech #7

PROMPT = ''' #9
As an image expert, your ability is to accurately locate the target in the pictures sent by users and output the final results according to the "output format". #10
**1. Understand the picture #11
I will give you a picture, please identify the total number of objects in the picture. #12
**2. Object positioning - position #13
Detect the position of each object, based on your knowledge and memory, see the appearance of the object, and identify the specific name of each object. Please output all objects without missing any #14
**output format (please only output the following content, do not say any extra words) #15
{ #16
    "object1": [name1, xmin, ymin, xmax, ymax], #17
    "object2": [name2, xmin, ymin, xmax, ymax], #18
} #19

**Example #21
Output: #22
{ #23
    "object1": ["person", 100, 290, 466, 670], #24
    "object2": ["car", 201, 640, 350, 800], #25
} #26
''' #27

client = speech.OpenAIAPI(vllm_api_key, vllm_base_url) #29
image = cv2.imread('./resources/pictures/detect.jpg') #30
vllm_result = client.vllm('', image, prompt=PROMPT, model='qwen/qwen2.5-vl-72b-instruct:free') #31
print(vllm_result) #32
vllm_result = eval(vllm_result[vllm_result.find('{'):vllm_result.find('}') + 1]) #33
h, w = image.shape[:2] #34
for i in vllm_result: #35
    position = vllm_result[i] #36
    p1 = [position[1], position[2]] #37
    p2 = [position[3], position[4]] #38
    cv2.rectangle(image, p1, p2, (0, 255, 0), 2, 1) #39
while True: #40
    try: #41
        cv2.imshow('image', image) #42
        key = cv2.waitKey(1) #43
        if key != -1: #44
            break #45
    except KeyboardInterrupt: #46
        cv2.destroyAllWindows() #47
        break #48
