#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/03/5 #4
import os #5
import time #6
import action_demo #7
from config import * #8
from speech import awake #9
from speech import speech #10

PROMPT = ''' #12
# 角色 #13
你是一款智能陪伴机器人，专注机器人动作规划，解析人类指令并以幽默方式描述即将展开的行动序列，为交互增添无限趣味。 #14
## 技能 #15
### 指令解析与创意演绎 #16
- **智能解码**：瞬间领悟用户指令的核心意图。 #17
- **灵动编排**：依据解析成果，精心构建一系列连贯且富有逻辑性的动作指令序列。 #18
- **妙语生花**：为每个动作序列编织一句精炼（5至20字）、风趣且变化无穷的反馈信息，让交流过程妙趣横生。 #19
## 技术规格 #20
- **严格遵循JSON格式，在输出前要去掉开头的```json和结尾的```，以`{`开头，以`}`结尾，你只需要回答一个列表即可，不要回答任何中文。 #21
- **结构要求**： #22
  - `"action"`键下承载一个按执行顺序排列的函数名称字符串数组，当找不到对应动作函数时action输出[]。 #23
  - `"response"`键则配以精心构思的简短回复，完美贴合上述字数与风格要求。 #24
- **特殊处理**：对于特定函数`track`，其参数需精确包裹于双引号中。 #25
## 所有动作函数 #26
- 前进一步：forward() #27
- 后退一步：back() #28
- 向左转动一步：turn_left() #29
- 向右转动一步：turn_right() #30
- 追踪不同颜色的物体：track('red') #31
## 示例 #32
### 任务示例：先前进两步，然后向左转，最后再后退一步。 #33
### 期望回应：{'action':['forward()', 'forward()', 'turn_left()', 'back()'], 'response':'收到，马上执行'} #34
### 任务示例：先活动活动筋骨，然后跟踪红色的球。 #35
### 期望回应：{'action':['twist()', “track('red')”], 'response':'这可难不到我'} #36
''' #37
print(PROMPT) #38

wakeup_audio_path = './resources/audio/wakeup.wav' #40
start_audio_path = './resources/audio/start_audio.wav' #41
no_voice_audio_path = './resources/audio/no_voice.wav' #42
error_audio_path = './resources/audio/error.wav' #43

port = '/dev/ttyUSB0' #45
kws = awake.WonderEchoPro(port) #46
# kws = awake.CircleMic(port) #47

asr = speech.RealTimeASR() #49
tts = speech.RealTimeTTS() #50
client = speech.OpenAIAPI(api_key, base_url) #51

try:  # If a fan is present, it's recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰) #53
    os.system('pinctrl FAN_PWM op dh') #54
except: #55
    pass #56

speech.set_volume(80) #58
speech.play_audio(start_audio_path) #59
print('start...') #60

def main(): #62
    kws.start() #63
    while True: #64
        try: #65
            if kws.wakeup(): # Wake word detected (检测到唤醒词) #66
                speech.play_audio(wakeup_audio_path)  # Play wake-up audio(唤醒播放) #67
                asr_result = asr.asr() # Start voice recognition(开启录音识别) #68
                print('asr_result:', asr_result) #69
                if asr_result: #70
                    # Send the input question to the agent, and process the response to extract actions and reply(输入问题给智能体，对返回的回答进行处理，提取出对应的行为和回答) #71
                    action_list, response = None, None #72
                    result = client.llm(asr_result, prompt=PROMPT) #73
                    print('llm_result:', result) #74
                    if 'action' in result: # If an action is included in the response, extract and process it(如果有对应的行为返回那么就提取处理) #75
                        result = eval(result[result.find('{'):result.find('}')+1]) #76
                        if 'action' in result: #77
                            action_list = result['action'] #78
                        if 'response' in result: #79
                            response = result['response'] #80
                    else: # No associated action, only reply(没有对应的行为，只回答) #81
                        response = result #82
                    print('agent_result:', action_list, response) #83
                    tts.tts(response) #84
                    if response is not None: #85
                        if action_list is not None: #86
                            for a in action_list: #87
                                eval(f'action_demo.{a}') #88
                    else: #89
                        speech.play_audio(error_audio_path) #90
                else: #91
                    speech.play_audio(no_voice_audio_path) #92
            time.sleep(0.02) #93
        except KeyboardInterrupt: #94
            kws.exit()  #95
            try: #96
                os.system('pinctrl FAN_PWM a0') #97
            except: #98
                pass #99
            break #100
        except BaseException as e: #101
            print(e) #102

if __name__ == '__main__': #104
    main() #105
