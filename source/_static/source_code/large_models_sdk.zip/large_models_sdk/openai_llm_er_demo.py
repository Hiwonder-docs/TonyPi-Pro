#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
from config import * #5
from speech import speech #6

client = speech.OpenAIAPI(llm_api_key, llm_base_url) #8

messages = [{"role": "user", "content": 'So sad'}] #10
assistant_output = client.llm_multi_turn(messages, model='gpt-4o-mini') #11
print(assistant_output) #12

messages.append({"role": "assistant", "content": assistant_output}) #14

messages.append({"role": "user", "content": 'Ha ha'}) #16
assistant_output = client.llm_multi_turn(messages, model='gpt-4o-mini') #17
print(assistant_output) #18
