#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
from config import * #5
from speech import speech #6

client = speech.OpenAIAPI(api_key, base_url) #8

# Additional parameters can be provided in the following way(更多参数采用以下方式进行输入) #10
# Streaming output(流式输出) #11
# params = {"model": 'qwen-max',  #12
          # "messages": [ #13
            # { #14
                # "role": "user", #15
                # "content": '以科技改变生活写一段50字的中文文案' #16
            # }, #17
          # ], #18
          # "stream": True} #19
# stream = client.llm_origin(params) #20
# for event in stream: #21
    # print(event.choices[0].delta.content) #22

# networked search(联网搜索) #24
# params = {"model": 'qwen-max',  #25
          # "messages": [ #26
            # { #27
                # "role": "user", #28
                # "content": '深圳天气' #29
            # }, #30
          # ], #31
          # "extra_body": { #32
          # "enable_search": True #33
          # } #34
        # } #35
# completion = client.llm_origin(params) #36
# print(completion.choices[0].message.content.strip()) #37

print(client.llm('以科技改变生活写一段50字的中文文案', prompt='', model='qwen-max')) # Here, qwen-max is used as an example. You can replace it with another model name as needed(此处以qwen-max为例，可按需更换模型名称。模型列表)：https://help.aliyun.com/zh/model-studio/getting-started/models #39
