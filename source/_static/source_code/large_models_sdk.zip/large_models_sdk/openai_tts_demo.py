#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/04/08 #4
from config import * #5
from speech import speech   #6

tts = speech.RealTimeOpenAITTS() #8
tts.tts("Hello, Can I help you?") # https://platform.openai.com/docs/guides/text-to-speech #9
tts.tts("Hello, Can I help you?", model="tts-1", voice="onyx", speed=1.0, instructions='Speak in a cheerful and positive tone.') #10
tts.save_audio("Hello, Can I help you?", model="gpt-4o-mini-tts", voice="onyx", speed=1.0, instructions='Speak in a cheerful and positive tone.', audio_format='wav', save_path="./resources/audio/tts_audio.wav") #11

# tts.save_audio("I'm here", model="tts-1-hd", voice="onyx", speed=0.7, audio_format='wav', save_path="./resources/audio/en/wakeup.wav") #13
# tts.save_audio("I'm ready", model="tts-1-hd", voice="onyx", speed=0.9, audio_format='wav', save_path="./resources/audio/en/start_audio.wav") #14
# tts.save_audio("Sorry, would you please repeat again", model="tts-1-hd", voice="onyx", audio_format='wav', save_path="./resources/audio/en/no_voice.wav") #15
# tts.save_audio("Sorry, I can't do that", model="tts-1-hd", voice="onyx", audio_format='wav', save_path="./resources/audio/en/error.wav") #16
# tts.save_audio("OK, Start tracking", model="tts-1-hd", voice="onyx", audio_format='wav', save_path="./resources/audio/en/start_track.wav") #17
# tts.save_audio("Failed to get target", model="tts-1-hd", voice="onyx", audio_format='wav', save_path="./resources/audio/en/track_fail.wav") #18
# tts.save_audio("Already remembered", model="tts-1-hd", voice="onyx", audio_format='wav', save_path="./resources/audio/en/record_finish.wav") #19
