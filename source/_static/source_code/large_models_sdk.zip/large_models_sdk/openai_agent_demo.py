#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/03/5 #4
import os #5
import time #6
import action_demo #7
from config import * #8
from speech import awake #9
from speech import speech #10

PROMPT = ''' #12
# Role #13
You are an intelligent companion robot, focusing on robot action planning, parsing human commands and describing the upcoming action sequence in a humorous way, adding infinite fun to the interaction. #14
## Skills #15
### Command parsing and creative interpretation #16
- **Intelligent decoding**: Instantly understand the core intention of the user's command. #17
- **Smart arrangement**: Based on the parsing results, carefully construct a series of coherent and logical action command sequences. #18
- **Witty words**: Weave a concise (5 to 20 words), humorous and ever-changing feedback information for each action sequence, making the communication process interesting. #19
## Technical specifications #20
- **Output format**: Strictly follow the JSON format. Before output, remove the leading ```json and the trailing ```, start with `{` and end with `}`. You only need to answer a list, do not answer any Chinese. #21
- **Structure requirements**: #22
- The `"action"` key carries an array of function name strings arranged in execution order. When the corresponding action function cannot be found, action outputs []. #23
- The `"response"` key is paired with a short, well-thought-out response that perfectly fits the above word count and style requirements. #24
- **Special handling**: For the special function `track`, its parameters must be precisely enclosed in double quotes. #25
## All action functions #26
- One step forward: forward() #27
- One step back: back() #28
- One step left: turn_left() #29
- One step right: turn_right() #30
- Track objects of different colors: track('red') #31
## Examples #32
### Task example: First take two steps forward, then turn left, and finally take one step back. #33
### Expected response: {'action':['forward()', 'forward()', 'turn_left()', 'back()'], 'response':'Got it, executing immediately'} #34
### Task example: First stretch your muscles, then track the red ball. #35
### Expected response: {'action':['twist()', "track('red')"], 'response':'This is not difficult for me'} #36
''' #37
print(PROMPT) #38

wakeup_audio_path = './resources/audio/en/wakeup.wav' #40
start_audio_path = './resources/audio/en/start_audio.wav' #41
no_voice_audio_path = './resources/audio/en/no_voice.wav' #42
error_audio_path = './resources/audio/en/error.wav' #43

port = '/dev/ttyUSB0' #45
kws = awake.WonderEchoPro(port) #46
# kws = awake.CircleMic(port) #47

asr = speech.RealTimeOpenAIASR() #49
asr.update_session(model='whisper-1') #50
tts = speech.RealTimeOpenAITTS() #51
client = speech.OpenAIAPI(llm_api_key, llm_base_url) #52

try:  # If a fan is present, it's recommended to turn it off before detection to reduce interference(如果有风扇，检测前推荐关掉减少干扰) #54
    os.system('pinctrl FAN_PWM op dh') #55
except: #56
    pass #57

speech.set_volume(80) #59
speech.play_audio(start_audio_path) #60
print('start...') #61

def main(): #63
    kws.start() #64
    while True: #65
        try: #66
            if kws.wakeup(): # Wake word detected(检测到唤醒词) #67
                speech.play_audio(wakeup_audio_path)  # Play wake-up sound(唤醒播放) #68
                asr_result = asr.asr() # Start voice recognition(开启录音识别) #69
                print('asr_result:', asr_result) #70
                if asr_result: #71
                    # Send the question to the agent, process the response, and extract the corresponding actions and reply（输入问题给智能体，对返回的回答进行处理，提取出对应的行为和回答) #72
                    action_list, response = None, None #73
                    t1 = time.time() #74
                    result = client.llm(asr_result, prompt=PROMPT, model='gpt-4o-mini') #75
                    print('llm time:', time.time() - t1) #76
                    print('llm_result:', result) #77
                    if 'action' in result: # If the response includes actions, extract and process them(如果有对应的行为返回那么就提取处理) #78
                        result = eval(result[result.find('{'):result.find('}')+1]) #79
                        if 'action' in result: #80
                            action_list = result['action'] #81
                        if 'response' in result: #82
                            response = result['response'] #83
                    else: # If no corresponding action is found, provide only a response.(没有对应的行为，只回答) #84
                        response = result #85
                    print('agent_result:', action_list, response) #86
                    tts.tts(text=response, model='tts-1') #87
                    if response is not None: #88
                        if action_list is not None: #89
                            for a in action_list: #90
                                eval(f'action_demo.{a}') #91
                    else: #92
                        speech.play_audio(error_audio_path) #93
                else: #94
                    speech.play_audio(no_voice_audio_path) #95
            time.sleep(0.02) #96
        except KeyboardInterrupt: #97
            kws.exit()  #98
            try: #99
                os.system('pinctrl FAN_PWM a0') #100
            except: #101
                pass #102
            break #103
        except BaseException as e: #104
            print(e) #105

if __name__ == '__main__': #107
    main() #108
