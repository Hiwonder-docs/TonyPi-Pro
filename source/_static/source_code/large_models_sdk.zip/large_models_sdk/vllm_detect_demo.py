#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/02/28 #4
import cv2 #5
from config import * #6
from speech import speech #7

PROMPT = ''' #9
你作为图像专家，你的能力是将用户发来的图片进行目标检测精准定位，并按「输出格式」进行最后结果的输出。。 #10
## 1.理解图片 #11
我会给你一张图片，请识别图片中一共有哪些物体。 #12
## 2.物体定位 - position #13
检测到每一个物体的位置，根据你的知识和记忆，看清这个物体的样子，识别每个物体的具体名称。**请输出全部的物体不要遗漏** #14
## 输出格式（请仅输出以下内容，不要说任何多余的话） #15
{ #16
 "object1": [name, xmin, ymin, xmax, ymax], #17
 "object2": [name, xmin, ymin, xmax, ymax], #18
} #19
''' #20

client = speech.OpenAIAPI(api_key, base_url) #22
image = cv2.imread('./resources/pictures/detect.jpg') #23
vllm_result = client.vllm('', image, prompt=PROMPT, model='qwen-vl-max-latest') #24
vllm_result = eval(vllm_result[vllm_result.find('{'):vllm_result.find('}') + 1]) #25
print(vllm_result) #26
for i in vllm_result: #27
    position = vllm_result[i] #28
    p1 = [position[1], position[2]] #29
    p2 = [position[3], position[4]] #30
    cv2.rectangle(image, p1, p2, (0, 255, 0), 2, 1) #31
while True: #32
    try: #33
        cv2.imshow('image', image) #34
        key = cv2.waitKey(1) #35
        if key != -1: #36
            break #37
    except KeyboardInterrupt: #38
        cv2.destroyAllWindows() #39
        break #40

