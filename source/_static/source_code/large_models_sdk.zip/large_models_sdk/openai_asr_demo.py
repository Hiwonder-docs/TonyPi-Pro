#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/04/08 #4
from config import * #5
from speech import speech #6

# all param #8
# asr = speech.RealTimeOpenAIASR(rate=16000, channel=1, device=0) #9

asr = speech.RealTimeOpenAIASR() #11
# whisper-1 fast than gpt-4o-transcribe  #12
asr.update_session(model='whisper-1', language='en', threshold=0.2, prefix_padding_ms=300, silence_duration_ms=800) #13

print('start talking...') #15
print(asr.asr()) #16
# print(asr.asr(save_path='./resources/audio/test_recording.wav')) #17
