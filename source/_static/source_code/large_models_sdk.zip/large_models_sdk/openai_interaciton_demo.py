#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2025/03/05 #4
import os #5
import time #6
from config import * #7
from speech import awake #8
from speech import speech #9

wakeup_audio_path = './resources/audio/en/wakeup.wav' #11
start_audio_path = './resources/audio/en/start_audio.wav' #12
no_voice_audio_path = './resources/audio/en/no_voice.wav' #13

port = '/dev/ttyUSB0' #15
kws = awake.WonderEchoPro(port) #16
# kws = awake.CircleMic(port) #17

asr = speech.RealTimeOpenAIASR() #19
asr.update_session(model='whisper-1') #20
tts = speech.RealTimeOpenAITTS() #21
client = speech.OpenAIAPI(llm_api_key, llm_base_url) #22

try: #24
    os.system('pinctrl FAN_PWM op dh') #25
except: #26
    pass #27

speech.set_volume(80) #29
speech.play_audio(start_audio_path) #30
print('start...') #31

def main(): #33
    kws.start() #34
    while True: #35
        try: #36
            if kws.wakeup(): # Wake word detected(检测到唤醒词) #37
                speech.play_audio(wakeup_audio_path)  # Play wake-up sound(唤醒播放) #38
                asr_result = asr.asr() # Start voice recognition(开启录音识别) #39
                print('asr_result:', asr_result) #40
                if asr_result: #41
                    # Send the recognition result to the agent for a response(将识别结果传给智能体让他来回答) #42
                    response = client.llm(asr_result, model='gpt-4o-mini') #43
                    print('llm response:', response) #44
                    tts.tts(response) #45
                else: #46
                    speech.play_audio(no_voice_audio_path) #47
            time.sleep(0.02) #48
        except KeyboardInterrupt: #49
            kws.exit()  #50
            try: #51
                os.system('pinctrl FAN_PWM a0') #52
            except: #53
                pass #54
            break #55
        except BaseException as e: #56
            print(e) #57

if __name__ == '__main__': #59
    main() #60
