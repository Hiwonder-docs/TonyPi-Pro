#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\7.拓展课程之传感器基础开发课程\第2课 触摸传感器实验(4.Advanced Lessons\7.Sensor Development Course\Lesson2 Touch Sensor Module) #3
import os #4
import sys #5
import time #6
import gpiod #7
import hiwonder.ros_robot_controller_sdk as rrc #8


board = rrc.Board() #11
    
st = 0 #13

chip = gpiod.Chip('gpiochip4') #15
touch = chip.get_line(22) #16
touch.request(consumer="touch", type=gpiod.LINE_REQ_DIR_IN, flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP) #17

if __name__ == '__main__':  #19
    while True: #20
        state = touch.get_value()   #读取引脚数字值(read pin numerical value) #21
        if not state: #22
            if st :            #这里做一个判断，防止反复响(make a judgement to prevent repeated ringing here) #23
                st = 0 #24
                board.set_buzzer(1900, 0.1, 0.9, 1) # 以1900Hz的频率，持续响0.1秒，关闭0.9秒，重复1次(at a frequency of 1900Hz, sound for 0.1 seconds, then pause for 0.9 seconds, repeat once) #25
        else: #26
            st = 1 #27
            board.set_buzzer(1000, 0.0, 0.0, 1) # 关闭(close) #28

    board.set_buzzer(1000, 0.0, 0.0, 1) # 关闭(close) #30

