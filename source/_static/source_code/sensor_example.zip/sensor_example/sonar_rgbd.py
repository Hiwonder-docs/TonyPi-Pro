#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\7.拓展课程之传感器基础开发课程\第4课 超声波模块实验(4.Advanced Lessons\7.Sensor Development Course\Lesson4 Ultrasonic Module) #3
import os #4
import sys #5
import time #6
import hiwonder.Sonar as Sonar #7

if sys.version_info.major == 2: #9
    print('Please run this program with python3!') #10
    sys.exit(0) #11



s = Sonar.Sonar() #15
s.setRGBMode(0)    #设置灯的模式，0为彩灯模式，1为呼吸灯模式(set the light mode, 0 is color light mode, 1 is breathing light mode) #16
s.setRGB(1, (35,205,55)) #17
s.setRGB(0, (235,205,55)) #18
s.startSymphony() #19

if __name__ == "__main__": #21
    while True: #22
        time.sleep(1) #23
        if s.getDistance() != 99999: #24
            print("Distance:", s.getDistance() , "mm") #25
            distance = s.getDistance() #26
            
            if 0.0 <= distance <= 100.0: #28
                s.setRGBMode(0) #29
                s.setRGB(1, (255,0,0))  #两边RGB设置为红色(set both RGB to red) #30
                s.setRGB(0, (255,0,0)) #31
                
            if 100.0 < distance <= 150.0: #33
                s.setRGBMode(0) #34
                s.setRGB(1, (0,255,0))  #两边RGB设置为绿色(set both RGB to green) #35
                s.setRGB(0, (0,255,0)) #36
                
            if 150.0 < distance <= 200.0: #38
                s.setRGBMode(0) #39
                s.setRGB(1, (0,0,255))  #两边RGB设置为蓝色(set both RGB to blue) #40
                s.setRGB(0, (0,0,255)) #41
                
            if distance > 200.0: #43
                s.setRGBMode(0)       #44
                s.setRGB(1, (255,255,255)) # 两边RGB设置为白色(set both RGB to white) #45
                s.setRGB(0, (255,255,255)) #46
