#!/usr/bin/env python3 #1
# encoding: utf-8 #2
# @Author: Aiden #3
# @Date: 2024/09/21 #4
import time #5
import smbus #6
from hiwonder.display import TM1640 #7
from hiwonder.number_model import render_number #8


class AHT10: #11
    CONFIG = [0x08, 0x00] #12
    MEASURE = [0x33, 0x00] #13

    def __init__(self, bus=1, addr=0x38): #15
        self.bus = smbus.SMBus(bus) #16
        self.addr = addr #17
        time.sleep(0.2)  #18

    def getData(self): #20
        byte = self.bus.read_byte(self.addr) #21
        self.bus.write_i2c_block_data(self.addr, 0xAC, self.MEASURE) #22
        time.sleep(0.5) #23
        data = self.bus.read_i2c_block_data(self.addr, 0x00) #24
        temp = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5] #25
        ctemp = ((temp*200) / 1048576) - 50 #26
        hum = ((data[1] << 16) | (data[2] << 8) | data[3]) >> 4 #27
        chum = int(hum * 100 / 1048576) #28
        
        return (ctemp, chum) #30


if __name__ == '__main__': #33
    aht10 = AHT10() #34
    display = TM1640(dio=22, clk=24) #35
    display.clear() #36
    while True: #37
        # 提取温度 #38
        tempture = str(round(aht10.getData()[0], 1)) #39

        # 提取出三个数字 #41
        num1, num2, num3 = tempture[0], tempture[1], tempture[3] #42

        display.display_buf = render_number(num1, num2, ".", num3) #44
        display.update_display() #45

        time.sleep(2) #47

        #提取湿度 #49
        humidity = str(round(aht10.getData()[1], 1)) #50

        # 提取出两个数字 #52
        num1, num2 = humidity[0], humidity[1] #53

        display.display_buf = render_number(num1, num2, "%", "%") #55
        
        time.sleep(2) #57
