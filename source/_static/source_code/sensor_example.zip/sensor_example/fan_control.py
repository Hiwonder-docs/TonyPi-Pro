#!/usr/bin/python3 #1
# coding=utf8 #2
# 4.拓展课程学习\7.拓展课程之传感器基础开发课程\第1课 风扇模块实验(4.Advanced Lessons\7.Sensor Development Course\Lesson1 Fan Module) #3
import time #4
import gpiod #5

## 初始化引脚模式(initial pin mode) #7
chip = gpiod.Chip("gpiochip4") #8
fanPin1 = chip.get_line(8) #9
fanPin1.request(consumer="pin1", type=gpiod.LINE_REQ_DIR_OUT) #10

fanPin2 = chip.get_line(7) #12
fanPin2.request(consumer="pin2", type=gpiod.LINE_REQ_DIR_OUT) #13



# initial          #17
def init(): #18
    start = False #19
    set_fan(0) #20
    print("Fan Control Init")	 #21
    
#fan control  #23
def set_fan(start): #24
               
    if start == 1: #26
        ## 开启风扇, 顺时针(turn on the fan, clockwise) #27
        fanPin1.set_value(1)  # 设置引脚输出高电平(set pin output high voltage) #28
        fanPin2.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #29
    else: #30
        ## 关闭风扇(turn off the fan) #31
        fanPin1.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #32
        fanPin2.set_value(0)  # 设置引脚输出低电平(set pin output low voltage) #33

if __name__ == '__main__':  #35
    while True: #36
        try: #37
            set_fan(1) #38
        except KeyboardInterrupt: #39
            set_fan(0) #40
            break #41
    
    
